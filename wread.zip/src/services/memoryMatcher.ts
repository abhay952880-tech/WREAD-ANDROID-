import { Memory } from '../types';

const STOP_WORDS = new Set([
  'a', 'an', 'the', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'is', 'are', 'was',
  'were', 'be', 'been', 'with', 'about', 'by', 'as', 'into', 'from', 'this', 'that',
  'it', 'its', 'my', 'your', 'our', 'their', 'we', 'i', 'you', 'he', 'she', 'they',
  'me', 'him', 'her', 'us', 'them', 'can', 'will', 'do', 'did', 'does', 'done',
  'how', 'what', 'which', 'who', 'whom', 'whose', 'why', 'when', 'where', 'please',
  'create', 'make', 'generate', 'build', 'give', 'show', 'write'
]);

export function findRelevantMemories(prompt: string, allMemories: Memory[]): Memory[] {
  if (!prompt || !allMemories || allMemories.length === 0) return [];

  // Tokenize prompt
  const tokens = prompt
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length >= 3 && !STOP_WORDS.has(w));

  if (tokens.length === 0) return [];

  const scored: Array<{ memory: Memory; score: number }> = [];

  for (const mem of allMemories) {
    let score = 0;
    const keyLower = (mem.key || '').toLowerCase();
    const contentLower = (mem.content || '').toLowerCase();
    const tagsLower = (mem.tags || []).map(t => t.toLowerCase());
    const catLower = (mem.category || '').toLowerCase();

    for (const token of tokens) {
      // Key match (high priority)
      if (keyLower.includes(token)) {
        score += 5;
      }
      // Tag match (high priority)
      if (tagsLower.some(t => t.includes(token))) {
        score += 4;
      }
      // Category match
      if (catLower.includes(token)) {
        score += 2;
      }
      // Content match
      if (contentLower.includes(token)) {
        score += 1;
      }
    }

    if (score > 0) {
      scored.push({ memory: mem, score });
    }
  }

  // Sort by relevance score descending and take top 3
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3).map(s => s.memory);
}

export function formatRelevantMemoriesContext(memories: Memory[]): string {
  if (!memories || memories.length === 0) return '';
  return memories
    .map(m => `• [Memory: ${m.key} (${m.category})] ${m.content}`)
    .join('\n');
}
