/**
 * WREAD - Storage Service Abstraction
 * Manages local client persistence with modular interfaces ready for cloud database binding.
 */

import { Conversation, Task, Memory, ResearchResult, AppSettings, AgentHistoryItem } from '../types';

const STORAGE_KEYS = {
  CONVERSATIONS: 'wread_conversations_v1',
  ACTIVE_CONVERSATION_ID: 'wread_active_conversation_id_v1',
  MEMORIES: 'wread_memories_v1',
  TASKS: 'wread_tasks_v1',
  RESEARCH_HISTORY: 'wread_research_history_v1',
  AGENT_HISTORY: 'wread_agent_history_v1',
  SETTINGS: 'wread_settings_v1',
};

// Default seed memories for immediate practical usability
const DEFAULT_MEMORIES: Memory[] = [
  {
    id: 'mem_1',
    key: 'Developer Persona',
    content: 'User prefers concise, mathematically structured code, production-grade TypeScript, and clean responsive UI design.',
    category: 'Preferences',
    createdAt: Date.now() - 3600000 * 24 * 2,
    updatedAt: Date.now() - 3600000 * 24 * 2,
    tags: ['coding', 'style'],
  },
  {
    id: 'mem_2',
    key: 'Core Directives',
    content: 'Always provide verifiable technical details, never generate speculative citations as authentic fact, and preserve security parameters.',
    category: 'Instructions',
    createdAt: Date.now() - 3600000 * 24,
    updatedAt: Date.now() - 3600000 * 24,
    tags: ['safety', 'directives'],
  },
  {
    id: 'mem_3',
    key: 'Project Scope: WREAD',
    content: 'High-performance personal AI operating system featuring autonomous agent loop, memory synthesis, and Kimi-K3 / Gemini multimodal backends.',
    category: 'Projects',
    createdAt: Date.now() - 3600000 * 12,
    updatedAt: Date.now() - 3600000 * 12,
    tags: ['wread', 'ai-os'],
  },
];

// Default sample tasks
const DEFAULT_TASKS: Task[] = [
  {
    id: 'task_1',
    title: 'Autonomous Architecture Audit',
    description: 'Verify zero credential leakage across frontend bundles and inspect client-server boundary.',
    status: 'Completed',
    createdAt: Date.now() - 7200000,
    updatedAt: Date.now() - 3600000,
    progress: 100,
    result: 'Architecture verified: Zero client secrets. Server-side proxy handling upstream requests.',
    category: 'Security',
  },
  {
    id: 'task_2',
    title: 'Multi-Modal Vision Pipeline',
    description: 'Ensure base64 image streams are sanitized and routed safely to multimodal provider.',
    status: 'Pending',
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now() - 3600000,
    progress: 40,
    category: 'Vision',
  },
];

// Default settings
export const DEFAULT_SETTINGS: AppSettings = {
  aiModel: 'moonshotai/Kimi-K3',
  temperature: 0.7,
  maxTokens: 4096,
  systemPrompt: 'You are WREAD, an advanced personal AI operating system. Provide thoughtful, sharp, technically rigorous answers.',
  memoryEnabled: true,
  autoExtractMemory: true,
  soundEnabled: false,
  accentColor: 'cyan',
  orbAnimation: true,
  voiceInputEnabled: true,
  voiceOutputEnabled: false, // Default OFF as requested
  voiceLanguage: 'auto',
  speechRate: 1.0,
};

export const StorageService = {
  // --- CONVERSATIONS ---
  getConversations(): Conversation[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
      if (!raw) return [];
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  saveConversation(conversation: Conversation): void {
    const list = this.getConversations();
    const index = list.findIndex(c => c.id === conversation.id);
    if (index >= 0) {
      list[index] = conversation;
    } else {
      list.unshift(conversation);
    }
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(list));
  },

  deleteConversation(id: string): void {
    const list = this.getConversations().filter(c => c.id !== id);
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(list));
    if (this.getActiveConversationId() === id) {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID);
    }
  },

  renameConversation(id: string, newTitle: string): void {
    const list = this.getConversations();
    const index = list.findIndex(c => c.id === id);
    if (index >= 0) {
      list[index].title = newTitle.trim() || 'Untitled Conversation';
      list[index].updatedAt = Date.now();
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(list));
    }
  },

  clearConversationMessages(id: string): void {
    const list = this.getConversations();
    const index = list.findIndex(c => c.id === id);
    if (index >= 0) {
      list[index].messages = [];
      list[index].updatedAt = Date.now();
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(list));
    }
  },

  getActiveConversationId(): string | null {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID);
  },

  setActiveConversationId(id: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID, id);
  },

  // --- MEMORIES ---
  getMemories(): Memory[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.MEMORIES);
      if (!raw) {
        localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(DEFAULT_MEMORIES));
        return DEFAULT_MEMORIES;
      }
      return JSON.parse(raw);
    } catch {
      return DEFAULT_MEMORIES;
    }
  },

  saveMemory(memory: Memory): void {
    const list = this.getMemories();
    const index = list.findIndex(m => m.id === memory.id);
    if (index >= 0) {
      list[index] = memory;
    } else {
      list.unshift(memory);
    }
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(list));
  },

  deleteMemory(id: string): void {
    const list = this.getMemories().filter(m => m.id !== id);
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(list));
  },

  clearMemories(): void {
    localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify([]));
  },

  // --- TASKS ---
  getTasks(): Task[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
      if (!raw) {
        localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(DEFAULT_TASKS));
        return DEFAULT_TASKS;
      }
      return JSON.parse(raw);
    } catch {
      return DEFAULT_TASKS;
    }
  },

  saveTask(task: Task): void {
    const list = this.getTasks();
    const index = list.findIndex(t => t.id === task.id);
    if (index >= 0) {
      list[index] = task;
    } else {
      list.unshift(task);
    }
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(list));
  },

  deleteTask(id: string): void {
    const list = this.getTasks().filter(t => t.id !== id);
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(list));
  },

  // --- RESEARCH HISTORY ---
  getResearchHistory(): ResearchResult[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.RESEARCH_HISTORY);
      if (!raw) return [];
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  saveResearchResult(result: ResearchResult): void {
    const list = this.getResearchHistory();
    const filtered = list.filter(r => r.id !== result.id);
    filtered.unshift(result);
    // Keep last 25 results
    const trimmed = filtered.slice(0, 25);
    localStorage.setItem(STORAGE_KEYS.RESEARCH_HISTORY, JSON.stringify(trimmed));
  },

  deleteResearchResult(id: string): void {
    const list = this.getResearchHistory().filter(r => r.id !== id);
    localStorage.setItem(STORAGE_KEYS.RESEARCH_HISTORY, JSON.stringify(list));
  },

  clearResearchHistory(): void {
    localStorage.setItem(STORAGE_KEYS.RESEARCH_HISTORY, JSON.stringify([]));
  },

  // --- AGENT HISTORY ---
  getAgentHistory(): AgentHistoryItem[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AGENT_HISTORY);
      if (!raw) return [];
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  saveAgentHistoryItem(item: AgentHistoryItem): void {
    const list = this.getAgentHistory();
    const filtered = list.filter(h => h.id !== item.id);
    filtered.unshift(item);
    // Keep last 30 agent tasks
    const trimmed = filtered.slice(0, 30);
    localStorage.setItem(STORAGE_KEYS.AGENT_HISTORY, JSON.stringify(trimmed));
  },

  deleteAgentHistoryItem(id: string): void {
    const list = this.getAgentHistory().filter(h => h.id !== id);
    localStorage.setItem(STORAGE_KEYS.AGENT_HISTORY, JSON.stringify(list));
  },

  clearAgentHistory(): void {
    localStorage.setItem(STORAGE_KEYS.AGENT_HISTORY, JSON.stringify([]));
  },

  // --- SETTINGS ---
  getSettings(): AppSettings {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (!raw) return DEFAULT_SETTINGS;
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: AppSettings): void {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },
};
