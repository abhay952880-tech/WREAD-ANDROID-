/**
 * WREAD - Client API Service
 * Secure communication layer routing all calls through the WREAD Server API.
 * Never connects to AI provider credentials from the client.
 */

import { BackendHealth, Message, ResearchResult, AgentStep, MessageAttachment } from '../types';

export class APIClientError extends Error {
  status: number;
  code?: string;

  constructor(message: string, status: number = 500, code?: string) {
    super(message);
    this.name = 'APIClientError';
    this.status = status;
    this.code = code;
  }
}

export async function checkBackendHealth(): Promise<BackendHealth> {
  try {
    const res = await fetch('/api/health', {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
    });

    if (!res.ok) {
      return {
        backend: 'degraded',
        configured: false,
        provider: 'unknown',
        model: 'unknown',
        hasKimiKey: false,
        hasGeminiKey: false,
        timestamp: new Date().toISOString(),
      };
    }

    const data = await res.json();
    return {
      backend: data.backend || 'ok',
      configured: Boolean(data.configured),
      provider: data.provider || 'kimi',
      model: data.model || 'moonshotai/Kimi-K3',
      hasKimiKey: Boolean(data.hasKimiKey),
      hasGeminiKey: Boolean(data.hasGeminiKey),
      timestamp: data.timestamp || new Date().toISOString(),
    };
  } catch (err: any) {
    return {
      backend: 'offline',
      configured: false,
      provider: 'none',
      model: 'none',
      hasKimiKey: false,
      hasGeminiKey: false,
      timestamp: new Date().toISOString(),
    };
  }
}

export async function sendChatMessage(
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>,
  options?: { temperature?: number; signal?: AbortSignal }
): Promise<{
  content: string;
  model: string;
  provider: string;
  reasoning?: string;
  responseTime?: number;
}> {
  let response: Response;

  try {
    response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      signal: options?.signal,
      body: JSON.stringify({
        messages,
        temperature: options?.temperature,
      }),
    });
  } catch (err: any) {
    if (err.name === 'AbortError' || err.message?.includes('aborted')) {
      throw new APIClientError('Request stopped by user.', 499, 'ABORTED');
    }
    throw new APIClientError(
      'Failed to communicate with WREAD server. Please check your network connection.',
      0,
      'NETWORK_ERROR'
    );
  }

  if (!response.ok) {
    let errorData: any = {};
    try {
      errorData = await response.json();
    } catch {
      // ignore JSON parse error
    }
    const message = errorData?.error?.message || `Server error (HTTP ${response.status})`;
    throw new APIClientError(message, response.status);
  }

  let data: any;
  try {
    data = await response.json();
  } catch {
    throw new APIClientError('Invalid response received from WREAD server.', 502);
  }

  if (!data || typeof data.content !== 'string' || data.content.trim().length === 0) {
    throw new APIClientError('The AI returned an empty response. Please try again.', 500);
  }

  return {
    content: data.content,
    model: data.model || 'moonshotai/Kimi-K3',
    provider: data.provider || 'Kimi-K3',
    reasoning: data.reasoning,
    responseTime: data.responseTime,
  };
}

export async function executeAgentStep(
  prompt: string,
  step: AgentStep,
  context?: any,
  imageAttachment?: MessageAttachment
): Promise<{ output: string; model: string }> {
  try {
    const res = await fetch('/api/agent/step', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, step, context, imageAttachment }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new APIClientError(errData?.error?.message || 'Agent step failed.', res.status);
    }

    return await res.json();
  } catch (err: any) {
    if (err instanceof APIClientError) throw err;
    throw new APIClientError(err.message || 'Agent execution failed.');
  }
}

export async function performWebResearch(
  query: string,
  mode: 'quick' | 'deep' = 'quick',
  options?: {
    relevantMemories?: string[];
    signal?: AbortSignal;
  }
): Promise<ResearchResult> {
  try {
    const res = await fetch('/api/research', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: options?.signal,
      body: JSON.stringify({
        query,
        mode,
        depth: mode === 'deep' ? 'deep' : 'overview',
        relevantMemories: options?.relevantMemories,
      }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new APIClientError(errData?.error?.message || 'Research synthesis failed.', res.status);
    }

    const data = await res.json();
    return {
      id: data.id || 'res_' + Date.now(),
      query: data.query || query,
      mode: data.mode || mode,
      depth: mode === 'deep' ? 'deep' : 'overview',
      createdAt: data.createdAt || Date.now(),
      summary: data.summary || 'No summary generated.',
      finalAnswer: data.finalAnswer || data.summary || 'No answer produced.',
      keyFindings: Array.isArray(data.keyFindings) ? data.keyFindings : [],
      keyFacts: Array.isArray(data.keyFacts) ? data.keyFacts : [],
      contradictions: Array.isArray(data.contradictions) ? data.contradictions : [],
      sources: Array.isArray(data.sources) ? data.sources : [],
      status: data.status || 'completed',
      model: data.model,
      provider: data.provider,
    };
  } catch (err: any) {
    if (err.name === 'AbortError' || err.code === 'ABORTED') {
      throw new APIClientError('Research stopped by user.', 499, 'ABORTED');
    }
    if (err instanceof APIClientError) throw err;
    throw new APIClientError(err.message || 'Web research request failed.');
  }
}

export async function analyzeImageFile(
  imageBase64: string,
  mimeType: string,
  prompt?: string,
  fileName?: string
): Promise<{ content: string; model: string; provider: string; timestamp?: string }> {
  try {
    const res = await fetch('/api/analyze-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64, mimeType, prompt, fileName }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new APIClientError(errData?.error?.message || 'Image analysis failed.', res.status);
    }

    return await res.json();
  } catch (err: any) {
    if (err instanceof APIClientError) throw err;
    throw new APIClientError(err.message || 'Image analysis call failed.');
  }
}
