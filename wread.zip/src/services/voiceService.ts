/**
 * WREAD Voice Assistant Service
 * Provides Speech-to-Text (STT) and Text-to-Speech (TTS)
 * Works fully in-browser with zero raw audio recordings stored or uploaded.
 * Supports English, Hindi, and Auto detection.
 */

import { VoiceLanguage } from '../types';

// Browser SpeechRecognition interface augmentation
interface IWindowSpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: ((this: IWindowSpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: IWindowSpeechRecognition, ev: any) => any) | null;
  onerror: ((this: IWindowSpeechRecognition, ev: any) => any) | null;
  onend: ((this: IWindowSpeechRecognition, ev: Event) => any) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: {
      new (): IWindowSpeechRecognition;
    };
    webkitSpeechRecognition?: {
      new (): IWindowSpeechRecognition;
    };
  }
}

export interface VoiceRecognitionCallbacks {
  onStart?: () => void;
  onInterim?: (interimText: string) => void;
  onFinal?: (finalText: string) => void;
  onError?: (errorMessage: string) => void;
  onEnd?: () => void;
}

export interface SpeakOptions {
  language?: VoiceLanguage;
  rate?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: any) => void;
}

// Hindi detection helper (Devanagari script + common Romanized Hindi tokens)
const HINDI_ROMAN_TOKENS = new Set([
  'hai', 'hain', 'kya', 'kaise', 'kyun', 'kitna', 'kitne', 'samjhao', 'batao',
  'karo', 'karen', 'hota', 'hoti', 'hote', 'mein', 'par', 'aur', 'nahi', 'nahi',
  'namaste', 'shukriya', 'dhanyawad', 'mera', 'meri', 'mere', 'aap', 'tum',
  'kuch', 'accha', 'theek', 'padhai', 'pariksha', 'yojana', 'banao'
]);

export class VoiceAssistantService {
  private static recognitionInstance: IWindowSpeechRecognition | null = null;
  private static isCurrentlyListening: boolean = false;
  private static currentUtterance: SpeechSynthesisUtterance | null = null;
  private static cachedVoices: SpeechSynthesisVoice[] = [];
  private static voicesLoaded: boolean = false;

  /**
   * Initializes voice caching on browser mount
   */
  public static init(): void {
    if (typeof window === 'undefined') return;

    if ('speechSynthesis' in window) {
      const updateVoices = () => {
        try {
          this.cachedVoices = window.speechSynthesis.getVoices();
          if (this.cachedVoices.length > 0) {
            this.voicesLoaded = true;
          }
        } catch {
          // Ignore
        }
      };

      updateVoices();
      if (typeof window.speechSynthesis.onvoiceschanged !== 'undefined') {
        window.speechSynthesis.onvoiceschanged = updateVoices;
      }
    }
  }

  /**
   * Check if Speech-to-Text is supported in this browser/device
   */
  public static isSTTSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }

  /**
   * Check if Text-to-Speech is supported in this browser/device
   */
  public static isTTSSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return typeof window.speechSynthesis !== 'undefined';
  }

  /**
   * Resolve BCP-47 language tag based on chosen setting and text context
   */
  public static resolveLanguage(pref: VoiceLanguage, sampleText?: string): string {
    if (pref === 'hi-IN') return 'hi-IN';
    if (pref === 'en-US') return 'en-US';

    // Auto-detection
    if (sampleText) {
      // 1. Check Devanagari script: Unicode block 0900-097F
      if (/[\u0900-\u097F]/.test(sampleText)) {
        return 'hi-IN';
      }

      // 2. Check Romanized Hindi keywords (Hinglish)
      const words = sampleText.toLowerCase().split(/[\s,?.!]+/);
      let hindiCount = 0;
      for (const w of words) {
        if (HINDI_ROMAN_TOKENS.has(w)) hindiCount++;
      }
      if (hindiCount >= 2 || (words.length <= 4 && hindiCount >= 1)) {
        return 'hi-IN';
      }
    }

    // Default to system language if Indian English/Hindi, or en-US
    const sysLang = typeof navigator !== 'undefined' ? navigator.language : 'en-US';
    if (sysLang.startsWith('hi')) return 'hi-IN';
    if (sysLang === 'en-IN') return 'en-IN';
    return 'en-US';
  }

  /**
   * Start microphone speech recognition
   */
  public static startListening(
    callbacks: VoiceRecognitionCallbacks,
    prefLanguage: VoiceLanguage = 'auto'
  ): void {
    if (!this.isSTTSupported()) {
      callbacks.onError?.('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Android Chrome.');
      return;
    }

    // Stop any existing session
    this.stopListening();
    this.stopSpeaking();

    const SpeechRecConstructor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecConstructor) {
      callbacks.onError?.('Speech recognition interface unavailable.');
      return;
    }

    try {
      const recognition = new SpeechRecConstructor();
      this.recognitionInstance = recognition;

      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.lang = this.resolveLanguage(prefLanguage);

      let accumulatedTranscript = '';

      recognition.onstart = () => {
        this.isCurrentlyListening = true;
        callbacks.onStart?.();
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0]?.transcript || '';
          if (event.results[i].isFinal) {
            accumulatedTranscript += (accumulatedTranscript ? ' ' : '') + transcript.trim();
          } else {
            interim += transcript;
          }
        }

        if (interim) {
          callbacks.onInterim?.(interim);
        }
        if (accumulatedTranscript) {
          callbacks.onFinal?.(accumulatedTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        const errorKey = event.error;
        let friendlyMessage = 'Voice recognition error occurred.';

        switch (errorKey) {
          case 'not-allowed':
          case 'permission-denied':
            friendlyMessage = 'Microphone permission denied. Please allow microphone access in your browser.';
            break;
          case 'no-speech':
            friendlyMessage = 'No speech detected. Please tap the microphone and speak again.';
            break;
          case 'audio-capture':
            friendlyMessage = 'No microphone device was detected, or microphone is in use by another app.';
            break;
          case 'network':
            friendlyMessage = 'Network connection issue with speech recognition service.';
            break;
          case 'aborted':
            // Intentional cancel, no error message needed
            return;
          default:
            friendlyMessage = `Voice recognition error (${errorKey}).`;
            break;
        }

        callbacks.onError?.(friendlyMessage);
      };

      recognition.onend = () => {
        this.isCurrentlyListening = false;
        this.recognitionInstance = null;
        callbacks.onEnd?.();
      };

      recognition.start();
    } catch (err: any) {
      this.isCurrentlyListening = false;
      this.recognitionInstance = null;
      callbacks.onError?.(err?.message || 'Could not access microphone.');
    }
  }

  /**
   * Stop active speech recognition
   */
  public static stopListening(): void {
    if (this.recognitionInstance) {
      try {
        this.recognitionInstance.stop();
      } catch {
        // Ignore
      }
      this.recognitionInstance = null;
    }
    this.isCurrentlyListening = false;
  }

  public static isListening(): boolean {
    return this.isCurrentlyListening;
  }

  /**
   * Clean text for speech synthesis (strip code blocks, links, math, tables)
   */
  public static cleanTextForSpeech(rawText: string): string {
    if (!rawText) return '';

    return rawText
      // Strip markdown code blocks
      .replace(/```[\s\S]*?```/g, ' [code block omitted] ')
      // Strip inline code
      .replace(/`([^`]+)`/g, '$1')
      // Strip images
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '')
      // Strip markdown links -> keep link text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // Strip markdown headers
      .replace(/#{1,6}\s+/g, '')
      // Strip citations like [1], [2]
      .replace(/\[\d+\]/g, '')
      // Strip bold / italic
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/_([^_]+)_/g, '$1')
      // Strip blockquotes
      .replace(/^\s*>\s+/gm, '')
      // Strip bullet symbols
      .replace(/^\s*[-*+]\s+/gm, '')
      // Strip numbered lists like 1. 2.
      .replace(/^\s*\d+\.\s+/gm, '')
      // Strip horizontal rules
      .replace(/^-{3,}$/gm, '')
      // Strip table dividers
      .replace(/\|[-:]+\|/g, ' ')
      .replace(/\|/g, ' ')
      // Clean up whitespace
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Speak text aloud using SpeechSynthesis
   */
  public static speak(text: string, options?: SpeakOptions): void {
    if (!this.isTTSSupported()) {
      options?.onError?.('Speech synthesis is not supported on this device.');
      return;
    }

    // Stop ongoing speech
    this.stopSpeaking();

    const cleaned = this.cleanTextForSpeech(text);
    if (!cleaned) return;

    // Limit length to first 1200 characters for responsive speaking
    const textToSpeak = cleaned.length > 1200 ? cleaned.slice(0, 1200) + '...' : cleaned;

    try {
      // Chrome Android resume quirk
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      this.currentUtterance = utterance;

      const langCode = this.resolveLanguage(options?.language || 'auto', textToSpeak);
      utterance.lang = langCode;
      utterance.rate = Math.max(0.6, Math.min(2.0, options?.rate || 1.0));
      utterance.pitch = 1.0;

      // Select matching voice
      const voices = this.cachedVoices.length > 0 ? this.cachedVoices : window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        // Priority 1: exact language match
        let selectedVoice = voices.find(v => v.lang.toLowerCase() === langCode.toLowerCase());
        
        // Priority 2: partial language match (e.g. 'hi' or 'en')
        if (!selectedVoice) {
          const prefix = langCode.split('-')[0].toLowerCase();
          selectedVoice = voices.find(v => v.lang.toLowerCase().startsWith(prefix));
        }

        // If Hindi requested or detected and no Hindi voice found, try Indian English (en-IN)
        if (!selectedVoice && langCode.startsWith('hi')) {
          selectedVoice = voices.find(v => v.lang.toLowerCase().includes('in') || v.lang.toLowerCase().includes('india'));
        }

        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
      }

      utterance.onstart = () => {
        options?.onStart?.();
      };

      utterance.onend = () => {
        this.currentUtterance = null;
        options?.onEnd?.();
      };

      utterance.onerror = (ev) => {
        this.currentUtterance = null;
        // Ignore user-initiated cancellation
        if (ev.error !== 'canceled' && ev.error !== 'interrupted') {
          options?.onError?.(ev);
        } else {
          options?.onEnd?.();
        }
      };

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      this.currentUtterance = null;
      options?.onError?.(err);
    }
  }

  /**
   * Stop active speech synthesis
   */
  public static stopSpeaking(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Ignore
      }
      this.currentUtterance = null;
    }
  }

  /**
   * Check if speech synthesis is currently speaking
   */
  public static isSpeaking(): boolean {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
    return window.speechSynthesis.speaking;
  }
}

// Auto-initialize voice listener
if (typeof window !== 'undefined') {
  VoiceAssistantService.init();
}
