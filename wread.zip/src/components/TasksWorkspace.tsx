import React, { useState, useEffect } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Play, 
  Square, 
  Trash2, 
  X,
  Layers,
  Filter
} from 'lucide-react';
import { Task, TaskStatus } from '../types';
import { StorageService } from '../services/storage';

export const TasksWorkspace: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [isCreatingTask, setIsCreatingTask] = useState(false);

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState('Operations');

  useEffect(() => {
    setTasks(StorageService.getTasks());
  }, []);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newTask: Task = {
      id: 'task_' + Date.now(),
      title: newTitle.trim(),
      description: newDescription.trim(),
      status: 'Pending',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      progress: 0,
      category: newCategory,
    };

    StorageService.saveTask(newTask);
    setTasks(StorageService.getTasks());
    setNewTitle('');
    setNewDescription('');
    setIsCreatingTask(false);
  };

  const handleUpdateStatus = (taskId: string, newStatus: TaskStatus) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const progress = newStatus === 'Completed' ? 100 : newStatus === 'Running' ? 50 : task.progress;
    const updated: Task = {
      ...task,
      status: newStatus,
      progress,
      updatedAt: Date.now(),
      result: newStatus === 'Completed' ? (task.result || 'Task verified and marked completed.') : task.result,
    };

    StorageService.saveTask(updated);
    setTasks(StorageService.getTasks());
  };

  const handleDeleteTask = (id: string) => {
    StorageService.deleteTask(id);
    setTasks(StorageService.getTasks());
  };

  // Filter tasks
  const filteredTasks = tasks.filter((task) => {
    const isCompletedStatus = task.status === 'Completed';
    const matchesTab = activeTab === 'completed' ? isCompletedStatus : !isCompletedStatus;
    const matchesStatus = statusFilter === 'All' || task.status === statusFilter;
    return matchesTab && matchesStatus;
  });

  const getStatusBadge = (status: TaskStatus) => {
    switch (status) {
      case 'Completed':
        return 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300';
      case 'Running':
        return 'bg-cyan-950/70 border-cyan-500/40 text-cyan-300 animate-pulse';
      case 'Pending':
        return 'bg-slate-900 border-slate-700 text-slate-300';
      case 'Failed':
        return 'bg-rose-950/70 border-rose-500/40 text-rose-300';
      case 'Cancelled':
        return 'bg-amber-950/70 border-amber-500/40 text-amber-300';
    }
  };

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-blue-400" />
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Task Queue & Milestones
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950/60 border border-blue-500/30 text-blue-300 text-xs font-mono">
              {tasks.filter(t => t.status !== 'Completed').length} Active
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track and orchestrate active missions, background evaluations, and completed deliverables.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingTask(true)}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-medium text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-lg shadow-blue-950/40 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Task</span>
        </button>
      </div>

      {/* Create Task Modal */}
      {isCreatingTask && (
        <div className="glass-card rounded-2xl p-5 border border-blue-500/30 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-blue-400" />
              <span>Create New Task</span>
            </h3>
            <button
              onClick={() => setIsCreatingTask(false)}
              className="text-slate-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleCreateTask} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Task Title
              </label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g. Conduct Security Audit, Compile Technical Specification"
                className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category
                </label>
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="Operations, Research, Code, Security"
                  className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Description & Constraints
              </label>
              <textarea
                rows={2}
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="Detailed objectives, expected outcomes, or parameters..."
                className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingTask(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white transition-all shadow-md cursor-pointer"
              >
                Create Task
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tabs & Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Active vs Completed Tabs */}
        <div className="flex items-center bg-slate-950/80 rounded-xl p-1 border border-white/[0.08] w-fit">
          <button
            onClick={() => {
              setActiveTab('active');
              setStatusFilter('All');
            }}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'active'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Active ({tasks.filter(t => t.status !== 'Completed').length})
          </button>
          <button
            onClick={() => {
              setActiveTab('completed');
              setStatusFilter('All');
            }}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
              activeTab === 'completed'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Completed ({tasks.filter(t => t.status === 'Completed').length})
          </button>
        </div>

        {/* Status Dropdown */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 border border-white/[0.1] text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Running">Running</option>
            <option value="Completed">Completed</option>
            <option value="Failed">Failed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Task Cards List */}
      {filteredTasks.length === 0 ? (
        /* Empty State */
        <div className="glass-card rounded-2xl p-12 text-center text-slate-400 space-y-3 border border-white/[0.06]">
          <CheckSquare className="w-10 h-10 text-slate-400 mx-auto" />
          <h4 className="text-base font-semibold text-slate-200">
            {activeTab === 'active' ? 'No active tasks' : 'No completed tasks yet'}
          </h4>
          <p className="text-xs max-w-sm mx-auto">
            {activeTab === 'active'
              ? 'Create a new task to track and queue autonomous milestones.'
              : 'Completed deliverables will appear here once milestones finish.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className="glass-card rounded-2xl p-5 border border-white/[0.08] hover:border-blue-500/30 transition-all space-y-3 shadow-lg"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-semibold text-slate-100">
                      {task.title}
                    </h3>
                    {task.category && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-white/[0.05]">
                        {task.category}
                      </span>
                    )}
                  </div>
                  {task.description && (
                    <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                      {task.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusBadge(
                      task.status
                    )}`}
                  >
                    {task.status}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>Progress</span>
                  <span className="font-mono">{task.progress}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      task.status === 'Completed'
                        ? 'bg-emerald-400'
                        : task.status === 'Failed'
                        ? 'bg-rose-500'
                        : 'bg-blue-500'
                    }`}
                    style={{ width: `${task.progress}%` }}
                  />
                </div>
              </div>

              {/* Result if present */}
              {task.result && (
                <div className="p-3 rounded-xl bg-slate-950/60 border border-white/[0.04] text-xs text-slate-300">
                  <span className="font-semibold text-slate-200">Outcome: </span>
                  {task.result}
                </div>
              )}

              {/* Footer Controls & Timestamps */}
              <div className="pt-2 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
                <div className="flex items-center gap-1 text-[11px]">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Created {new Date(task.createdAt).toLocaleDateString()}</span>
                </div>

                <div className="flex items-center gap-2">
                  {task.status !== 'Completed' && (
                    <>
                      {task.status !== 'Running' && (
                        <button
                          onClick={() => handleUpdateStatus(task.id, 'Running')}
                          className="px-2.5 py-1 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/30 text-cyan-300 text-[11px] font-medium transition-colors cursor-pointer"
                        >
                          Mark Running
                        </button>
                      )}
                      <button
                        onClick={() => handleUpdateStatus(task.id, 'Completed')}
                        className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-300 text-[11px] font-medium transition-colors cursor-pointer"
                      >
                        Mark Done
                      </button>
                    </>
                  )}
                  {task.status === 'Running' && (
                    <button
                      onClick={() => handleUpdateStatus(task.id, 'Cancelled')}
                      className="px-2.5 py-1 rounded-lg bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/30 text-amber-300 text-[11px] font-medium transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="p-1 text-slate-300 hover:text-rose-400 transition-colors cursor-pointer"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
