import React, { useState, useRef } from 'react';
import { 
  Image as ImageIcon, 
  UploadCloud, 
  X, 
  Sparkles, 
  FileCheck, 
  Scan, 
  AlertCircle, 
  Copy, 
  Check, 
  RefreshCw,
  Cpu
} from 'lucide-react';
import { analyzeImageFile } from '../services/api';
import { FormattedResponse } from './FormattedResponse';

export const VisionWorkspace: React.FC = () => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [mimeType, setMimeType] = useState<string>('image/png');
  const [prompt, setPrompt] = useState<string>('Analyze this image in detail. Identify technical architecture, text, structures, and visual patterns.');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedResult, setCopiedResult] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Preset sample image generator for instant verification
  const loadSampleImage = (type: 'architecture' | 'flowchart') => {
    // Generate a sleek canvas diagram
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 360;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 600, 360);

    // Grid lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < 600; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 360);
      ctx.stroke();
    }
    for (let y = 0; y < 360; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(600, y);
      ctx.stroke();
    }

    if (type === 'architecture') {
      // Box 1: Client
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(40, 140, 120, 80);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px monospace';
      ctx.fillText('Client Web', 60, 185);

      // Box 2: Proxy
      ctx.fillStyle = '#4f46e5';
      ctx.fillRect(240, 140, 120, 80);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('WREAD API', 260, 185);

      // Box 3: Model
      ctx.fillStyle = '#9333ea';
      ctx.fillRect(440, 140, 120, 80);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Kimi-K3', 470, 185);

      // Connectors
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(160, 180);
      ctx.lineTo(240, 180);
      ctx.moveTo(360, 180);
      ctx.lineTo(440, 180);
      ctx.stroke();
    } else {
      ctx.fillStyle = '#059669';
      ctx.fillRect(80, 80, 160, 90);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px monospace';
      ctx.fillText('State Engine', 105, 130);

      ctx.fillStyle = '#d97706';
      ctx.fillRect(360, 80, 160, 90);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Memory Cache', 385, 130);
    }

    const dataUrl = canvas.toDataURL('image/png');
    setImageSrc(dataUrl);
    setFileName(`sample_${type}_diagram.png`);
    setFileSize('~42 KB');
    setMimeType('image/png');
    setAnalysisResult(null);
    setErrorMessage(null);
  };

  const handleFileChange = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please provide a valid image file (PNG, JPEG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImageSrc(reader.result as string);
      setFileName(file.name);
      setFileSize(`${Math.round(file.size / 1024)} KB`);
      setMimeType(file.type);
      setAnalysisResult(null);
      setErrorMessage(null);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!imageSrc || isAnalyzing) return;

    setIsAnalyzing(true);
    setErrorMessage(null);

    try {
      const response = await analyzeImageFile(imageSrc, mimeType, prompt);
      setAnalysisResult(response.content);
    } catch (err: any) {
      setErrorMessage(err.message || 'Image analysis failed.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCopyResult = () => {
    if (!analysisResult) return;
    navigator.clipboard.writeText(analysisResult);
    setCopiedResult(true);
    setTimeout(() => setCopiedResult(false), 2000);
  };

  const handleRemoveImage = () => {
    setImageSrc(null);
    setFileName('');
    setFileSize('');
    setAnalysisResult(null);
    setErrorMessage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-amber-400" />
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Image Analysis Architecture
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-950/60 border border-amber-500/30 text-amber-300 text-xs font-mono">
              Vision Protocol
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Analyze architectural diagrams, documents, user interfaces, or visual media via server vision proxy.
          </p>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900 border border-white/[0.07] text-xs text-slate-300">
          <Cpu className="w-4 h-4 text-amber-400" />
          <span>Multimodal Pipeline Ready</span>
        </div>
      </div>

      {/* Main Workspace Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Image Upload & Preview */}
        <div className="lg:col-span-6 space-y-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileChange(e.target.files[0]);
              }
            }}
            accept="image/*"
            className="hidden"
          />

          {!imageSrc ? (
            /* Upload Dropzone */
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="glass-card rounded-2xl p-8 border-2 border-dashed border-white/[0.12] hover:border-amber-500/50 transition-all cursor-pointer text-center flex flex-col items-center justify-center min-h-[300px] group shadow-xl"
            >
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <UploadCloud className="w-7 h-7 text-amber-400" />
              </div>

              <h3 className="text-base font-semibold text-slate-100 mb-1">
                Upload image for visual analysis
              </h3>
              <p className="text-xs text-slate-400 max-w-xs mb-4">
                Drag and drop files here, or click to browse (PNG, JPG, WebP)
              </p>

              {/* Sample Images button */}
              <div className="pt-2 flex flex-wrap gap-2 justify-center" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  onClick={() => loadSampleImage('architecture')}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs text-amber-300 border border-amber-500/30 transition-colors"
                >
                  Load Architecture Diagram
                </button>
                <button
                  type="button"
                  onClick={() => loadSampleImage('flowchart')}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs text-cyan-300 border border-cyan-500/30 transition-colors"
                >
                  Load State Diagram
                </button>
              </div>
            </div>
          ) : (
            /* Active Image Preview */
            <div className="glass-card rounded-2xl p-4 border border-white/[0.08] space-y-3 relative shadow-xl">
              <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
                <div className="flex items-center gap-2 min-w-0">
                  <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-medium text-slate-200 truncate">
                    {fileName}
                  </span>
                  <span className="text-[11px] font-mono text-slate-300">
                    ({fileSize})
                  </span>
                </div>

                <button
                  onClick={handleRemoveImage}
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-colors cursor-pointer"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Image Canvas / Container with scanning animation when analyzing */}
              <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800 max-h-[360px] flex items-center justify-center">
                <img
                  src={imageSrc}
                  alt="Analysis Preview"
                  className="max-h-[340px] w-auto object-contain"
                />

                {isAnalyzing && (
                  <div className="absolute inset-0 bg-amber-500/10 pointer-events-none flex flex-col justify-center">
                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent shadow-[0_0_15px_#f59e0b] animate-bounce" />
                    <div className="absolute top-3 left-3 flex items-center gap-2 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md text-[11px] font-mono text-amber-300 border border-amber-500/30">
                      <Scan className="w-3.5 h-3.5 animate-spin" />
                      <span>Neural Vision Scanning...</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Prompt & Analysis Output */}
        <div className="lg:col-span-6 space-y-4 flex flex-col">
          <div className="glass-card rounded-2xl p-5 border border-white/[0.08] space-y-4 shadow-xl">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
              Perception Directive / Query
            </label>
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="What specifically should be extracted or identified from this image?"
              className="w-full px-4 py-2.5 rounded-xl glass-input text-xs sm:text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40 resize-none leading-relaxed"
            />

            <button
              onClick={handleAnalyze}
              disabled={!imageSrc || isAnalyzing}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 disabled:opacity-30 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-950/40"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Processing Vision Stream...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Analyze Image</span>
                </>
              )}
            </button>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Analysis Results Area */}
          {analysisResult && (
            <div className="flex-1 glass-card rounded-2xl p-5 border border-white/[0.08] space-y-3 shadow-xl">
              <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-300">
                  <Sparkles className="w-4 h-4" />
                  <span>Vision Analysis Output</span>
                </div>
                <button
                  onClick={handleCopyResult}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition-colors cursor-pointer"
                >
                  {copiedResult ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <div className="text-xs sm:text-sm text-slate-200 leading-relaxed max-h-[380px] overflow-y-auto pr-1">
                <FormattedResponse content={analysisResult} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
