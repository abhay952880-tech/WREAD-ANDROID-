import React, { useState } from 'react';
import { 
  MessageSquare, 
  Bot, 
  Search, 
  Image as ImageIcon, 
  Brain, 
  CheckSquare, 
  ArrowRight, 
  Sparkles,
  Zap,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { ActiveWorkspace } from '../types';
import { AiOrb } from './AiOrb';

interface HomeWorkspaceProps {
  onSelectWorkspace: (ws: ActiveWorkspace) => void;
  onQuickPromptSubmit?: (prompt: string) => void;
}

export const HomeWorkspace: React.FC<HomeWorkspaceProps> = ({
  onSelectWorkspace,
  onQuickPromptSubmit,
}) => {
  const [quickInput, setQuickInput] = useState('');
  const [orbState, setOrbState] = useState<'idle' | 'breathing' | 'processing'>('idle');

  const capabilities = [
    {
      id: 'chat' as ActiveWorkspace,
      title: 'Ask AI',
      tagline: 'Deep conversational reasoning & code intelligence',
      icon: MessageSquare,
      accent: 'from-cyan-500/20 to-blue-600/20',
      border: 'hover:border-cyan-500/50',
      iconColor: 'text-cyan-400',
    },
    {
      id: 'agent' as ActiveWorkspace,
      title: 'Agent Mode',
      tagline: 'Autonomous multi-step planning & execution loops',
      icon: Bot,
      accent: 'from-purple-500/20 to-indigo-600/20',
      border: 'hover:border-purple-500/50',
      iconColor: 'text-purple-400',
    },
    {
      id: 'research' as ActiveWorkspace,
      title: 'Web Research',
      tagline: 'Synthesis, key findings & domain source citations',
      icon: Search,
      accent: 'from-emerald-500/20 to-teal-600/20',
      border: 'hover:border-emerald-500/50',
      iconColor: 'text-emerald-400',
    },
    {
      id: 'vision' as ActiveWorkspace,
      title: 'Analyze Image',
      tagline: 'Multimodal perception, diagrams & document parsing',
      icon: ImageIcon,
      accent: 'from-amber-500/20 to-orange-600/20',
      border: 'hover:border-amber-500/50',
      iconColor: 'text-amber-400',
    },
    {
      id: 'memory' as ActiveWorkspace,
      title: 'Memory',
      tagline: 'Persistent user preferences, instructions & context',
      icon: Brain,
      accent: 'from-pink-500/20 to-rose-600/20',
      border: 'hover:border-pink-500/50',
      iconColor: 'text-pink-400',
    },
    {
      id: 'tasks' as ActiveWorkspace,
      title: 'Tasks',
      tagline: 'Background execution queues & milestone status',
      icon: CheckSquare,
      accent: 'from-blue-500/20 to-cyan-600/20',
      border: 'hover:border-blue-500/50',
      iconColor: 'text-blue-400',
    },
  ];

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    setOrbState('processing');
    setTimeout(() => {
      if (onQuickPromptSubmit) {
        onQuickPromptSubmit(quickInput.trim());
      } else {
        onSelectWorkspace('chat');
      }
    }, 400);
  };

  const samplePrompts = [
    'Synthesize current developments in frontier AI reasoning models',
    'Architect an autonomous microservice with resilient failure states',
    'Analyze technical trade-offs between dense and MoE architectures',
  ];

  return (
    <div className="flex-1 w-full max-w-6xl mx-auto px-4 py-8 sm:py-12 flex flex-col items-center justify-center">
      {/* Hero Branding Header */}
      <div className="text-center space-y-2 mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/80 border border-white/[0.08] text-xs text-slate-300 mb-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>WREAD Autonomous Intelligence OS</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight bg-gradient-to-b from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
          WREAD
        </h1>

        <p className="text-lg sm:text-xl font-medium tracking-tight text-cyan-300/90">
          "Your Personal AI Agent"
        </p>
      </div>

      {/* Central Animated AI Orb/Core */}
      <div className="my-4 sm:my-6 flex flex-col items-center">
        <AiOrb
          state={orbState}
          size="lg"
          onClick={() => {
            setOrbState(prev => (prev === 'idle' ? 'processing' : 'idle'));
          }}
        />
        <span className="text-[11px] text-slate-300 mt-3 font-mono tracking-wider uppercase">
          Neural Core Active • Click to cycle states
        </span>
      </div>

      {/* Prompt / Search Question */}
      <div className="w-full max-w-2xl text-center space-y-4 mb-8">
        <h2 className="text-xl sm:text-2xl font-semibold text-slate-100 tracking-tight">
          What can I help you with?
        </h2>

        {/* Quick input bar */}
        <form onSubmit={handleQuickSubmit} className="relative w-full">
          <input
            type="text"
            value={quickInput}
            onChange={(e) => setQuickInput(e.target.value)}
            placeholder="Ask a question, command an agent, or describe a task..."
            className="w-full px-5 py-3.5 pr-28 rounded-2xl glass-input text-sm sm:text-base text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all shadow-xl"
          />
          <button
            type="submit"
            disabled={!quickInput.trim()}
            className="absolute right-2 top-2 bottom-2 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-30 disabled:pointer-events-none text-white font-medium text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <span>Proceed</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Prompt suggestions */}
        <div className="flex flex-wrap justify-center gap-2 pt-1">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuickInput(p);
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-900/60 hover:bg-slate-800/80 border border-white/[0.06] text-xs text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer text-left truncate max-w-xs"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Capability Cards Grid (6 items as required) */}
      <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4 mt-2">
        {capabilities.map((cap) => {
          const Icon = cap.icon;
          return (
            <div
              key={cap.id}
              onClick={() => onSelectWorkspace(cap.id)}
              className={`group p-4 sm:p-5 rounded-2xl glass-card border border-white/[0.08] ${cap.border} transition-all duration-200 cursor-pointer relative overflow-hidden flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-xl hover:shadow-cyan-500/5`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`p-2.5 rounded-xl bg-slate-900/90 border border-white/[0.08] ${cap.iconColor}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
              </div>

              <div>
                <h3 className="text-base font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors">
                  {cap.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {cap.tagline}
                </p>
              </div>

              {/* Subtle ambient light splash in corner */}
              <div className={`absolute -right-8 -bottom-8 w-24 h-24 rounded-full bg-gradient-to-br ${cap.accent} blur-xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity`} />
            </div>
          );
        })}
      </div>

      {/* Trust & Architecture Pills */}
      <div className="mt-12 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-300">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Zero Client Secrets</span>
        </div>
        <span>•</span>
        <div className="flex items-center gap-1.5">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span>Kimi-K3 / Modal Proxy</span>
        </div>
        <span>•</span>
        <div className="flex items-center gap-1.5">
          <Zap className="w-4 h-4 text-amber-400" />
          <span>Autonomous Loop Ready</span>
        </div>
      </div>
    </div>
  );
};
