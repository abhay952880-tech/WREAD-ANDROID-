import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Play, 
  Square, 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertTriangle, 
  Terminal, 
  Globe, 
  FileCode, 
  Database, 
  Cpu, 
  Sparkles,
  Layers,
  Copy,
  Check,
  RotateCcw,
  SkipForward,
  History,
  Trash2,
  Brain,
  X,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  ImageIcon,
  Paperclip,
  Eye
} from 'lucide-react';
import { AgentTask, AgentStep, AgentToolType, AgentHistoryItem, Memory } from '../types';
import { sendChatMessage, performWebResearch, analyzeImageFile } from '../services/api';
import { StorageService } from '../services/storage';
import { findRelevantMemories, formatRelevantMemoriesContext } from '../services/memoryMatcher';
import { FormattedResponse } from './FormattedResponse';
import { VoiceAssistantService } from '../services/voiceService';

interface AgentWorkspaceProps {
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
}

export const AgentWorkspace: React.FC<AgentWorkspaceProps> = ({
  initialPrompt,
  onClearInitialPrompt,
}) => {
  const [taskPrompt, setTaskPrompt] = useState(initialPrompt || '');
  const [activeTask, setActiveTask] = useState<AgentTask | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [copiedResult, setCopiedResult] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [historyList, setHistoryList] = useState<AgentHistoryItem[]>([]);
  const [attachedMemories, setAttachedMemories] = useState<Memory[]>([]);
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({});
  const [isRecording, setIsRecording] = useState(false);
  const [interimVoiceText, setInterimVoiceText] = useState('');
  const [isSpeakingResult, setIsSpeakingResult] = useState(false);
  const [agentImage, setAgentImage] = useState<{
    name: string;
    type: string;
    base64: string;
    size?: number;
  } | null>(null);

  const abortExecutionRef = useRef<boolean>(false);
  const activeTaskRef = useRef<AgentTask | null>(null);
  const agentImageInputRef = useRef<HTMLInputElement>(null);

  const handleAgentImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];

    // Max 10MB
    if (file.size > 10 * 1024 * 1024) {
      alert('Image exceeds 10 MB limit.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAgentImage({
        name: file.name,
        type: file.type || 'image/jpeg',
        base64: reader.result as string,
        size: file.size,
      });
    };
    reader.readAsDataURL(file);
    if (agentImageInputRef.current) agentImageInputRef.current.value = '';
  };

  // Sync ref with state
  useEffect(() => {
    activeTaskRef.current = activeTask;
  }, [activeTask]);

  // Load history on mount
  useEffect(() => {
    setHistoryList(StorageService.getAgentHistory());
  }, []);

  // Handle initialPrompt changes (e.g. from Chat "Run with Agent")
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      setTaskPrompt(initialPrompt.trim());
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt, onClearInitialPrompt]);

  // Clean up voice on unmount
  useEffect(() => {
    return () => {
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.stopListening();
    };
  }, []);

  // Voice dictation toggle for agent task prompt
  const toggleSpeechRecognition = () => {
    if (isRecording) {
      VoiceAssistantService.stopListening();
      setIsRecording(false);
      setInterimVoiceText('');
      return;
    }

    if (!VoiceAssistantService.isSTTSupported()) {
      return;
    }

    VoiceAssistantService.stopSpeaking();
    setIsSpeakingResult(false);

    const settings = StorageService.getSettings();
    VoiceAssistantService.startListening(
      {
        onStart: () => {
          setIsRecording(true);
        },
        onInterim: (interim) => {
          setInterimVoiceText(interim);
        },
        onFinal: (finalText) => {
          setTaskPrompt(prev => (prev ? `${prev.trim()} ${finalText}` : finalText));
          setInterimVoiceText('');
        },
        onError: () => {
          setIsRecording(false);
          setInterimVoiceText('');
        },
        onEnd: () => {
          setIsRecording(false);
          setInterimVoiceText('');
        },
      },
      settings?.voiceLanguage || 'auto'
    );
  };

  // Toggle Read Aloud for agent deliverable
  const handleToggleSpeakResult = () => {
    if (!activeTask) return;
    const textToSpeak = activeTask.finalResult || activeTask.result;
    if (!textToSpeak) return;

    if (isSpeakingResult) {
      VoiceAssistantService.stopSpeaking();
      setIsSpeakingResult(false);
    } else {
      const settings = StorageService.getSettings();
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.speak(textToSpeak, {
        language: settings?.voiceLanguage || 'auto',
        rate: settings?.speechRate || 1.0,
        onStart: () => setIsSpeakingResult(true),
        onEnd: () => setIsSpeakingResult(false),
        onError: () => setIsSpeakingResult(false),
      });
    }
  };

  const toolMetadata: Record<AgentToolType, { name: string; icon: any; isLive: boolean; desc: string }> = {
    reasoning: {
      name: 'Neural Reasoning Kernel',
      icon: Sparkles,
      isLive: true,
      desc: 'Kimi-K3 upstream inference engine',
    },
    research: {
      name: 'Deep Research Synthesizer',
      icon: Cpu,
      isLive: true,
      desc: 'WREAD multi-stage reasoning and research',
    },
    automation: {
      name: 'Workflow Orchestrator',
      icon: Bot,
      isLive: true,
      desc: 'Autonomous multi-step sequence loop',
    },
    web_search: {
      name: 'Web Search Engine',
      icon: Globe,
      isLive: false,
      desc: 'Web indexing sandbox',
    },
    file_operations: {
      name: 'File System Operations',
      icon: FileCode,
      isLive: false,
      desc: 'Local file read/write sandbox',
    },
    data_analysis: {
      name: 'Data Analysis Pipeline',
      icon: Database,
      isLive: false,
      desc: 'Statistical engine sandbox',
    },
    api_call: {
      name: 'External API Dispatcher',
      icon: Layers,
      isLive: false,
      desc: 'REST/GraphQL webhook bridge',
    },
    vision_analysis: {
      name: 'Vision & Multimodal Inspector',
      icon: ImageIcon,
      isLive: true,
      desc: 'Multimodal image OCR, diagrams, and error diagnostics',
    },
  };

  const sampleTasks = [
    'Inspect this UI screenshot, diagnose visual bugs, and write a remediation plan',
    'Create a study plan for SSC preparation and organize it into daily steps',
    'Explain photosynthesis in simple Hindi',
    'Make a 7-day SSC study plan',
    'Formulate a zero-downtime database migration strategy',
  ];

  // Helper to persist task to history
  const persistTaskHistory = (taskToSave: AgentTask) => {
    const historyItem: AgentHistoryItem = {
      id: taskToSave.id,
      task: taskToSave.task || taskToSave.prompt,
      status: taskToSave.status,
      createdAt: taskToSave.createdAt,
      completedAt: taskToSave.completedAt || Date.now(),
      steps: taskToSave.steps,
      finalResult: taskToSave.finalResult || taskToSave.result,
    };
    StorageService.saveAgentHistoryItem(historyItem);
    setHistoryList(StorageService.getAgentHistory());
  };

  // 1. Task Planning Phase (Requirement 2 & 14)
  const generatePlanWithAI = async (prompt: string, relevantMemories: Memory[]): Promise<AgentStep[]> => {
    const memoryContext = formatRelevantMemoriesContext(relevantMemories);

    const planningMessages = [
      {
        role: 'system' as const,
        content: `You are WREAD Autonomous Agent Planning Kernel.
Your objective is to analyze the user's task and formulate a structured, logical sequence of 3 to 5 distinct execution milestones.

SAFETY DIRECTIVE:
You must NOT generate steps for dangerous, destructive, financial, medical, or illegal actions. Maintain an objective, educational, analytical, and structured planning scope.

${memoryContext ? `RELEVANT MEMORY DIRECTIVES:\n${memoryContext}\n` : ''}

CRITICAL: Return ONLY a valid JSON array of objects. Do not include markdown formatting or commentary outside the JSON.
Each object must have:
- "title": concise milestone title (e.g. "Step 1: Understand Objectives & Prerequisites")
- "description": specific, actionable objective for this milestone

Example JSON format:
[
  { "title": "Understand Scope and Core Objectives", "description": "Analyze syllabus boundaries, constraints, and target outcomes." },
  { "title": "Synthesize Daily Breakdown and Strategy", "description": "Formulate organized daily routine and milestone allocations." },
  { "title": "Compile Actionable Practice Resources and Review", "description": "Assemble curated mock tests, revision cycles, and final guidelines." }
]`,
      },
      {
        role: 'user' as const,
        content: `Formulate a structured execution plan for: "${prompt}"`,
      },
    ];

    try {
      const response = await sendChatMessage(planningMessages, {
        temperature: 0.3,
      });

      // Parse JSON from response
      const raw = response.content.trim();
      const jsonMatch = raw.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((item: any, idx: number) => ({
            id: `step_${idx + 1}_${Date.now()}`,
            title: item.title || `Step ${idx + 1}`,
            description: item.description || 'Analyze and execute milestone.',
            tool: idx === 0 ? 'reasoning' : idx === 1 ? 'research' : 'automation',
            toolConnected: true,
            status: 'pending',
            timestamp: Date.now(),
          }));
        }
      }
    } catch (err) {
      console.warn('[Agent Planning] AI plan parse fallback:', err);
    }

    // Fallback structured plan if AI parsing fails
    return [
      {
        id: `step_1_${Date.now()}`,
        title: 'Understand Objective & Environmental Scope',
        description: `Analyze core constraints, prerequisites, and goals for: "${prompt}".`,
        tool: 'reasoning',
        toolConnected: true,
        status: 'pending',
        timestamp: Date.now(),
      },
      {
        id: `step_2_${Date.now()}`,
        title: 'Information Gathering & Concept Synthesis',
        description: 'Collate foundational domain knowledge, methodologies, and structured components.',
        tool: 'research',
        toolConnected: true,
        status: 'pending',
        timestamp: Date.now(),
      },
      {
        id: `step_3_${Date.now()}`,
        title: 'Milestone Execution & Detailed Solution Formulation',
        description: 'Formulate in-depth, practical, step-by-step deliverable modules.',
        tool: 'automation',
        toolConnected: true,
        status: 'pending',
        timestamp: Date.now(),
      },
      {
        id: `step_4_${Date.now()}`,
        title: 'Verification, Synthesis & Quality Review',
        description: 'Verify all constraints are satisfied and construct final authoritative deliverable.',
        tool: 'reasoning',
        toolConnected: true,
        status: 'pending',
        timestamp: Date.now(),
      },
    ];
  };

  // 2. Main Step-by-Step Execution Engine (Requirement 3, 4, 5, 15)
  const executePlanSequentially = async (
    task: AgentTask,
    startIndex: number = 0,
    relevantMemories: Memory[] = []
  ) => {
    setIsRunning(true);
    abortExecutionRef.current = false;

    const memoryContext = formatRelevantMemoriesContext(relevantMemories);
    const steps = [...task.steps];
    const cumulativeContext: Array<{ title: string; output: string }> = [];

    // Prepopulate cumulative context from already completed steps (in case of resume/retry)
    for (let j = 0; j < startIndex; j++) {
      if (steps[j].status === 'completed' && steps[j].output) {
        cumulativeContext.push({
          title: steps[j].title,
          output: steps[j].output!,
        });
      }
    }

    for (let i = startIndex; i < steps.length; i++) {
      // Check if user stopped agent
      if (abortExecutionRef.current) {
        const stoppedTask: AgentTask = {
          ...activeTaskRef.current!,
          status: 'stopped',
          logs: [
            ...(activeTaskRef.current?.logs || []),
            {
              timestamp: Date.now(),
              message: 'Execution stopped by user directive.',
              type: 'warn',
            },
          ],
        };
        setActiveTask(stoppedTask);
        persistTaskHistory(stoppedTask);
        setIsRunning(false);
        return;
      }

      // If step was already marked skipped, proceed
      if (steps[i].status === 'skipped') {
        continue;
      }

      // Mark step as running
      steps[i] = { ...steps[i], status: 'running' };
      setActiveTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          status: 'executing',
          currentStepIndex: i,
          steps: [...steps],
          logs: [
            ...prev.logs,
            {
              timestamp: Date.now(),
              message: `Executing Step ${i + 1}/${steps.length}: "${steps[i].title}"`,
              type: 'tool',
            },
          ],
        };
      });

      // Automatically expand running step
      setExpandedSteps(prev => ({ ...prev, [steps[i].id]: true }));

      // Execute step using existing Kimi-K3 backend or Web Research Engine
      try {
        let stepOutput = '';

        // Check if this step is a Web Research request
        const isWebResearchStep =
          steps[i].tool === 'research' ||
          steps[i].title.toLowerCase().includes('research') ||
          steps[i].title.toLowerCase().includes('search') ||
          steps[i].title.toLowerCase().includes('web');

        if (isWebResearchStep) {
          try {
            setActiveTask(prev => {
              if (!prev) return null;
              return {
                ...prev,
                logs: [
                  ...prev.logs,
                  {
                    timestamp: Date.now(),
                    message: `[Web Research Engine] Querying public web sources for: "${steps[i].title}"`,
                    type: 'tool',
                  },
                ],
              };
            });

            const searchQuery = `${task.prompt}: ${steps[i].title}`;
            const resResult = await performWebResearch(searchQuery, 'quick');

            if (resResult.sources && resResult.sources.length > 0) {
              const sourcesText = resResult.sources
                .map((s, idx) => `[${idx + 1}] ${s.title} — ${s.url}`)
                .join('\n');
              stepOutput = `${resResult.finalAnswer || resResult.summary}\n\n**Retrieved Sources (${resResult.sources.length}):**\n${sourcesText}`;
            } else {
              stepOutput = resResult.finalAnswer || resResult.summary;
            }

            setActiveTask(prev => {
              if (!prev) return null;
              return {
                ...prev,
                logs: [
                  ...prev.logs,
                  {
                    timestamp: Date.now(),
                    message: `[Web Research Engine] Sourced ${resResult.sources?.length || 0} public web references.`,
                    type: 'tool',
                  },
                ],
              };
            });
          } catch (researchErr) {
            console.warn('[Agent Web Research Fallback to LLM]:', researchErr);
          }
        }

        // Check if this step requires vision analysis with the attached image
        const isVisionStep =
          (steps[i].tool === 'vision_analysis' ||
            steps[i].title.toLowerCase().includes('image') ||
            steps[i].title.toLowerCase().includes('screenshot') ||
            steps[i].title.toLowerCase().includes('visual') ||
            steps[i].title.toLowerCase().includes('ui') ||
            (i === 0 && task.imageAttachment)) &&
          task.imageAttachment;

        if (!stepOutput && isVisionStep && task.imageAttachment) {
          try {
            setActiveTask(prev => {
              if (!prev) return null;
              return {
                ...prev,
                logs: [
                  ...prev.logs,
                  {
                    timestamp: Date.now(),
                    message: `[Vision Multimodal Engine] Analyzing image attachment (${task.imageAttachment?.name}) for: "${steps[i].title}"`,
                    type: 'tool',
                  },
                ],
              };
            });

            const visionResult = await analyzeImageFile(
              task.imageAttachment.base64,
              `Task: "${task.prompt}"\nMilestone: "${steps[i].title}" - ${steps[i].description}\nPlease analyze the attached image thoroughly to fulfill this milestone.`,
              task.imageAttachment.name
            );

            stepOutput = visionResult.content;
          } catch (visionErr) {
            console.warn('[Agent Vision Step Fallback]:', visionErr);
          }
        }

        // If not a research/vision step or if previous tools returned empty, execute via LLM prompt
        if (!stepOutput) {
          const stepMessages = [
            {
              role: 'system' as const,
              content: `You are WREAD Autonomous Agent Kernel executing an sequential operational plan.
Original User Task: "${task.prompt}"

Full Execution Plan:
${steps.map((s, idx) => `Milestone ${idx + 1}: ${s.title} — ${s.description}`).join('\n')}

${memoryContext ? `Relevant User Memory Directives:\n${memoryContext}\n` : ''}

${
  cumulativeContext.length > 0
    ? `Completed Milestones So Far:\n${cumulativeContext
        .map(c => `[Milestone: ${c.title}]\n${c.output}`)
        .join('\n\n')}\n`
    : ''
}

CURRENT MILESTONE OBJECTIVE:
Step ${i + 1} of ${steps.length}: "${steps[i].title}"
Goal: "${steps[i].description}"

SAFETY DIRECTIVE:
Do NOT perform or suggest dangerous, destructive, legal, medical, or financial actions. Focus on practical, structured reasoning and high-quality educational/analytical content.

Deliver a thorough, clear, high-utility execution result for this specific milestone. Do not stop at high-level summaries; provide full, concrete, practical details.`,
            },
            {
              role: 'user' as const,
              content: `Execute Milestone ${i + 1}: ${steps[i].title}`,
              attachments: task.imageAttachment ? [task.imageAttachment] : undefined,
            },
          ];

          const response = await sendChatMessage(stepMessages, {
            temperature: 0.5,
          });
          stepOutput = response.content;
        }

        // Check if stopped while awaiting response
        if (abortExecutionRef.current) {
          steps[i] = { ...steps[i], status: 'pending' };
          const stoppedTask: AgentTask = {
            ...activeTaskRef.current!,
            status: 'stopped',
            steps: [...steps],
            logs: [
              ...(activeTaskRef.current?.logs || []),
              {
                timestamp: Date.now(),
                message: `Stopped before committing Step ${i + 1}.`,
                type: 'warn',
              },
            ],
          };
          setActiveTask(stoppedTask);
          persistTaskHistory(stoppedTask);
          setIsRunning(false);
          return;
        }

        // Mark step completed
        steps[i] = {
          ...steps[i],
          status: 'completed',
          output: stepOutput,
        };

        cumulativeContext.push({
          title: steps[i].title,
          output: stepOutput,
        });

        setActiveTask(prev => {
          if (!prev) return null;
          return {
            ...prev,
            steps: [...steps],
            logs: [
              ...prev.logs,
              {
                timestamp: Date.now(),
                message: `Completed Step ${i + 1}: "${steps[i].title}"`,
                type: 'info',
              },
            ],
          };
        });
      } catch (err: any) {
        // Step Failed (Requirement 7: Show "Step failed", provide Retry, Skip, Stop Agent)
        const errorMsg = err.message || 'Execution error occurred.';
        steps[i] = {
          ...steps[i],
          status: 'failed',
          output: `Step failed: ${errorMsg}`,
        };

        const failedTask: AgentTask = {
          ...activeTaskRef.current!,
          status: 'failed',
          currentStepIndex: i,
          steps: [...steps],
          error: errorMsg,
          logs: [
            ...(activeTaskRef.current?.logs || []),
            {
              timestamp: Date.now(),
              message: `Step failed at Step ${i + 1}: ${errorMsg}`,
              type: 'error',
            },
          ],
        };

        setActiveTask(failedTask);
        persistTaskHistory(failedTask);
        setIsRunning(false);
        return;
      }
    }

    // 3. Final Result Synthesis (Requirement 8)
    try {
      setActiveTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          logs: [
            ...prev.logs,
            {
              timestamp: Date.now(),
              message: 'All milestones completed. Formulating comprehensive final synthesis...',
              type: 'info',
            },
          ],
        };
      });

      const synthesisMessages = [
        {
          role: 'system' as const,
          content: `You are WREAD Autonomous Agent Kernel.
All milestones for the user's complex task have been executed.
Original User Task: "${task.prompt}"

Milestone Results:
${cumulativeContext.map(c => `### ${c.title}\n${c.output}`).join('\n\n')}

Provide the definitive, comprehensive final deliverable for the user.
Organize it with clear headings, actionable steps, and polished Markdown formatting. Make it immediately useful, thorough, and complete.`,
        },
        {
          role: 'user' as const,
          content: `Synthesize the final deliverable for: "${task.prompt}"`,
        },
      ];

      const synthesisResponse = await sendChatMessage(synthesisMessages, {
        temperature: 0.4,
      });

      const finalDeliverable = synthesisResponse.content;

      const completedTask: AgentTask = {
        ...activeTaskRef.current!,
        status: 'completed',
        steps: [...steps],
        result: finalDeliverable,
        finalResult: finalDeliverable,
        completedAt: Date.now(),
        logs: [
          ...(activeTaskRef.current?.logs || []),
          {
            timestamp: Date.now(),
            message: 'Agent completed all milestones and deliverable synthesis.',
            type: 'info',
          },
        ],
      };

      setActiveTask(completedTask);
      persistTaskHistory(completedTask);
    } catch (err: any) {
      // If synthesis call fails, stitch cumulativeContext directly as fallback
      const fallbackResult = cumulativeContext
        .map(c => `### ${c.title}\n\n${c.output}`)
        .join('\n\n---\n\n');

      const completedTask: AgentTask = {
        ...activeTaskRef.current!,
        status: 'completed',
        steps: [...steps],
        result: fallbackResult,
        finalResult: fallbackResult,
        completedAt: Date.now(),
        logs: [
          ...(activeTaskRef.current?.logs || []),
          {
            timestamp: Date.now(),
            message: 'Agent completed with compiled milestone outputs.',
            type: 'info',
          },
        ],
      };

      setActiveTask(completedTask);
      persistTaskHistory(completedTask);
    } finally {
      setIsRunning(false);
    }
  };

  // Start Agent Directive
  const handleStartAgent = async () => {
    const trimmed = taskPrompt.trim();
    if (!trimmed || isRunning) return;

    abortExecutionRef.current = false;
    setIsRunning(true);

    // Memory Integration (Requirement 10): Search for relevant memories
    const allMemories = StorageService.getMemories();
    const relevant = findRelevantMemories(trimmed, allMemories);
    setAttachedMemories(relevant);

    const initialTask: AgentTask = {
      id: 'agent_' + Date.now(),
      task: trimmed,
      prompt: trimmed,
      imageAttachment: agentImage || undefined,
      status: 'planning',
      steps: [],
      currentStepIndex: 0,
      logs: [
        {
          timestamp: Date.now(),
          message: `Agent initialized for task: "${trimmed}"`,
          type: 'info',
        },
        ...(agentImage
          ? [
              {
                timestamp: Date.now(),
                message: `Attached visual payload: "${agentImage.name}" (${(
                  agentImage.size ? (agentImage.size / 1024).toFixed(0) + ' KB' : 'image'
                )})`,
                type: 'tool' as const,
              },
            ]
          : []),
        {
          timestamp: Date.now(),
          message:
            relevant.length > 0
              ? `Attached ${relevant.length} relevant memory directive(s): ${relevant
                  .map(m => `"${m.key}"`)
                  .join(', ')}`
              : 'No matching memory directives found. Operating with standard parameters.',
          type: 'info',
        },
        {
          timestamp: Date.now(),
          message: 'Decomposing task into structured sequential plan...',
          type: 'tool',
        },
      ],
      createdAt: Date.now(),
    };

    setActiveTask(initialTask);

    // Step 1: Formulate structured plan (Requirement 2: Display plan before execution)
    const generatedSteps = await generatePlanWithAI(trimmed, relevant);

    // Check if user stopped during planning
    if (abortExecutionRef.current) {
      const stoppedTask: AgentTask = {
        ...initialTask,
        status: 'stopped',
        steps: generatedSteps,
        logs: [
          ...initialTask.logs,
          {
            timestamp: Date.now(),
            message: 'Agent stopped by user during planning.',
            type: 'warn',
          },
        ],
      };
      setActiveTask(stoppedTask);
      persistTaskHistory(stoppedTask);
      setIsRunning(false);
      return;
    }

    const taskWithPlan: AgentTask = {
      ...initialTask,
      status: 'planning',
      steps: generatedSteps,
      logs: [
        ...initialTask.logs,
        {
          timestamp: Date.now(),
          message: `Plan formulated with ${generatedSteps.length} milestones. Initiating sequential execution...`,
          type: 'info',
        },
      ],
    };

    setActiveTask(taskWithPlan);

    // Automatically expand all step cards by default
    const initialExpanded: Record<string, boolean> = {};
    generatedSteps.forEach(s => {
      initialExpanded[s.id] = true;
    });
    setExpandedSteps(initialExpanded);

    // Step 2: Sequentially execute steps
    await executePlanSequentially(taskWithPlan, 0, relevant);
  };

  // Stop Agent (Requirement 6)
  const handleStopAgent = () => {
    abortExecutionRef.current = true;
    if (activeTask) {
      const stoppedTask: AgentTask = {
        ...activeTask,
        status: 'stopped',
        logs: [
          ...activeTask.logs,
          {
            timestamp: Date.now(),
            message: 'Stop signal received from user. Halting execution pipeline.',
            type: 'warn',
          },
        ],
      };
      setActiveTask(stoppedTask);
      persistTaskHistory(stoppedTask);
    }
    setIsRunning(false);
  };

  // Retry Failed Step (Requirement 7)
  const handleRetryStep = async (stepIdx: number) => {
    if (!activeTask || isRunning) return;
    const updatedSteps = [...activeTask.steps];
    updatedSteps[stepIdx] = {
      ...updatedSteps[stepIdx],
      status: 'pending',
      output: undefined,
    };

    const taskToResume: AgentTask = {
      ...activeTask,
      status: 'executing',
      currentStepIndex: stepIdx,
      steps: updatedSteps,
      error: undefined,
      logs: [
        ...activeTask.logs,
        {
          timestamp: Date.now(),
          message: `Retrying Step ${stepIdx + 1}: "${updatedSteps[stepIdx].title}"`,
          type: 'info',
        },
      ],
    };

    setActiveTask(taskToResume);
    await executePlanSequentially(taskToResume, stepIdx, attachedMemories);
  };

  // Skip Failed Step (Requirement 7)
  const handleSkipStep = async (stepIdx: number) => {
    if (!activeTask || isRunning) return;
    const updatedSteps = [...activeTask.steps];
    updatedSteps[stepIdx] = {
      ...updatedSteps[stepIdx],
      status: 'skipped',
      output: 'Milestone skipped by user.',
    };

    const nextIdx = stepIdx + 1;
    const taskToResume: AgentTask = {
      ...activeTask,
      status: nextIdx < updatedSteps.length ? 'executing' : 'planning',
      currentStepIndex: nextIdx,
      steps: updatedSteps,
      error: undefined,
      logs: [
        ...activeTask.logs,
        {
          timestamp: Date.now(),
          message: `Skipped Step ${stepIdx + 1}: "${updatedSteps[stepIdx].title}". Moving forward.`,
          type: 'warn',
        },
      ],
    };

    setActiveTask(taskToResume);
    await executePlanSequentially(taskToResume, nextIdx, attachedMemories);
  };

  // Copy Result
  const handleCopyResult = () => {
    const textToCopy = activeTask?.finalResult || activeTask?.result;
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopiedResult(true);
    setTimeout(() => setCopiedResult(false), 2000);
  };

  // Toggle step output expansion
  const toggleStepExpanded = (stepId: string) => {
    setExpandedSteps(prev => ({
      ...prev,
      [stepId]: !prev[stepId],
    }));
  };

  // Load task from history
  const handleOpenHistoryItem = (item: AgentHistoryItem) => {
    const restoredTask: AgentTask = {
      id: item.id,
      task: item.task,
      prompt: item.task,
      status: item.status,
      steps: item.steps,
      currentStepIndex: item.steps.length - 1,
      result: item.finalResult,
      finalResult: item.finalResult,
      completedAt: item.completedAt,
      logs: [
        {
          timestamp: item.createdAt,
          message: `Restored task record: "${item.task}"`,
          type: 'info',
        },
        {
          timestamp: item.completedAt || Date.now(),
          message: `Recorded status: ${item.status}`,
          type: 'info',
        },
      ],
      createdAt: item.createdAt,
    };
    setActiveTask(restoredTask);
    setTaskPrompt(item.task);
    setIsHistoryOpen(false);
  };

  const handleDeleteHistoryItem = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    StorageService.deleteAgentHistoryItem(id);
    setHistoryList(StorageService.getAgentHistory());
  };

  const handleClearHistory = () => {
    if (confirm('Clear all saved agent task history?')) {
      StorageService.clearAgentHistory();
      setHistoryList([]);
    }
  };

  // Progress calculations
  const totalSteps = activeTask?.steps.length || 0;
  const completedStepsCount =
    activeTask?.steps.filter(s => s.status === 'completed').length || 0;
  const skippedStepsCount =
    activeTask?.steps.filter(s => s.status === 'skipped').length || 0;
  const failedStepsCount =
    activeTask?.steps.filter(s => s.status === 'failed').length || 0;

  const progressPercent =
    totalSteps > 0
      ? Math.round(((completedStepsCount + skippedStepsCount) / totalSteps) * 100)
      : 0;

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-950/70 border border-purple-500/30 flex items-center justify-center">
              <Bot className="w-5 h-5 text-purple-400" />
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Agent Mode
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-purple-950/60 border border-purple-500/30 text-purple-300 text-xs font-mono">
              Autonomous
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Formulate structured multi-step plans and execute sequentially via Kimi-K3 reasoning.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* History Button (Requirement 9) */}
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-white/[0.08] text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="View saved agent tasks"
          >
            <History className="w-3.5 h-3.5 text-purple-400" />
            <span>History</span>
            {historyList.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-purple-900/60 text-purple-300 text-[10px] font-mono">
                {historyList.length}
              </span>
            )}
          </button>

          {/* Current Task Status Badge (Requirement 1 & 8) */}
          {activeTask && (
            <div className="flex items-center gap-2">
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold capitalize flex items-center gap-1.5 ${
                  activeTask.status === 'completed'
                    ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40'
                    : activeTask.status === 'executing'
                    ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-500/40 animate-pulse'
                    : activeTask.status === 'planning'
                    ? 'bg-purple-950/70 text-purple-300 border border-purple-500/40 animate-pulse'
                    : activeTask.status === 'failed'
                    ? 'bg-rose-950/70 text-rose-300 border border-rose-500/40'
                    : activeTask.status === 'stopped'
                    ? 'bg-amber-950/70 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-900 text-slate-300 border border-slate-700'
                }`}
              >
                {activeTask.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                {activeTask.status === 'executing' && (
                  <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                )}
                {activeTask.status === 'failed' && <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />}
                <span>
                  {activeTask.status === 'completed'
                    ? 'Agent completed'
                    : activeTask.status === 'executing'
                    ? `Running Step ${(activeTask.currentStepIndex || 0) + 1}/${activeTask.steps.length}`
                    : activeTask.status === 'planning'
                    ? 'Planning Task...'
                    : activeTask.status === 'stopped'
                    ? 'Task Stopped'
                    : activeTask.status === 'failed'
                    ? 'Step failed'
                    : activeTask.status}
                </span>
              </span>

              {activeTask.imageAttachment && (
                <span className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-purple-500/30 text-xs text-purple-300">
                  <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                  <span className="truncate max-w-[120px] font-mono">{activeTask.imageAttachment.name}</span>
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Task Input Section (Requirement 1 & 15) */}
      <div className="glass-card rounded-2xl p-5 border border-white/[0.08] space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-semibold text-slate-200">
            What should WREAD do?
          </label>
          {attachedMemories.length > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-purple-300 bg-purple-950/50 px-2.5 py-0.5 rounded-full border border-purple-500/20">
              <Brain className="w-3 h-3 text-purple-400" />
              <span>{attachedMemories.length} relevant memories active</span>
            </div>
          )}
        </div>

        {/* Voice recording interim status indicator */}
        {isRecording && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-xs text-purple-200 animate-pulse">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
            </span>
            <span className="font-semibold text-purple-300">Listening to agent task:</span>
            <span className="italic truncate text-slate-300">
              {interimVoiceText || 'Speak task now... (Tap mic to finish)'}
            </span>
          </div>
        )}

        {/* Attached Image Preview */}
        {agentImage && (
          <div className="flex items-center gap-3 p-2 px-3 rounded-xl bg-purple-950/40 border border-purple-500/30 max-w-md">
            <img
              src={agentImage.base64}
              alt={agentImage.name}
              className="w-10 h-10 object-cover rounded-lg border border-purple-500/40 shrink-0"
            />
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-xs font-semibold text-purple-200 truncate">{agentImage.name}</span>
              <span className="text-[10px] text-purple-300/80">
                {agentImage.size ? (agentImage.size / 1024).toFixed(0) + ' KB' : 'Image'} • Vision Attached
              </span>
            </div>
            <button
              type="button"
              onClick={() => setAgentImage(null)}
              className="p-1 text-slate-400 hover:text-rose-400 cursor-pointer"
              title="Remove attached image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1 flex items-center">
            {/* Hidden file input for agent image attachment */}
            <input
              type="file"
              ref={agentImageInputRef}
              onChange={handleAgentImageSelect}
              className="hidden"
              accept="image/jpeg,image/png,image/webp,image/jpg"
            />

            <input
              type="text"
              disabled={isRunning}
              value={taskPrompt}
              onChange={(e) => setTaskPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !isRunning) handleStartAgent();
              }}
              placeholder={isRecording ? "Listening to voice..." : "e.g. Inspect this UI screenshot, diagnose visual bugs, or create an operational plan..."}
              className="w-full pl-4 pr-20 py-3 rounded-xl glass-input text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500/40"
            />

            <div className="absolute right-2.5 flex items-center gap-1">
              {/* Image attachment button */}
              <button
                type="button"
                disabled={isRunning}
                onClick={() => agentImageInputRef.current?.click()}
                className="p-1.5 rounded-lg text-slate-400 hover:text-purple-300 hover:bg-slate-900/60 transition-colors cursor-pointer disabled:opacity-40"
                title="Attach image for agent visual inspection"
              >
                <ImageIcon className="w-4 h-4" />
              </button>

              {/* Voice button */}
              <button
                type="button"
                onClick={toggleSpeechRecognition}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isRecording
                    ? 'text-rose-400 bg-rose-950/60 animate-pulse'
                    : 'text-slate-400 hover:text-purple-300 hover:bg-slate-900/60'
                }`}
                title={isRecording ? 'Stop voice input' : 'Speak agent task'}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex gap-2 shrink-0">
            {isRunning ? (
              /* Stop Agent Button (Requirement 6) */
              <button
                onClick={handleStopAgent}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white font-medium text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-rose-900/20"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Stop Agent</span>
              </button>
            ) : (
              /* Start Agent Button (Requirement 1 & 15) */
              <button
                onClick={handleStartAgent}
                disabled={!taskPrompt.trim() && !agentImage}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 text-white font-medium text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-purple-900/30"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Start Agent</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-2 pt-1 items-center">
          <span className="text-xs text-slate-400 py-1">Quick presets:</span>
          {sampleTasks.map((st, i) => (
            <button
              key={i}
              disabled={isRunning}
              onClick={() => setTaskPrompt(st)}
              className="px-2.5 py-1 rounded-lg bg-slate-900/70 hover:bg-slate-800 text-xs text-slate-300 hover:text-purple-300 border border-white/[0.04] transition-colors cursor-pointer truncate max-w-xs"
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Memory Transparency Banner (Requirement 10) */}
      {attachedMemories.length > 0 && (
        <div className="p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="text-slate-300 font-medium">
              Context enriched with relevant WREAD memories:
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {attachedMemories.map(m => (
              <span
                key={m.id}
                className="px-2 py-0.5 rounded-md bg-purple-900/40 border border-purple-500/30 text-purple-200 text-[11px]"
                title={m.content}
              >
                {m.key}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Execution Progress & Milestones (Requirement 1, 2, 3) */}
      {activeTask && (
        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="glass-card p-4 rounded-xl border border-white/[0.06] space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-2">
                <span>Task Progress</span>
                <span className="text-slate-400 font-normal">
                  ({completedStepsCount}/{totalSteps} completed
                  {skippedStepsCount > 0 ? `, ${skippedStepsCount} skipped` : ''})
                </span>
              </span>
              <span className="font-mono text-cyan-400">{progressPercent}%</span>
            </div>
            <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-white/[0.05]">
              <div
                className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Step-by-Step Execution Timeline (Requirement 2 & 3) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <span>
                  {activeTask.status === 'planning' && activeTask.steps.length === 0
                    ? 'Formulating Plan...'
                    : `Execution Graph (${activeTask.steps.length} Milestones)`}
                </span>
              </h3>
              {activeTask.steps.length > 0 && (
                <span className="text-xs text-slate-400 font-mono">
                  Sequential Loop
                </span>
              )}
            </div>

            {/* Planning spinner if steps are not yet formulated */}
            {activeTask.status === 'planning' && activeTask.steps.length === 0 && (
              <div className="glass-card rounded-xl p-6 border border-purple-500/20 text-center space-y-3">
                <div className="w-8 h-8 mx-auto rounded-full border-2 border-purple-400 border-t-transparent animate-spin" />
                <p className="text-sm text-slate-300">
                  WREAD Agent is analyzing your objective and breaking it down into structured milestones...
                </p>
              </div>
            )}

            {/* Step Cards List */}
            <div className="space-y-3">
              {activeTask.steps.map((step, idx) => {
                const isCurrent =
                  activeTask.currentStepIndex === idx && activeTask.status === 'executing';
                const isComplete = step.status === 'completed';
                const isFailed = step.status === 'failed';
                const isSkipped = step.status === 'skipped';
                const isPending = step.status === 'pending';
                const isExpanded = expandedSteps[step.id] ?? true;

                return (
                  <div
                    key={step.id}
                    className={`rounded-xl border transition-all overflow-hidden ${
                      isCurrent
                        ? 'bg-slate-900/90 border-cyan-500/50 shadow-lg shadow-cyan-950/30'
                        : isComplete
                        ? 'glass-card border-white/[0.08]'
                        : isFailed
                        ? 'bg-rose-950/30 border-rose-500/40 shadow-lg shadow-rose-950/20'
                        : isSkipped
                        ? 'bg-slate-950/40 border-slate-800 opacity-60'
                        : 'bg-slate-950/40 border-white/[0.04] opacity-70'
                    }`}
                  >
                    {/* Step Card Header */}
                    <div
                      onClick={() => toggleStepExpanded(step.id)}
                      className="p-4 flex items-start justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        {/* Status Icon */}
                        <div className="mt-0.5 shrink-0">
                          {isComplete ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                          ) : isCurrent ? (
                            <div className="w-5 h-5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
                          ) : isFailed ? (
                            <AlertTriangle className="w-5 h-5 text-rose-400" />
                          ) : isSkipped ? (
                            <SkipForward className="w-5 h-5 text-amber-400" />
                          ) : (
                            <Circle className="w-5 h-5 text-slate-500" />
                          )}
                        </div>

                        {/* Title & Description */}
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono text-purple-300 font-semibold">
                              Step {idx + 1}
                            </span>
                            <h4 className="text-sm font-semibold text-slate-100">
                              {step.title}
                            </h4>
                            <span
                              className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize ${
                                isComplete
                                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                                  : isCurrent
                                  ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/30 animate-pulse'
                                  : isFailed
                                  ? 'bg-rose-950/80 text-rose-300 border border-rose-500/30'
                                  : isSkipped
                                  ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                                  : 'bg-slate-900 text-slate-400 border border-slate-800'
                              }`}
                            >
                              {step.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-1">
                            {step.description}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-white/[0.05] text-slate-400 hidden sm:inline">
                          {toolMetadata[step.tool]?.name || 'Kimi-K3'}
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {/* Step Content / Output / Error Actions */}
                    {isExpanded && (
                      <div className="px-4 pb-4 space-y-3 border-t border-white/[0.04] pt-3">
                        {/* Step Output If Available */}
                        {step.output && (
                          <div className="text-xs text-slate-200 leading-relaxed bg-black/30 p-3.5 rounded-xl border border-white/[0.04]">
                            <FormattedResponse content={step.output} />
                          </div>
                        )}

                        {/* Step Failed Controls (Requirement 7: Retry, Skip, Stop Agent) */}
                        {isFailed && (
                          <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 space-y-3">
                            <div className="flex items-center gap-2 text-xs text-rose-300 font-semibold">
                              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                              <span>Step failed: {step.output || 'Execution interrupted.'}</span>
                            </div>

                            <div className="flex flex-wrap items-center gap-2 pt-1">
                              <button
                                onClick={() => handleRetryStep(idx)}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium cursor-pointer transition-colors"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Retry Step</span>
                              </button>

                              <button
                                onClick={() => handleSkipStep(idx)}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer transition-colors"
                              >
                                <SkipForward className="w-3.5 h-3.5 text-amber-400" />
                                <span>Skip Step</span>
                              </button>

                              <button
                                onClick={handleStopAgent}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-medium cursor-pointer transition-colors border border-white/[0.06]"
                              >
                                <Square className="w-3.5 h-3.5 text-rose-400" />
                                <span>Stop Agent</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Execution Log Stream */}
          <div className="rounded-xl bg-slate-950 border border-slate-800 p-4 space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-900 text-slate-400">
              <div className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Agent Execution Kernel Trace</span>
              </div>
              <span className="text-[11px] text-slate-500">
                {activeTask.logs.length} events recorded
              </span>
            </div>

            <div className="max-h-36 overflow-y-auto space-y-1.5 text-[11px] pr-1">
              {activeTask.logs.map((log, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-slate-500 shrink-0">
                    [{new Date(log.timestamp).toLocaleTimeString()}]
                  </span>
                  <span
                    className={
                      log.type === 'error'
                        ? 'text-rose-400'
                        : log.type === 'warn'
                        ? 'text-amber-400'
                        : log.type === 'tool'
                        ? 'text-cyan-300'
                        : 'text-slate-300'
                    }
                  >
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Final Result Card (Requirement 8: Show "Agent completed" & clear final result) */}
          {(activeTask.finalResult || activeTask.result) && (
            <div className="glass-card rounded-2xl p-6 border border-emerald-500/30 space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-950/70 border border-emerald-500/40 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      Agent completed — Final Deliverable
                    </h3>
                    <p className="text-xs text-slate-400">
                      Synthesized across {completedStepsCount} completed milestones
                      {skippedStepsCount > 0 ? ` (${skippedStepsCount} skipped)` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleSpeakResult}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSpeakingResult
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                    }`}
                    title={isSpeakingResult ? 'Stop reading aloud' : 'Read agent deliverable aloud'}
                  >
                    {isSpeakingResult ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                        <span>Stop</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                        <span>Read Aloud</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleCopyResult}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition-colors cursor-pointer"
                  >
                    {copiedResult ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Copy Result</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="pt-2 text-slate-100 leading-relaxed">
                <FormattedResponse
                  content={activeTask.finalResult || activeTask.result || ''}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Agent History Modal / Drawer (Requirement 9) */}
      {isHistoryOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-bold text-white">Agent Task History</h3>
                <span className="text-xs text-slate-400 font-mono">
                  ({historyList.length})
                </span>
              </div>

              <div className="flex items-center gap-2">
                {historyList.length > 0 && (
                  <button
                    onClick={handleClearHistory}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                    title="Clear history"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear History</span>
                  </button>
                )}
                <button
                  onClick={() => setIsHistoryOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Task List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {historyList.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-sm">
                  No previous agent tasks saved yet. Start a task to generate history.
                </div>
              ) : (
                historyList.map(item => (
                  <div
                    key={item.id}
                    onClick={() => handleOpenHistoryItem(item)}
                    className="p-4 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-white/[0.06] hover:border-purple-500/40 transition-all cursor-pointer space-y-2 group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <h4 className="text-sm font-semibold text-slate-100 group-hover:text-purple-300 transition-colors line-clamp-2">
                        {item.task}
                      </h4>
                      <button
                        onClick={(e) => handleDeleteHistoryItem(e, item.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono capitalize ${
                            item.status === 'completed'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                              : item.status === 'failed'
                              ? 'bg-rose-950 text-rose-300 border border-rose-500/30'
                              : item.status === 'stopped'
                              ? 'bg-amber-950 text-amber-300 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {item.status}
                        </span>
                        <span>{item.steps?.length || 0} milestones</span>
                      </div>

                      <div className="flex items-center gap-1 text-slate-500 text-[11px]">
                        <Clock className="w-3 h-3" />
                        <span>
                          {new Date(item.createdAt).toLocaleDateString([], {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
