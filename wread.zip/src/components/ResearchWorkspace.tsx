import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Globe, 
  ExternalLink, 
  Sparkles, 
  FileText, 
  ListOrdered, 
  Copy, 
  Check, 
  Clock, 
  Trash2, 
  ChevronRight, 
  ShieldCheck,
  Square,
  AlertCircle,
  BrainCircuit,
  Layers,
  ArrowRight,
  BookOpen,
  Calendar,
  Compass,
  Mic,
  MicOff,
  Volume2,
  VolumeX
} from 'lucide-react';
import { ResearchResult, ResearchSource, ResearchMode } from '../types';
import { performWebResearch, APIClientError } from '../services/api';
import { StorageService } from '../services/storage';
import { findRelevantMemories } from '../services/memoryMatcher';
import { FormattedResponse } from './FormattedResponse';
import { VoiceAssistantService } from '../services/voiceService';

interface ResearchWorkspaceProps {
  initialQuery?: string;
  onClearInitialQuery?: () => void;
}

type TimelineStep = 
  | 'idle'
  | 'searching'
  | 'collecting'
  | 'reading'
  | 'comparing'
  | 'analyzing'
  | 'preparing'
  | 'completed'
  | 'stopped'
  | 'failed';

const TIMELINE_STEPS: Array<{ key: TimelineStep; label: string; desc: string }> = [
  { key: 'searching', label: 'Searching...', desc: 'Querying public web retrieval layer' },
  { key: 'collecting', label: 'Collecting sources...', desc: 'Extracting verified domain references & URLs' },
  { key: 'reading', label: 'Reading sources...', desc: 'Parsing content excerpts & source snippets' },
  { key: 'comparing', label: 'Comparing information...', desc: 'Detecting contradictions & aligning key evidence' },
  { key: 'analyzing', label: 'Analyzing with Kimi-K3...', desc: 'Synthesizing knowledge via neural model' },
  { key: 'preparing', label: 'Preparing final answer...', desc: 'Assembling citations & verified sources list' },
];

export const ResearchWorkspace: React.FC<ResearchWorkspaceProps> = ({
  initialQuery,
  onClearInitialQuery,
}) => {
  const [query, setQuery] = useState(initialQuery || '');
  const [mode, setMode] = useState<ResearchMode>('quick');
  const [isLoading, setIsLoading] = useState(false);
  const [timelineStep, setTimelineStep] = useState<TimelineStep>('idle');
  const [activeResult, setActiveResult] = useState<ResearchResult | null>(null);
  const [history, setHistory] = useState<ResearchResult[]>([]);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [copiedAnswer, setCopiedAnswer] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'answer' | 'sources' | 'facts'>('answer');
  const [consultedMemoriesCount, setConsultedMemoriesCount] = useState<number>(0);
  const [isRecording, setIsRecording] = useState(false);
  const [interimVoiceText, setInterimVoiceText] = useState('');
  const [isSpeakingAnswer, setIsSpeakingAnswer] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const timelineIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Load history on mount
  useEffect(() => {
    setHistory(StorageService.getResearchHistory());
  }, []);

  // Handle incoming initialQuery from Chat or Home
  useEffect(() => {
    if (initialQuery && initialQuery.trim().length > 0) {
      setQuery(initialQuery);
      if (onClearInitialQuery) {
        onClearInitialQuery();
      }
    }
  }, [initialQuery, onClearInitialQuery]);

  // Clean up timers and voice on unmount
  useEffect(() => {
    return () => {
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.stopListening();
      if (timelineIntervalRef.current) {
        clearInterval(timelineIntervalRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  // Voice dictation toggle for research query
  const toggleSpeechRecognition = () => {
    if (isRecording) {
      VoiceAssistantService.stopListening();
      setIsRecording(false);
      setInterimVoiceText('');
      return;
    }

    if (!VoiceAssistantService.isSTTSupported()) {
      setErrorMessage('Speech recognition is not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    VoiceAssistantService.stopSpeaking();
    setIsSpeakingAnswer(false);
    setErrorMessage(null);

    const settings = StorageService.getSettings();
    VoiceAssistantService.startListening(
      {
        onStart: () => {
          setIsRecording(true);
        },
        onInterim: (interim) => {
          setInterimVoiceText(interim);
        },
        onFinal: (finalText) => {
          setQuery(prev => (prev ? `${prev.trim()} ${finalText}` : finalText));
          setInterimVoiceText('');
        },
        onError: (errMsg) => {
          setErrorMessage(errMsg);
          setIsRecording(false);
          setInterimVoiceText('');
        },
        onEnd: () => {
          setIsRecording(false);
          setInterimVoiceText('');
        },
      },
      settings?.voiceLanguage || 'auto'
    );
  };

  // Speak research dossier answer
  const handleToggleSpeakAnswer = () => {
    if (!activeResult) return;
    const textToSpeak = activeResult.finalAnswer || activeResult.summary;
    if (isSpeakingAnswer) {
      VoiceAssistantService.stopSpeaking();
      setIsSpeakingAnswer(false);
    } else {
      const settings = StorageService.getSettings();
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.speak(textToSpeak, {
        language: settings?.voiceLanguage || 'auto',
        rate: settings?.speechRate || 1.0,
        onStart: () => setIsSpeakingAnswer(true),
        onEnd: () => setIsSpeakingAnswer(false),
        onError: () => setIsSpeakingAnswer(false),
      });
    }
  };

  const handleStartResearch = async (searchQuery?: string) => {
    const q = typeof searchQuery === 'string' ? searchQuery : query;
    if (!q.trim() || isLoading) return;

    setIsLoading(true);
    setErrorMessage(null);
    setTimelineStep('searching');

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Timeline stepping simulation for visual feedback
    const stepSequence: TimelineStep[] = ['searching', 'collecting', 'reading', 'comparing', 'analyzing', 'preparing'];
    let currentIdx = 0;
    
    if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
    timelineIntervalRef.current = setInterval(() => {
      if (currentIdx < stepSequence.length - 1) {
        currentIdx++;
        setTimelineStep(stepSequence[currentIdx]);
      }
    }, mode === 'deep' ? 1600 : 900);

    // Context-aware memory retrieval (only relevant memories)
    const allMemories = StorageService.getMemories();
    const relevant = findRelevantMemories(q.trim(), allMemories);
    setConsultedMemoriesCount(relevant.length);
    const relevantMemoryTexts = relevant.map(m => `[Memory: ${m.category}] ${m.content}`);

    try {
      const result = await performWebResearch(q.trim(), mode, {
        relevantMemories: relevantMemoryTexts,
        signal: controller.signal,
      });

      if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
      setTimelineStep('completed');
      setActiveResult(result);
      setActiveTab('answer');
      StorageService.saveResearchResult(result);
      setHistory(StorageService.getResearchHistory());
    } catch (err: any) {
      if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
      
      if (err.name === 'AbortError' || err.code === 'ABORTED' || err.message?.includes('stopped')) {
        setTimelineStep('stopped');
        setErrorMessage('Research stopped by user directive. Preserved already collected state.');
        return;
      }

      setTimelineStep('failed');
      const safeMsg = err.message || 'Web research failed. Please check network connection and try again.';
      setErrorMessage(safeMsg);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
      if (timelineIntervalRef.current) clearInterval(timelineIntervalRef.current);
    }
  };

  const handleStopResearch = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    if (timelineIntervalRef.current) {
      clearInterval(timelineIntervalRef.current);
      timelineIntervalRef.current = null;
    }
    setIsLoading(false);
    setTimelineStep('stopped');
    setErrorMessage('Research stopped by user directive. Preserved already collected state.');
  };

  const handleCopySummary = () => {
    if (!activeResult) return;
    navigator.clipboard.writeText(activeResult.summary);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  const handleCopyAnswer = () => {
    if (!activeResult?.finalAnswer) return;
    navigator.clipboard.writeText(activeResult.finalAnswer);
    setCopiedAnswer(true);
    setTimeout(() => setCopiedAnswer(false), 2000);
  };

  const handleDeleteHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    StorageService.deleteResearchResult(id);
    setHistory(StorageService.getResearchHistory());
    if (activeResult?.id === id) {
      setActiveResult(null);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear all research history?')) {
      StorageService.clearResearchHistory();
      setHistory([]);
      setActiveResult(null);
    }
  };

  const sampleQueries = [
    'Who is the current Prime Minister of India?',
    'Latest SSC exam updates',
    'Post-quantum cryptographic standards approved by NIST',
    'Recent breakthroughs in room-temperature superconductors',
  ];

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center shadow-lg shadow-emerald-500/10">
              <Globe className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>Web Research Engine</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono font-normal">
                  Live Web Retrieval
                </span>
              </h1>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Gathers public web pages, indexes verifiable sources, and performs neural synthesis with Kimi-K3.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {consultedMemoriesCount > 0 && (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-[11px] text-cyan-300">
              <BrainCircuit className="w-3.5 h-3.5 text-cyan-400" />
              <span>{consultedMemoriesCount} memories integrated</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900 border border-white/[0.08] text-xs text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Verifiable Citations</span>
          </div>
        </div>
      </div>

      {/* Query Bar & Controls */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 border border-white/[0.08] space-y-4 shadow-xl">
        {/* Voice recording interim status indicator */}
        {isRecording && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-xs text-emerald-200 animate-pulse">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
            </span>
            <span className="font-semibold text-emerald-300">Listening to research query:</span>
            <span className="italic truncate text-slate-300">
              {interimVoiceText || 'Speak query now... (Tap mic to stop)'}
            </span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              disabled={isLoading}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleStartResearch();
              }}
              placeholder={isRecording ? "Listening..." : "Enter research query (e.g. 'Who is the current Prime Minister of India?')"}
              className="w-full pl-4 pr-12 py-3 rounded-xl glass-input text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
            />
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className={`absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-colors cursor-pointer ${
                isRecording
                  ? 'text-rose-400 bg-rose-950/60 animate-pulse'
                  : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-900/60'
              }`}
              title={isRecording ? 'Stop voice input' : 'Speak research query'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode Selector (Quick vs Deep) */}
            <div className="flex items-center bg-slate-950/80 rounded-xl p-1 border border-white/[0.08]">
              <button
                type="button"
                onClick={() => setMode('quick')}
                disabled={isLoading}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  mode === 'quick'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Quick Research: fewer sources, faster response"
              >
                Quick
              </button>
              <button
                type="button"
                onClick={() => setMode('deep')}
                disabled={isLoading}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  mode === 'deep'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Deep Research: more sources, content reading, comparative analysis"
              >
                Deep
              </button>
            </div>

            {/* Start / Stop Button */}
            {!isLoading ? (
              <button
                onClick={() => handleStartResearch()}
                disabled={!query.trim()}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-30 text-white font-medium text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-950/40 shrink-0"
              >
                <Search className="w-4 h-4" />
                <span>Start Research</span>
              </button>
            ) : (
              <button
                onClick={handleStopResearch}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-medium text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-rose-950/40 shrink-0 animate-pulse"
                title="Stop current research pipeline and preserve already collected sources"
              >
                <Square className="w-4 h-4 fill-white" />
                <span>Stop Research</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick query presets */}
        <div className="flex flex-wrap gap-2 pt-1 items-center">
          <span className="text-xs text-slate-300">Suggested:</span>
          {sampleQueries.map((sq, i) => (
            <button
              key={i}
              disabled={isLoading}
              onClick={() => {
                setQuery(sq);
                handleStartResearch(sq);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-xs text-slate-300 hover:text-emerald-300 transition-colors cursor-pointer truncate max-w-xs border border-white/[0.04]"
            >
              "{sq}"
            </button>
          ))}
        </div>
      </div>

      {/* Error state if any */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/30 flex items-start gap-3 text-xs text-rose-200 shadow-md">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-rose-300">Research Status Update:</span>
            <p className="leading-relaxed">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Research Timeline (Requirement 8) */}
      {(isLoading || timelineStep === 'completed' || timelineStep === 'stopped') && (
        <div className="glass-card rounded-2xl p-5 border border-white/[0.08] space-y-3 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Research Pipeline Timeline
              </h3>
            </div>
            <span className="text-[11px] font-mono text-slate-300">
              Mode: {mode === 'deep' ? 'Deep Comparative' : 'Quick Synthesis'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 pt-1">
            {TIMELINE_STEPS.map((step, idx) => {
              const activeIndex = TIMELINE_STEPS.findIndex(s => s.key === timelineStep);
              const isDone = timelineStep === 'completed' || (activeIndex >= 0 && idx < activeIndex);
              const isCurrent = timelineStep === step.key && isLoading;
              const isPending = !isDone && !isCurrent;

              return (
                <div
                  key={step.key}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    isCurrent
                      ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/20'
                      : isDone
                      ? 'bg-slate-900/60 border-emerald-500/20 text-slate-200'
                      : 'bg-slate-950/40 border-white/[0.04] text-slate-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    {isCurrent ? (
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    ) : isDone ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <span className="text-[10px] font-mono text-slate-400">0{idx + 1}</span>
                    )}
                    <span className="text-[11px] font-semibold truncate">{step.label}</span>
                  </div>
                  <p className="text-[10px] text-slate-300 line-clamp-1">{step.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Loading Progress State */}
      {isLoading && (
        <div className="glass-card rounded-2xl p-8 border border-emerald-500/30 text-center space-y-4 shadow-xl">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 mx-auto flex items-center justify-center animate-pulse">
            <Globe className="w-6 h-6 text-emerald-400 animate-spin" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-white">
              Retrieving & Analyzing Live Public Web Intelligence
            </h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              Extracting domain entities, evaluating technical papers, and synthesizing sourced citations with Kimi-K3...
            </p>
          </div>
          <div className="w-48 h-1.5 bg-slate-900 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 w-2/3 animate-pulse" />
          </div>
        </div>
      )}

      {/* Research Result Content */}
      {activeResult && !isLoading && (
        <div className="space-y-6">
          {/* Navigation Tabs for Result */}
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-1">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('answer')}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'answer'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Final Answer & Citations</span>
              </button>

              <button
                onClick={() => setActiveTab('sources')}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'sources'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Sources Found ({activeResult.sources?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveTab('facts')}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'facts'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ListOrdered className="w-3.5 h-3.5" />
                <span>Key Facts & Summary</span>
              </button>
            </div>

            <div className="text-[11px] text-slate-300 font-mono hidden sm:block">
              Synthesized with {activeResult.provider || 'Kimi-K3'}
            </div>
          </div>

          {/* TAB 1: FINAL ANSWER (Requirement 1, 6) */}
          {activeTab === 'answer' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.06]">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-lg font-bold text-white">
                    Research Dossier: "{activeResult.query}"
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleSpeakAnswer}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSpeakingAnswer
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                    }`}
                    title={isSpeakingAnswer ? 'Stop reading aloud' : 'Read research dossier aloud'}
                  >
                    {isSpeakingAnswer ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                        <span>Stop</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Read Aloud</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleCopyAnswer}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition-colors cursor-pointer"
                  >
                    {copiedAnswer ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Answer</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Formatted Markdown Final Answer */}
              <div className="text-slate-200 leading-relaxed text-sm sm:text-base">
                <FormattedResponse content={activeResult.finalAnswer || activeResult.summary} />
              </div>
            </div>
          )}

          {/* TAB 2: SOURCES FOUND (Requirement 4: title, url, snippet, sourceName, retrievedAt) */}
          {activeTab === 'sources' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.06]">
                <div className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-indigo-400" />
                  <h3 className="text-base font-bold text-white">
                    Retrieved Public Web Sources ({activeResult.sources?.length || 0})
                  </h3>
                </div>
                <span className="text-xs text-slate-300 font-mono">
                  Live public web retrieval
                </span>
              </div>

              {(!activeResult.sources || activeResult.sources.length === 0) ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  No external sources retrieved for this query.
                </div>
              ) : (
                <div className="space-y-3 pt-1">
                  {activeResult.sources.map((src: ResearchSource, idx: number) => (
                    <a
                      key={idx}
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 rounded-xl bg-slate-950/70 border border-white/[0.06] hover:border-emerald-500/40 hover:bg-slate-900/60 transition-all flex flex-col justify-between group block cursor-pointer"
                    >
                      <div className="flex items-start justify-between gap-3 mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 text-xs font-mono border border-emerald-800/40">
                            [{idx + 1}]
                          </span>
                          <span className="text-xs font-mono text-cyan-400 truncate max-w-xs">
                            {src.sourceName || src.domain}
                          </span>
                        </div>
                        <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-300 transition-colors shrink-0 mt-0.5" />
                      </div>

                      <h4 className="text-sm font-semibold text-slate-100 group-hover:text-white mb-1">
                        {src.title}
                      </h4>

                      <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                        {src.snippet || 'No snippet preview available for this source.'}
                      </p>

                      <div className="mt-2.5 pt-2 border-t border-white/[0.04] flex items-center justify-between text-[10px] text-slate-400 font-mono">
                        <span className="truncate max-w-[280px] sm:max-w-md text-slate-400">
                          {src.url}
                        </span>
                        <span>
                          {src.retrievedAt ? new Date(src.retrievedAt).toLocaleTimeString() : 'Verified'}
                        </span>
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: KEY FACTS & SUMMARY */}
          {activeTab === 'facts' && (
            <div className="space-y-6">
              {/* Executive Summary Card */}
              <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-3 shadow-xl">
                <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <h3 className="text-base font-bold text-white">Executive Summary</h3>
                  </div>
                  <button
                    onClick={handleCopySummary}
                    className="flex items-center gap-1 text-xs text-slate-300 hover:text-white"
                  >
                    {copiedSummary ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedSummary ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {activeResult.summary}
                </p>
              </div>

              {/* Key Empirical Facts */}
              {activeResult.keyFacts && activeResult.keyFacts.length > 0 && (
                <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-3 shadow-xl">
                  <div className="flex items-center gap-2 pb-2 border-b border-white/[0.06]">
                    <ListOrdered className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-base font-bold text-white">
                      Key Empirical Facts & Findings
                    </h3>
                  </div>
                  <div className="space-y-2 pt-1">
                    {activeResult.keyFacts.map((fact, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-slate-950/60 border border-white/[0.04] flex items-start gap-3"
                      >
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-950 text-cyan-400 text-xs font-mono shrink-0 mt-0.5 border border-cyan-800/40">
                          {idx + 1}
                        </span>
                        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                          {fact}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Contradictions & Divergences */}
              {activeResult.contradictions && activeResult.contradictions.length > 0 && (
                <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-3 shadow-xl">
                  <div className="flex items-center gap-2 pb-2 border-b border-white/[0.06]">
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                    <h3 className="text-base font-bold text-white">
                      Source Divergences & Perspective Checks
                    </h3>
                  </div>
                  <div className="space-y-2 pt-1">
                    {activeResult.contradictions.map((contra, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 flex items-start gap-3 text-amber-200 text-xs leading-relaxed"
                      >
                        <span>•</span>
                        <p>{contra}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Research History List (Requirement 11) */}
      {history.length > 0 && (
        <div className="pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>Research History ({history.length})</span>
            </h3>

            <button
              onClick={handleClearHistory}
              className="text-xs text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1 cursor-pointer font-medium"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setActiveResult(item);
                  setQuery(item.query);
                  setActiveTab('answer');
                }}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  activeResult?.id === item.id
                    ? 'bg-slate-900/90 border-emerald-500/40 text-emerald-300'
                    : 'glass-card border-white/[0.05] text-slate-300 hover:border-white/[0.1]'
                }`}
              >
                <div className="min-w-0 flex-1 pr-2">
                  <div className="text-xs font-semibold truncate text-slate-200">
                    {item.query}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                    <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                    <span>•</span>
                    <span className="capitalize">{item.mode || 'quick'}</span>
                    <span>•</span>
                    <span>{item.sources?.length || 0} sources</span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={(e) => handleDeleteHistory(item.id, e)}
                    className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                    title="Delete record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State if no active result & no history */}
      {!activeResult && history.length === 0 && !isLoading && (
        <div className="py-12 text-center text-slate-400 space-y-2">
          <Globe className="w-10 h-10 text-slate-500 mx-auto" />
          <h4 className="text-sm font-semibold text-slate-300">
            No research dossiers compiled yet
          </h4>
          <p className="text-xs max-w-sm mx-auto text-slate-400">
            Enter a question or topic above to retrieve live public sources, compare evidence, and generate cited intelligence.
          </p>
        </div>
      )}
    </div>
  );
};
