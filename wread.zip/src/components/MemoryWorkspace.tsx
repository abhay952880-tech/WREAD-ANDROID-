import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Search, 
  Plus, 
  Trash2, 
  Edit3, 
  Tag, 
  Check, 
  X, 
  Download,
  Calendar,
  Layers
} from 'lucide-react';
import { Memory, MemoryCategory } from '../types';
import { StorageService } from '../services/storage';

export const MemoryWorkspace: React.FC = () => {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isAddingMemory, setIsAddingMemory] = useState(false);
  const [editingMemoryId, setEditingMemoryId] = useState<string | null>(null);

  // Form State
  const [formKey, setFormKey] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formCategory, setFormCategory] = useState<MemoryCategory>('Preferences');
  const [formTags, setFormTags] = useState('');

  const categories: Array<{ id: string; label: string }> = [
    { id: 'All', label: 'All Categories' },
    { id: 'Preferences', label: 'Preferences' },
    { id: 'Projects', label: 'Projects' },
    { id: 'Instructions', label: 'Instructions' },
    { id: 'Important Information', label: 'Important Info' },
    { id: 'General', label: 'General' },
  ];

  useEffect(() => {
    setMemories(StorageService.getMemories());
  }, []);

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formKey.trim() || !formContent.trim()) return;

    const tags = formTags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    const memoryToSave: Memory = {
      id: editingMemoryId || 'mem_' + Date.now(),
      key: formKey.trim(),
      content: formContent.trim(),
      category: formCategory,
      tags,
      createdAt: editingMemoryId
        ? memories.find(m => m.id === editingMemoryId)?.createdAt || Date.now()
        : Date.now(),
      updatedAt: Date.now(),
    };

    StorageService.saveMemory(memoryToSave);
    setMemories(StorageService.getMemories());
    resetForm();
  };

  const handleEditClick = (mem: Memory) => {
    setEditingMemoryId(mem.id);
    setFormKey(mem.key);
    setFormContent(mem.content);
    setFormCategory(mem.category);
    setFormTags(mem.tags ? mem.tags.join(', ') : '');
    setIsAddingMemory(true);
  };

  const handleDelete = (id: string) => {
    StorageService.deleteMemory(id);
    setMemories(StorageService.getMemories());
  };

  const resetForm = () => {
    setIsAddingMemory(false);
    setEditingMemoryId(null);
    setFormKey('');
    setFormContent('');
    setFormCategory('Preferences');
    setFormTags('');
  };

  const handleExportMemories = () => {
    const jsonStr = JSON.stringify(memories, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wread-memories-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter memories
  const filteredMemories = memories.filter((m) => {
    const matchesCategory =
      selectedCategory === 'All' || m.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      !query ||
      m.key.toLowerCase().includes(query) ||
      m.content.toLowerCase().includes(query) ||
      m.tags?.some(t => t.toLowerCase().includes(query));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-pink-400" />
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Memory & Knowledge Vault
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-pink-950/60 border border-pink-500/30 text-pink-300 text-xs font-mono">
              {memories.length} Stored
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Persistent context, preferences, and custom project directives retained across conversations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportMemories}
            disabled={memories.length === 0}
            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/[0.08] text-xs text-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-30"
            title="Export memories as JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>

          <button
            onClick={() => setIsAddingMemory(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-medium text-xs sm:text-sm flex items-center gap-1.5 transition-all shadow-lg shadow-pink-950/40 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Memory</span>
          </button>
        </div>
      </div>

      {/* Add / Edit Memory Modal */}
      {isAddingMemory && (
        <div className="glass-card rounded-2xl p-5 border border-pink-500/30 space-y-4 shadow-2xl">
          <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Brain className="w-4 h-4 text-pink-400" />
              <span>{editingMemoryId ? 'Edit Memory' : 'Store New Memory'}</span>
            </h3>
            <button
              onClick={resetForm}
              className="text-slate-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSaveMemory} className="space-y-3.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Memory Identifier / Key
                </label>
                <input
                  type="text"
                  required
                  value={formKey}
                  onChange={(e) => setFormKey(e.target.value)}
                  placeholder="e.g. Coding Guidelines, API Preference"
                  className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500/50"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as MemoryCategory)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-white/[0.1] text-xs sm:text-sm text-white focus:outline-none focus:ring-2 focus:ring-pink-500/50 cursor-pointer"
                >
                  <option value="Preferences">Preferences</option>
                  <option value="Projects">Projects</option>
                  <option value="Instructions">Instructions</option>
                  <option value="Important Information">Important Information</option>
                  <option value="General">General</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Content & Context
              </label>
              <textarea
                required
                rows={3}
                value={formContent}
                onChange={(e) => setFormContent(e.target.value)}
                placeholder="Details, habits, architecture preferences, or persistent instructions..."
                className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500/50 resize-none leading-relaxed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Tags (comma separated)
              </label>
              <input
                type="text"
                value={formTags}
                onChange={(e) => setFormTags(e.target.value)}
                placeholder="e.g. style, typescript, security"
                className="w-full px-3.5 py-2 rounded-xl glass-input text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500/50"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-xs font-medium text-white transition-all shadow-md cursor-pointer"
              >
                {editingMemoryId ? 'Update Memory' : 'Save Memory'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search & Category Filter Bar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search stored memories by keyword, key, or tag..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl glass-input text-xs sm:text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-pink-500/40"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-white/[0.05]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Memories Grid */}
      {filteredMemories.length === 0 ? (
        /* Empty State */
        <div className="glass-card rounded-2xl p-12 text-center text-slate-400 space-y-3 border border-white/[0.06]">
          <Brain className="w-10 h-10 text-slate-400 mx-auto" />
          <h4 className="text-base font-semibold text-slate-200">
            No memories found
          </h4>
          <p className="text-xs max-w-sm mx-auto">
            {searchQuery || selectedCategory !== 'All'
              ? 'No stored items match your current filter parameters.'
              : 'Add custom memories to personalize responses and preserve context across sessions.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredMemories.map((mem) => (
            <div
              key={mem.id}
              className="glass-card rounded-2xl p-4 sm:p-5 border border-white/[0.08] hover:border-pink-500/30 transition-all flex flex-col justify-between space-y-3 shadow-lg"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-pink-400" />
                    <h3 className="text-sm font-bold text-slate-100">
                      {mem.key}
                    </h3>
                  </div>

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-pink-950/70 text-pink-300 border border-pink-800/40">
                    {mem.category}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {mem.content}
                </p>
              </div>

              <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between text-xs text-slate-300">
                <div className="flex flex-wrap items-center gap-1.5">
                  {mem.tags && mem.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-white/[0.05] text-slate-400"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleEditClick(mem)}
                    className="p-1 rounded text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    title="Edit memory"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(mem.id)}
                    className="p-1 rounded text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                    title="Delete memory"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
