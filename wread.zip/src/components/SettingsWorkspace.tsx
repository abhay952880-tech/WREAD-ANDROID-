import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Cpu, 
  Palette, 
  Brain, 
  Bell, 
  Server, 
  Info, 
  ShieldCheck, 
  RefreshCw, 
  Check, 
  Trash2,
  Lock,
  Zap,
  Sliders,
  Mic,
  Volume2
} from 'lucide-react';
import { AppSettings, BackendHealth, VoiceLanguage } from '../types';
import { StorageService } from '../services/storage';
import { checkBackendHealth } from '../services/api';
import { VoiceAssistantService } from '../services/voiceService';

interface SettingsWorkspaceProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  backendHealth: BackendHealth;
  onRefreshHealth: () => void;
}

export const SettingsWorkspace: React.FC<SettingsWorkspaceProps> = ({
  settings,
  onUpdateSettings,
  backendHealth,
  onRefreshHealth,
}) => {
  const [activeSection, setActiveSection] = useState<'ai' | 'voice' | 'appearance' | 'memory' | 'notifications' | 'backend' | 'about'>('ai');
  const [isTestingHealth, setIsTestingHealth] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isSpeakingTest, setIsSpeakingTest] = useState(false);

  const handleToggle = (key: keyof AppSettings) => {
    const updated = { ...settings, [key]: !settings[key] };
    onUpdateSettings(updated);
    StorageService.saveSettings(updated);
    flashSave();
  };

  const handleChange = (key: keyof AppSettings, value: any) => {
    const updated = { ...settings, [key]: value };
    onUpdateSettings(updated);
    StorageService.saveSettings(updated);
    flashSave();
  };

  const flashSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 1500);
  };

  const handleTestBackend = async () => {
    setIsTestingHealth(true);
    setTestResult(null);
    const start = Date.now();
    try {
      const res = await checkBackendHealth();
      const latency = Date.now() - start;
      onRefreshHealth();
      setTestResult(`Health Check Passed (${latency}ms) — Backend: ${res.backend}, Configured: ${res.configured}, Provider: ${res.provider}, Model: ${res.model}`);
    } catch (err: any) {
      setTestResult(`Check Failed: ${err.message}`);
    } finally {
      setIsTestingHealth(false);
    }
  };

  const handleClearAllMemories = () => {
    if (confirm('Are you sure you want to clear all stored memories?')) {
      StorageService.clearMemories();
      alert('All memories have been removed.');
    }
  };

  const handleTestSpeech = () => {
    if (isSpeakingTest) {
      VoiceAssistantService.stopSpeaking();
      setIsSpeakingTest(false);
      return;
    }

    const testPhrases = {
      'hi-IN': 'नमस्ते! मैं WREAD हूँ, आपका व्यक्तिगत AI सहायक। आपकी क्या सहायता करूँ?',
      'en-US': 'Hello! I am WREAD, your personal AI operating system. How can I assist you today?',
      'auto': 'Hello! नमस्ते! WREAD voice assistant system is online and ready.',
    };

    const phrase = testPhrases[settings.voiceLanguage || 'auto'] || testPhrases.auto;
    setIsSpeakingTest(true);

    VoiceAssistantService.speak(phrase, {
      language: settings.voiceLanguage,
      rate: settings.speechRate,
      onStart: () => setIsSpeakingTest(true),
      onEnd: () => setIsSpeakingTest(false),
      onError: () => setIsSpeakingTest(false),
    });
  };

  const sections = [
    { id: 'ai' as const, label: 'AI & Models', icon: Cpu },
    { id: 'voice' as const, label: 'Voice Assistant', icon: Mic },
    { id: 'appearance' as const, label: 'Appearance', icon: Palette },
    { id: 'memory' as const, label: 'Memory & Context', icon: Brain },
    { id: 'notifications' as const, label: 'Notifications', icon: Bell },
    { id: 'backend' as const, label: 'Backend & Security', icon: Server },
    { id: 'about' as const, label: 'About WREAD', icon: Info },
  ];

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-6 h-6 text-cyan-400" />
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Settings & Configuration
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Configure system reasoning parameters, memory retention, appearance, and backend health.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-3 py-1 rounded-full animate-pulse">
            <Check className="w-3.5 h-3.5" />
            <span>Settings Saved</span>
          </div>
        )}
      </div>

      {/* Settings Layout with Horizontal/Vertical Tabs */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Navigation Tabs */}
        <div className="md:col-span-4 flex md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0">
          {sections.map((sec) => {
            const Icon = sec.icon;
            const isActive = activeSection === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id)}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{sec.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Pane */}
        <div className="md:col-span-8">
          {/* AI Section */}
          {activeSection === 'ai' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  AI Model Configuration
                </h3>
                <p className="text-xs text-slate-400">
                  Manage primary inference model and generation parameters.
                </p>
              </div>

              <div className="space-y-4 text-xs sm:text-sm">
                <div>
                  <label className="block font-medium text-slate-200 mb-1.5">
                    Active AI Model Identifier
                  </label>
                  <input
                    type="text"
                    value={settings.aiModel}
                    onChange={(e) => handleChange('aiModel', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl glass-input font-mono text-cyan-300 text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                  />
                  <span className="text-[11px] text-slate-300 mt-1 block">
                    Default: moonshotai/Kimi-K3 hosted on Modal server endpoint.
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-medium text-slate-200">
                      Sampling Temperature: <span className="font-mono text-cyan-400">{settings.temperature}</span>
                    </label>
                    <span className="text-slate-300 text-[11px]">
                      {settings.temperature < 0.4 ? 'Deterministic' : settings.temperature > 0.8 ? 'Creative' : 'Balanced'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.temperature}
                    onChange={(e) => handleChange('temperature', parseFloat(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-200 mb-1.5">
                    System Core Directive
                  </label>
                  <textarea
                    rows={3}
                    value={settings.systemPrompt}
                    onChange={(e) => handleChange('systemPrompt', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none leading-relaxed"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Voice Assistant Section (Requirement 13) */}
          {activeSection === 'voice' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  Voice Assistant & Speech Synthesis
                </h3>
                <p className="text-xs text-slate-400">
                  Configure speech recognition, text-to-speech auto-reading, language dialect, and speech pacing.
                </p>
              </div>

              <div className="space-y-4">
                {/* Voice Input Toggle */}
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Voice Input (Speech-to-Text)
                    </div>
                    <div className="text-xs text-slate-400">
                      Enable microphone dictation in Chat, Agent task input, and Web Research
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('voiceInputEnabled')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.voiceInputEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.voiceInputEnabled ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Voice Output Toggle (Auto Speak) */}
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Auto Voice Output (Text-to-Speech)
                    </div>
                    <div className="text-xs text-slate-400">
                      Automatically read completed AI responses aloud (Default: OFF)
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('voiceOutputEnabled')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.voiceOutputEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.voiceOutputEnabled ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Voice Language Selection */}
                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05] space-y-2">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Voice Language
                    </div>
                    <div className="text-xs text-slate-400">
                      Supported: Hindi (हिन्दी), English, or Auto-detect based on text and script
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-1">
                    {[
                      { id: 'auto', label: 'Auto Detect', desc: 'Hindi / English / Script' },
                      { id: 'hi-IN', label: 'Hindi (हिन्दी)', desc: 'Indian Hindi dialect' },
                      { id: 'en-US', label: 'English', desc: 'Standard English' },
                    ].map((lang) => {
                      const isSelected = (settings.voiceLanguage || 'auto') === lang.id;
                      return (
                        <button
                          key={lang.id}
                          type="button"
                          onClick={() => handleChange('voiceLanguage', lang.id)}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-300'
                              : 'bg-slate-900/60 border-white/[0.04] text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <div className="text-xs font-semibold">{lang.label}</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">{lang.desc}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Speech Rate Slider */}
                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05] space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-slate-200">
                      Speech Rate (Pacing)
                    </label>
                    <span className="text-xs font-mono text-cyan-400">
                      {settings.speechRate || 1.0}x
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-slate-400">0.8x (Slower)</span>
                    <input
                      type="range"
                      min="0.8"
                      max="1.5"
                      step="0.1"
                      value={settings.speechRate || 1.0}
                      onChange={(e) => handleChange('speechRate', parseFloat(e.target.value))}
                      className="flex-1 accent-cyan-400 cursor-pointer"
                    />
                    <span className="text-[11px] text-slate-400">1.5x (Faster)</span>
                  </div>
                </div>

                {/* Audio Sample Test Button */}
                <div className="pt-2 flex items-center justify-between">
                  <div className="text-xs text-slate-400">
                    Test speech synthesis with current language settings:
                  </div>
                  <button
                    type="button"
                    onClick={handleTestSpeech}
                    className={`px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
                      isSpeakingTest
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-500/40 animate-pulse'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/[0.08]'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isSpeakingTest ? 'Stop Speaking' : 'Play Test Audio'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Appearance Section */}
          {activeSection === 'appearance' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  Appearance & Interface
                </h3>
                <p className="text-xs text-slate-400">
                  Customize theme accents, visual effects, and animated components.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Neural AI Orb Animation
                    </div>
                    <div className="text-xs text-slate-400">
                      Enable smooth multi-layer glow and particle rotation
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('orbAnimation')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.orbAnimation ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.orbAnimation ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Futuristic Accent Glow
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'cyan', label: 'Electric Cyan', color: 'bg-cyan-500' },
                      { id: 'purple', label: 'Neon Violet', color: 'bg-purple-500' },
                      { id: 'emerald', label: 'Cyber Emerald', color: 'bg-emerald-500' },
                    ].map((theme) => (
                      <button
                        key={theme.id}
                        onClick={() => handleChange('accentColor', theme.id)}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all cursor-pointer ${
                          settings.accentColor === theme.id
                            ? 'bg-slate-900 border-cyan-500/60 shadow-lg'
                            : 'bg-slate-950/40 border-white/[0.06] hover:border-white/[0.12]'
                        }`}
                      >
                        <div className={`w-5 h-5 rounded-full ${theme.color} shadow-sm`} />
                        <span className="text-xs font-medium text-slate-200">
                          {theme.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Memory Section */}
          {activeSection === 'memory' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  Memory Management
                </h3>
                <p className="text-xs text-slate-400">
                  Control persistent memory synthesis and context retention.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Enable Persistent Context Memory
                    </div>
                    <div className="text-xs text-slate-400">
                      Inject stored preferences and guidelines into AI reasoning prompts
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('memoryEnabled')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.memoryEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.memoryEnabled ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Auto-Extract User Directives
                    </div>
                    <div className="text-xs text-slate-400">
                      Detect and categorize recurring preferences automatically
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('autoExtractMemory')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.autoExtractMemory ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.autoExtractMemory ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="pt-2">
                  <button
                    onClick={handleClearAllMemories}
                    className="px-4 py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-xs font-semibold text-rose-300 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear All Memories</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Notifications Section */}
          {activeSection === 'notifications' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  Notifications & Audio
                </h3>
                <p className="text-xs text-slate-400">
                  Control sound alerts and background event notifications.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/60 border border-white/[0.05]">
                  <div>
                    <div className="text-sm font-medium text-slate-200">
                      Auditory Completion Cues
                    </div>
                    <div className="text-xs text-slate-400">
                      Play subtle futuristic harmonic chime when tasks complete
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle('soundEnabled')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.soundEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                        settings.soundEnabled ? 'left-6' : 'left-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Backend & Security Section */}
          {activeSection === 'backend' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  Backend Architecture & Security Diagnostics
                </h3>
                <p className="text-xs text-slate-400">
                  Live verification of server-side proxy and upstream AI endpoint readiness.
                </p>
              </div>

              <div className="space-y-3 text-xs sm:text-sm">
                <div className="p-4 rounded-xl bg-slate-950/70 border border-white/[0.06] space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Backend Server Route:</span>
                    <span className="font-mono text-cyan-400">GET /api/health</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Server Health Status:</span>
                    <span className="text-emerald-400 font-semibold">{backendHealth.backend.toUpperCase()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Kimi-K3 Credentials Configured:</span>
                    <span className={backendHealth.hasKimiKey ? 'text-emerald-400 font-medium' : 'text-amber-400'}>
                      {backendHealth.hasKimiKey ? 'Yes (Server Secret)' : 'Missing from environment'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Gemini Key Fallback:</span>
                    <span className={backendHealth.hasGeminiKey ? 'text-emerald-400 font-medium' : 'text-slate-300'}>
                      {backendHealth.hasGeminiKey ? 'Active' : 'None'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Upstream Base URL:</span>
                    <span className="font-mono text-[11px] text-slate-300 truncate max-w-[220px]">
                      https://searchess50--ep-kimi-k3-server.us-west.modal.direct
                    </span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    onClick={handleTestBackend}
                    disabled={isTestingHealth}
                    className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-cyan-950/30"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isTestingHealth ? 'animate-spin' : ''}`} />
                    <span>Test /api/health Endpoint</span>
                  </button>
                </div>

                {testResult && (
                  <div className="p-3 rounded-xl bg-slate-950 border border-cyan-500/30 font-mono text-[11px] text-cyan-300">
                    {testResult}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* About Section */}
          {activeSection === 'about' && (
            <div className="glass-card rounded-2xl p-6 border border-white/[0.08] space-y-6 shadow-xl">
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  WREAD Personal AI Operating System
                </h3>
                <p className="text-xs text-slate-400">
                  Original, independent autonomous intelligence platform.
                </p>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <p>
                  <strong className="text-white">WREAD</strong> is an original personal AI assistant designed with a complete separation of concerns between client interface and server execution pipelines.
                </p>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-white/[0.06] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Security & Zero-Exposure Guarantee</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    AI secrets, API tokens, and Modal credentials never traverse into browser memory, HTML, or client-side storage. All upstream requests are proxied via Node.js Express server endpoints with sanitized logging.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/[0.06] text-xs text-slate-300">
                  <span>Version 1.0.4-preview</span>
                  <span>Architecture: Full-Stack React + Node</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
