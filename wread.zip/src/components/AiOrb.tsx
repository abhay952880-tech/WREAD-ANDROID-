import React from 'react';
import { motion } from 'motion/react';

interface AiOrbProps {
  state?: 'idle' | 'breathing' | 'processing' | 'error';
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}

export const AiOrb: React.FC<AiOrbProps> = ({
  state = 'idle',
  size = 'lg',
  onClick,
  className = '',
}) => {
  const sizeMap = {
    sm: 'w-16 h-16',
    md: 'w-32 h-32',
    lg: 'w-48 h-48 sm:w-56 sm:h-56',
  };

  const isProcessing = state === 'processing';
  const isError = state === 'error';

  return (
    <div
      id="ai-orb-container"
      onClick={onClick}
      className={`relative flex items-center justify-center cursor-pointer select-none ${sizeMap[size]} ${className}`}
      title="WREAD Core AI Orb"
    >
      {/* Outer ambient glow halo */}
      <motion.div
        className={`absolute inset-0 rounded-full blur-2xl opacity-60 ${
          isError
            ? 'bg-rose-600'
            : isProcessing
            ? 'bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600'
            : 'bg-gradient-to-tr from-indigo-600 via-cyan-600 to-purple-800'
        }`}
        animate={
          isProcessing
            ? {
                scale: [1, 1.25, 1],
                opacity: [0.6, 0.9, 0.6],
                rotate: [0, 180, 360],
              }
            : {
                scale: [0.95, 1.1, 0.95],
                opacity: [0.45, 0.65, 0.45],
              }
        }
        transition={{
          duration: isProcessing ? 2.5 : 5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Orbiting ring 1 */}
      <motion.div
        className="absolute inset-1 rounded-full border border-cyan-400/30 border-dashed"
        animate={{ rotate: 360 }}
        transition={{
          duration: isProcessing ? 6 : 20,
          repeat: Infinity,
          ease: 'linear',
        }}
      />

      {/* Orbiting ring 2 */}
      <motion.div
        className="absolute inset-3 rounded-full border border-purple-500/25"
        animate={{ rotate: -360 }}
        transition={{
          duration: isProcessing ? 8 : 28,
          repeat: Infinity,
          ease: 'linear',
        }}
      />

      {/* Core sphere */}
      <motion.div
        className={`relative w-4/5 h-4/5 rounded-full overflow-hidden shadow-2xl flex items-center justify-center border ${
          isError
            ? 'border-rose-500/50 bg-gradient-to-br from-rose-950 via-slate-900 to-rose-900'
            : 'border-cyan-400/40 bg-gradient-to-br from-slate-950 via-indigo-950/80 to-slate-900'
        }`}
        animate={
          isProcessing
            ? {
                scale: [1, 1.05, 1],
                boxShadow: [
                  '0 0 20px rgba(6,182,212,0.4)',
                  '0 0 50px rgba(168,85,247,0.7)',
                  '0 0 20px rgba(6,182,212,0.4)',
                ],
              }
            : {
                scale: [0.98, 1.02, 0.98],
                boxShadow: [
                  '0 0 15px rgba(99,102,241,0.2)',
                  '0 0 30px rgba(6,182,212,0.4)',
                  '0 0 15px rgba(99,102,241,0.2)',
                ],
              }
        }
        transition={{
          duration: isProcessing ? 1.5 : 4,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      >
        {/* Core plasma fluid motion */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 via-purple-600/30 to-indigo-400/20 mix-blend-screen"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: isProcessing ? 4 : 12,
            repeat: Infinity,
            ease: 'linear',
          }}
        />

        {/* Central neural node */}
        <motion.div
          className={`w-5 h-5 rounded-full ${
            isError
              ? 'bg-rose-400 shadow-[0_0_15px_#f43f5e]'
              : isProcessing
              ? 'bg-cyan-300 shadow-[0_0_20px_#22d3ee]'
              : 'bg-indigo-300 shadow-[0_0_15px_#818cf8]'
          }`}
          animate={{
            scale: isProcessing ? [1, 1.5, 1] : [0.9, 1.1, 0.9],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: isProcessing ? 0.8 : 2.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        {/* Neural spark particles */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="w-1 h-1 rounded-full bg-cyan-200 absolute -top-1 animate-ping" />
          <div className="w-1.5 h-1.5 rounded-full bg-purple-300 absolute -bottom-1 right-8 animate-pulse" />
        </div>
      </motion.div>
    </div>
  );
};
