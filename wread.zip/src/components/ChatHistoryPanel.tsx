import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  MessageSquare, 
  Trash2, 
  Edit2, 
  Check, 
  X, 
  Calendar, 
  Clock, 
  AlertTriangle 
} from 'lucide-react';
import { Conversation } from '../types';

interface ChatHistoryPanelProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onDeleteConversation: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const ChatHistoryPanel: React.FC<ChatHistoryPanelProps> = ({
  conversations,
  activeId,
  onSelectConversation,
  onNewChat,
  onRenameConversation,
  onDeleteConversation,
  isOpen,
  onClose,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Filter conversations by search query
  const filtered = conversations.filter(c => 
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.messages.some(m => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Start renaming
  const handleStartRename = (e: React.MouseEvent, conversation: Conversation) => {
    e.stopPropagation();
    setEditingId(conversation.id);
    setEditTitle(conversation.title);
  };

  // Commit rename
  const handleSaveRename = (e: React.MouseEvent | React.FormEvent, id: string) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  // Delete flow
  const handleDeleteClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setConfirmDeleteId(id);
  };

  const handleConfirmDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    onDeleteConversation(id);
    setConfirmDeleteId(null);
  };

  const handleCancelDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDeleteId(null);
  };

  // Helper date formatting
  const formatTime = (ts?: number) => {
    if (!ts) return 'Unknown';
    const date = new Date(ts);
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' }) + 
      ' at ' + 
      date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatRelative = (ts?: number) => {
    if (!ts) return 'just now';
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days}d ago`;
    return new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="w-80 border-r border-white/[0.08] glass-panel flex flex-col h-full shrink-0 z-20 bg-slate-950/80 backdrop-blur-md transition-all">
      {/* Header */}
      <div className="p-3.5 border-b border-white/[0.08] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-cyan-400" />
          <span className="font-semibold text-sm text-slate-100">Conversation History</span>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-cyan-300 font-mono">
            {conversations.length}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          title="Close History Panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* New Chat & Search Box */}
      <div className="p-3 space-y-2 border-b border-white/[0.06]">
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-md shadow-cyan-950/40 font-medium text-xs sm:text-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
            <span>New Chat</span>
          </div>
          <span className="text-[10px] font-mono opacity-80 px-1.5 py-0.5 rounded bg-black/30">
            ⌘N
          </span>
        </button>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversations..."
            className="w-full pl-8 pr-3 py-1.5 bg-slate-900/80 border border-white/[0.08] focus:border-cyan-500/50 rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-2 text-slate-400 hover:text-slate-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filtered.length === 0 ? (
          <div className="text-center py-10 px-4 text-xs text-slate-400 space-y-2">
            <MessageSquare className="w-8 h-8 mx-auto text-slate-600 opacity-60" />
            <p>
              {searchQuery ? 'No matching conversations found' : 'No saved conversations yet.'}
            </p>
          </div>
        ) : (
          filtered.map((chat) => {
            const isActive = chat.id === activeId;
            const isEditing = chat.id === editingId;
            const isConfirmingDelete = chat.id === confirmDeleteId;

            return (
              <div
                key={chat.id}
                onClick={() => {
                  if (!isEditing && !isConfirmingDelete) {
                    onSelectConversation(chat.id);
                  }
                }}
                className={`group relative rounded-xl p-2.5 transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-slate-900 border-cyan-500/40 shadow-sm shadow-cyan-950/50'
                    : 'border-transparent hover:bg-slate-900/60 hover:border-white/[0.06]'
                }`}
              >
                {/* Rename Mode */}
                {isEditing ? (
                  <div className="space-y-2" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="text"
                      autoFocus
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveRename(e, chat.id);
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                      className="w-full px-2 py-1 bg-slate-950 border border-cyan-400 rounded-md text-xs text-white focus:outline-none"
                    />
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={handleCancelRename}
                        className="p-1 text-slate-400 hover:text-slate-200 rounded"
                        title="Cancel"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => handleSaveRename(e, chat.id)}
                        className="px-2 py-0.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[11px] font-medium flex items-center gap-1"
                        title="Save title"
                      >
                        <Check className="w-3 h-3" />
                        <span>Save</span>
                      </button>
                    </div>
                  </div>
                ) : isConfirmingDelete ? (
                  /* Delete Confirmation */
                  <div 
                    className="p-2 bg-rose-950/60 border border-rose-500/40 rounded-lg space-y-2 text-xs text-rose-200"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center gap-1.5 font-medium text-rose-300">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>Delete this conversation?</span>
                    </div>
                    <div className="flex items-center justify-end gap-1.5 pt-1">
                      <button
                        onClick={handleCancelDelete}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px]"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={(e) => handleConfirmDelete(e, chat.id)}
                        className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[11px] font-medium"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Standard Card */
                  <>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          {isActive && (
                            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 animate-pulse" />
                          )}
                          <h4 className={`text-xs font-medium truncate ${
                            isActive ? 'text-cyan-300 font-semibold' : 'text-slate-200'
                          }`}>
                            {chat.title || 'Untitled Conversation'}
                          </h4>
                        </div>
                      </div>

                      {/* Hover Actions (Rename, Delete) */}
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => handleStartRename(e, chat)}
                          className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                          title="Rename conversation"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => handleDeleteClick(e, chat.id)}
                          className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                          title="Delete conversation"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Metadata Timestamps */}
                    <div className="mt-1.5 pt-1 border-t border-white/[0.04] flex items-center justify-between text-[10px] text-slate-400">
                      <span className="flex items-center gap-1 font-mono" title={`Created: ${formatTime(chat.createdAt)}`}>
                        <Calendar className="w-2.5 h-2.5 text-slate-500" />
                        {new Date(chat.createdAt || Date.now()).toLocaleDateString([], { month: 'numeric', day: 'numeric' })}
                      </span>
                      <span className="flex items-center gap-1 font-mono" title={`Last active: ${formatTime(chat.updatedAt)}`}>
                        <Clock className="w-2.5 h-2.5 text-slate-500" />
                        {formatRelative(chat.updatedAt)}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-slate-800 text-[10px] font-mono text-slate-400">
                        {chat.messages.length} msgs
                      </span>
                    </div>
                  </>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Footer Info */}
      <div className="p-2.5 border-t border-white/[0.06] text-[10px] text-slate-400 flex items-center justify-between">
        <span>Stored locally in browser</span>
        <span className="font-mono text-cyan-400">WREAD OS</span>
      </div>
    </div>
  );
};
