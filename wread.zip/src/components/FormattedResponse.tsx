import React, { useState } from 'react';
import { Copy, Check, Terminal } from 'lucide-react';

interface FormattedResponseProps {
  content: string;
  className?: string;
}

export const FormattedResponse: React.FC<FormattedResponseProps> = ({ content, className = '' }) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const handleCopyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeIndex(index);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  if (!content) return null;

  // Split content by code blocks: ```lang ... ```
  const parts = content.split(/(```[\s\S]*?```)/g);
  let codeBlockCount = 0;

  return (
    <div className={`space-y-3.5 text-slate-100 text-sm sm:text-base leading-relaxed ${className}`}>
      {parts.map((part, index) => {
        // Code Block
        if (part.startsWith('```') && part.endsWith('```')) {
          const blockIdx = codeBlockCount++;
          const match = part.match(/^```([a-zA-Z0-9_-]+)?\n([\s\S]*?)```$/);
          const lang = match ? match[1] || 'code' : 'code';
          const code = match ? match[2] : part.slice(3, -3);

          return (
            <div
              key={index}
              className="my-3.5 rounded-xl overflow-hidden border border-slate-700/60 bg-slate-950/90 shadow-lg"
            >
              <div className="flex items-center justify-between px-3.5 py-2 bg-slate-900/90 border-b border-slate-800 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-mono uppercase tracking-wider font-semibold text-slate-300">
                    {lang}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyCode(code, blockIdx)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer text-xs font-medium"
                  title="Copy code snippet"
                >
                  {copiedCodeIndex === blockIdx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 text-xs sm:text-sm font-mono text-cyan-100/90 overflow-x-auto whitespace-pre leading-relaxed selection:bg-cyan-500/30">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // Regular Markdown block
        return <FormattedTextBlock key={index} text={part} />;
      })}
    </div>
  );
};

const FormattedTextBlock: React.FC<{ text: string }> = ({ text }) => {
  // Split on double newlines for major block divisions
  const rawParagraphs = text.split(/\n\s*\n/);

  return (
    <>
      {rawParagraphs.map((para, pIdx) => {
        const trimmed = para.trim();
        if (!trimmed) return null;

        // Table Detection
        if (isMarkdownTable(trimmed)) {
          return <MarkdownTable key={pIdx} tableText={trimmed} />;
        }

        // Check if paragraph starts with heading
        if (trimmed.startsWith('# ') || trimmed.startsWith('## ') || trimmed.startsWith('### ') || trimmed.startsWith('#### ')) {
          return <MarkdownHeading key={pIdx} text={trimmed} />;
        }

        // Blockquote
        if (trimmed.startsWith('> ') || trimmed.startsWith('>')) {
          const quoteLines = trimmed
            .split('\n')
            .map(l => l.replace(/^>\s?/, ''))
            .join('\n');
          return (
            <blockquote
              key={pIdx}
              className="border-l-2 border-cyan-400/80 pl-4 py-1.5 italic text-slate-300 bg-cyan-950/15 rounded-r-lg my-2.5"
            >
              <InlineText text={quoteLines} />
            </blockquote>
          );
        }

        // Process line-by-line for mixed lists & paragraphs
        return <MixedContentBlock key={pIdx} blockText={trimmed} />;
      })}
    </>
  );
};

/**
 * Renders mixed text containing paragraphs, bullet lists, or numbered lists
 */
const MixedContentBlock: React.FC<{ blockText: string }> = ({ blockText }) => {
  const lines = blockText.split('\n');
  const elements: React.ReactNode[] = [];
  let currentBullets: string[] = [];
  let currentNumbers: string[] = [];

  const flushBullets = (key: string) => {
    if (currentBullets.length > 0) {
      elements.push(
        <ul key={key} className="space-y-1.5 my-2 pl-5 list-disc text-slate-200 marker:text-cyan-400">
          {currentBullets.map((b, i) => (
            <li key={i} className="pl-1">
              <InlineText text={b} />
            </li>
          ))}
        </ul>
      );
      currentBullets = [];
    }
  };

  const flushNumbers = (key: string) => {
    if (currentNumbers.length > 0) {
      elements.push(
        <ol key={key} className="space-y-1.5 my-2 pl-5 list-decimal text-slate-200 marker:text-cyan-400 marker:font-mono">
          {currentNumbers.map((n, i) => (
            <li key={i} className="pl-1">
              <InlineText text={n} />
            </li>
          ))}
        </ol>
      );
      currentNumbers = [];
    }
  };

  lines.forEach((line, lIdx) => {
    const trimmed = line.trim();
    const bulletMatch = trimmed.match(/^[-*•]\s+(.*)/);
    const numMatch = trimmed.match(/^\d+[\.)]\s+(.*)/);

    if (bulletMatch) {
      flushNumbers(`num_flush_${lIdx}`);
      currentBullets.push(bulletMatch[1]);
    } else if (numMatch) {
      flushBullets(`bul_flush_${lIdx}`);
      currentNumbers.push(numMatch[1]);
    } else {
      flushBullets(`bul_flush_${lIdx}`);
      flushNumbers(`num_flush_${lIdx}`);
      if (trimmed.length > 0) {
        elements.push(
          <p key={`p_${lIdx}`} className="text-slate-200 leading-relaxed my-1.5">
            <InlineText text={trimmed} />
          </p>
        );
      }
    }
  });

  flushBullets('final_bullets');
  flushNumbers('final_numbers');

  return <>{elements}</>;
};

const MarkdownHeading: React.FC<{ text: string }> = ({ text }) => {
  if (text.startsWith('# ')) {
    return (
      <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-4 mb-2 flex items-center gap-2">
        <span className="w-1.5 h-5 rounded-full bg-cyan-400 inline-block shrink-0" />
        <InlineText text={text.replace(/^#\s+/, '')} />
      </h1>
    );
  }
  if (text.startsWith('## ')) {
    return (
      <h2 className="text-lg sm:text-xl font-semibold tracking-tight text-slate-100 mt-3.5 mb-2 flex items-center gap-2">
        <span className="w-1 h-4 rounded-full bg-indigo-400 inline-block shrink-0" />
        <InlineText text={text.replace(/^##\s+/, '')} />
      </h2>
    );
  }
  if (text.startsWith('### ')) {
    return (
      <h3 className="text-base sm:text-lg font-medium text-cyan-300 mt-3 mb-1.5">
        <InlineText text={text.replace(/^###\s+/, '')} />
      </h3>
    );
  }
  return (
    <h4 className="text-sm sm:text-base font-semibold text-slate-200 mt-2.5 mb-1">
      <InlineText text={text.replace(/^####\s+/, '')} />
    </h4>
  );
};

function isMarkdownTable(text: string): boolean {
  const lines = text.split('\n').filter(l => l.trim().length > 0);
  if (lines.length < 2) return false;
  return lines.some(l => l.includes('|') && /\|[\s-:]+\|/.test(l));
}

const MarkdownTable: React.FC<{ tableText: string }> = ({ tableText }) => {
  const lines = tableText.split('\n').map(l => l.trim()).filter(l => l.startsWith('|') || l.includes('|'));
  if (lines.length < 2) return <InlineText text={tableText} />;

  // Header is line 0
  const headers = lines[0]
    .split('|')
    .map(c => c.trim())
    .filter(c => c.length > 0);

  // Skip delimiter line (usually line 1 e.g. |---|---|)
  const dataLines = lines.slice(1).filter(l => !/^\|?[\s-:]+(\|[\s-:]+)+\|?$/.test(l));

  const rows = dataLines.map(line =>
    line
      .split('|')
      .map(c => c.trim())
      .filter(c => c.length > 0)
  );

  return (
    <div className="my-3 overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60 shadow-md">
      <table className="w-full text-left text-xs sm:text-sm">
        <thead className="bg-slate-900/90 text-cyan-300 border-b border-slate-800">
          <tr>
            {headers.map((h, hIdx) => (
              <th key={hIdx} className="px-4 py-2.5 font-semibold">
                <InlineText text={h} />
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {rows.map((row, rIdx) => (
            <tr key={rIdx} className="hover:bg-slate-900/40 transition-colors">
              {row.map((cell, cIdx) => (
                <td key={cIdx} className="px-4 py-2.5 text-slate-300">
                  <InlineText text={cell} />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

/**
 * Inline text parser for `code`, **bold**, *italic*, and [links](url)
 */
const InlineText: React.FC<{ text: string }> = ({ text }) => {
  // First split by inline code: `code`
  const codeSegments = text.split(/(`[^`]+`)/g);

  return (
    <>
      {codeSegments.map((segment, sIdx) => {
        if (segment.startsWith('`') && segment.endsWith('`')) {
          return (
            <code
              key={sIdx}
              className="px-1.5 py-0.5 mx-0.5 rounded-md bg-slate-800/90 text-cyan-300 font-mono text-xs sm:text-[13px] border border-cyan-500/20"
            >
              {segment.slice(1, -1)}
            </code>
          );
        }

        // Parse bold **text**
        const boldSegments = segment.split(/(\*\*[^*]+\*\*)/g);
        return (
          <React.Fragment key={sIdx}>
            {boldSegments.map((bSegment, bIdx) => {
              if (bSegment.startsWith('**') && bSegment.endsWith('**')) {
                return (
                  <strong key={bIdx} className="font-semibold text-white">
                    {parseItalic(bSegment.slice(2, -2))}
                  </strong>
                );
              }
              return <React.Fragment key={bIdx}>{parseItalic(bSegment)}</React.Fragment>;
            })}
          </React.Fragment>
        );
      })}
    </>
  );
};

function parseItalic(str: string): React.ReactNode {
  // Parse *italic* or _italic_
  const italicSegments = str.split(/(\*[^*]+\*|_[^_]+_)/g);
  return (
    <>
      {italicSegments.map((segment, i) => {
        if (
          (segment.startsWith('*') && segment.endsWith('*') && segment.length > 2) ||
          (segment.startsWith('_') && segment.endsWith('_') && segment.length > 2)
        ) {
          return (
            <em key={i} className="italic text-slate-200">
              {parseLinks(segment.slice(1, -1))}
            </em>
          );
        }
        return <React.Fragment key={i}>{parseLinks(segment)}</React.Fragment>;
      })}
    </>
  );
}

function parseLinks(str: string): React.ReactNode {
  const linkSegments = str.split(/(\[[^\]]+\]\([^)]+\))/g);
  return (
    <>
      {linkSegments.map((seg, i) => {
        const match = seg.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
        if (match) {
          return (
            <a
              key={i}
              href={match[2]}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2 transition-colors inline-flex items-center"
            >
              {match[1]}
            </a>
          );
        }
        return seg;
      })}
    </>
  );
}
