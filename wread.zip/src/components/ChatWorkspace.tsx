import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Send, 
  Square, 
  Paperclip, 
  Mic, 
  MicOff, 
  Copy, 
  Check, 
  RotateCcw, 
  Trash2, 
  Sparkles, 
  AlertCircle, 
  User, 
  Bot,
  X,
  Clock,
  ArrowDown,
  Download,
  PanelLeftClose,
  PanelLeft,
  Plus,
  Edit2,
  AlertTriangle,
  Globe,
  Volume2,
  VolumeX,
  ImageIcon,
  Camera,
  Maximize2,
  FileText
} from 'lucide-react';
import { Message, Conversation, MessageAttachment, AppSettings } from '../types';
import { sendChatMessage, APIClientError } from '../services/api';
import { FormattedResponse } from './FormattedResponse';
import { ChatHistoryPanel } from './ChatHistoryPanel';
import { VoiceAssistantService } from '../services/voiceService';

interface ChatWorkspaceProps {
  conversation: Conversation;
  conversations?: Conversation[];
  onUpdateConversation: (updated: Conversation) => void;
  onSelectConversation?: (id: string) => void;
  onNewChat: () => void;
  onRenameConversation?: (id: string, newTitle: string) => void;
  onDeleteConversation?: (id: string) => void;
  onClearChat: () => void;
  initialPrompt?: string;
  onRunAgentTask?: (prompt: string) => void;
  onResearchOnWeb?: (query: string) => void;
  settings?: AppSettings;
}

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  conversation,
  conversations = [],
  onUpdateConversation,
  onSelectConversation,
  onNewChat,
  onRenameConversation,
  onDeleteConversation,
  onClearChat,
  initialPrompt,
  onRunAgentTask,
  onResearchOnWeb,
  settings,
}) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeError, setActiveError] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<MessageAttachment[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [interimVoiceText, setInterimVoiceText] = useState<string>('');
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [thinkingSeconds, setThinkingSeconds] = useState(0);
  
  // History panel toggle (open by default on large screens if conversations exist)
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  
  // Clear chat modal confirmation
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Inline rename of current active conversation in header
  const [isRenamingHeader, setIsRenamingHeader] = useState(false);
  const [headerTitleInput, setHeaderTitleInput] = useState('');

  // Auto-scroll management
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isAtBottom, setIsAtBottom] = useState(true);
  const [hasScrolledUp, setHasScrolledUp] = useState(false);

  // Input & controller references
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const timerIntervalRef = useRef<any>(null);

  // Lightbox & Drag-and-drop state
  const [lightboxImage, setLightboxImage] = useState<{ src: string; title: string; size?: number } | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  // Helper to format file size cleanly
  const formatFileSize = (bytes?: number): string => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  // Check scroll position to determine whether to auto-scroll
  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const threshold = 100;
    const distanceToBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distanceToBottom <= threshold;
    setIsAtBottom(nearBottom);
    setHasScrolledUp(!nearBottom && el.scrollTop > 150);
  };

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  // Auto-scroll when new messages arrive, ONLY if user is near bottom
  useEffect(() => {
    if (isAtBottom) {
      scrollToBottom('smooth');
    }
  }, [conversation.messages, isLoading, isAtBottom, scrollToBottom]);

  // Initial prompt trigger (e.g. from Home workspace quick actions)
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim().length > 0) {
      handleSendMessage(initialPrompt.trim());
    }
  }, [initialPrompt]);

  // Auto-resize textarea to fit multiline content
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [inputText]);

  // Thinking timer ticker
  useEffect(() => {
    if (isLoading) {
      setThinkingSeconds(0);
      timerIntervalRef.current = setInterval(() => {
        setThinkingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isLoading]);

  // Clean up voice synthesis & listening on unmount
  useEffect(() => {
    return () => {
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.stopListening();
    };
  }, []);

  // Voice dictation toggle (Speech-to-Text via VoiceAssistantService)
  const toggleSpeechRecognition = () => {
    if (isRecording) {
      VoiceAssistantService.stopListening();
      setIsRecording(false);
      setInterimVoiceText('');
      return;
    }

    if (!VoiceAssistantService.isSTTSupported()) {
      setActiveError('Speech recognition is not supported in this browser. Please use Chrome, Edge, or Android Chrome.');
      return;
    }

    // Stop speech if speaking
    VoiceAssistantService.stopSpeaking();
    setSpeakingMessageId(null);
    setActiveError(null);

    VoiceAssistantService.startListening(
      {
        onStart: () => {
          setIsRecording(true);
        },
        onInterim: (interim) => {
          setInterimVoiceText(interim);
        },
        onFinal: (finalText) => {
          setInputText(prev => (prev ? `${prev.trim()} ${finalText}` : finalText));
          setInterimVoiceText('');
        },
        onError: (errMsg) => {
          setActiveError(errMsg);
          setIsRecording(false);
          setInterimVoiceText('');
        },
        onEnd: () => {
          setIsRecording(false);
          setInterimVoiceText('');
        },
      },
      settings?.voiceLanguage || 'auto'
    );
  };

  // Text-to-Speech Playback Toggle
  const handleToggleSpeak = (msgId: string, content: string) => {
    if (speakingMessageId === msgId) {
      VoiceAssistantService.stopSpeaking();
      setSpeakingMessageId(null);
    } else {
      VoiceAssistantService.stopSpeaking();
      VoiceAssistantService.speak(content, {
        language: settings?.voiceLanguage || 'auto',
        rate: settings?.speechRate || 1.0,
        onStart: () => setSpeakingMessageId(msgId),
        onEnd: () => setSpeakingMessageId(null),
        onError: () => setSpeakingMessageId(null),
      });
    }
  };

  // Validate and process selected image file (JPG, JPEG, PNG, WEBP, max 10MB)
  const processSelectedImageFile = (file: File) => {
    setActiveError(null);

    // 1. Validate file format
    const validExtensions = /\.(jpe?g|png|webp)$/i;
    const validMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const isMimeValid = validMimes.includes(file.type.toLowerCase());
    const isExtValid = validExtensions.test(file.name);

    if (!isMimeValid && !isExtValid) {
      setActiveError('Unsupported file format. WREAD supports JPG, JPEG, PNG, and WEBP images.');
      return;
    }

    // 2. Validate file size (10 MB max)
    const maxBytes = 10 * 1024 * 1024;
    if (file.size > maxBytes) {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
      setActiveError(`Image is too large (${sizeMB} MB). Maximum allowed size is 10 MB.`);
      return;
    }

    // 3. Read file as Data URL
    const reader = new FileReader();
    reader.onerror = () => {
      setActiveError('Failed to read image file. Please try selecting the image again.');
    };
    reader.onload = () => {
      const base64 = reader.result as string;
      if (!base64) {
        setActiveError('Could not process image contents.');
        return;
      }
      setAttachments(prev => [
        ...prev,
        {
          name: file.name || 'image.jpg',
          type: file.type || 'image/jpeg',
          base64,
          size: file.size,
        },
      ]);
    };
    reader.readAsDataURL(file);
  };

  // Image file picker handler (Gallery / File system)
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    for (let i = 0; i < files.length; i++) {
      processSelectedImageFile(files[i]);
    }
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  // Mobile camera capture handler
  const handleCameraSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    processSelectedImageFile(files[0]);
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  // General file attachment handling (docs, code, json)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    // If user picked an image through general picker, route to specialized validator
    if (file.type.startsWith('image/') || file.name.match(/\.(jpe?g|png|webp)$/i)) {
      processSelectedImageFile(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      setAttachments(prev => [
        ...prev,
        {
          name: file.name,
          type: file.type,
          base64,
          size: file.size,
        },
      ]);
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Clipboard paste handler (captures screenshots automatically)
  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        const file = items[i].getAsFile();
        if (file) {
          processSelectedImageFile(file);
        }
      }
    }
  };

  // Drag and drop handlers on message composer
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);

    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/') || file.name.match(/\.(jpe?g|png|webp)$/i)) {
        processSelectedImageFile(file);
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          setAttachments(prev => [
            ...prev,
            {
              name: file.name,
              type: file.type,
              base64: reader.result as string,
              size: file.size,
            },
          ]);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Stop AI generation (safe client-side cancellation)
  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    VoiceAssistantService.stopSpeaking();
    VoiceAssistantService.stopListening();
    setSpeakingMessageId(null);
    setIsRecording(false);
    setIsLoading(false);
    setActiveError('Request cancelled by user.');
  };

  // Primary Send Message Action (handles text, text+image, and image-only messages)
  const handleSendMessage = async (textToSend?: string) => {
    const rawText = typeof textToSend === 'string' ? textToSend : inputText;
    const hasAttachments = attachments.length > 0;
    if (!rawText.trim() && !hasAttachments) return;
    if (isLoading) return;

    // For image-only messages, use a clear analytical prompt
    const hasImages = attachments.some(
      a => a.type?.startsWith('image/') || a.name?.match(/\.(jpe?g|png|webp)$/i)
    );
    const displayText = rawText.trim()
      ? rawText.trim()
      : hasImages
      ? 'Please analyze this image, describe what you see, and highlight any key details, visible text, diagrams, or errors.'
      : 'Attached file';

    // Stop active speech playback and voice listening
    VoiceAssistantService.stopSpeaking();
    VoiceAssistantService.stopListening();
    setSpeakingMessageId(null);
    setIsRecording(false);
    setActiveError(null);

    const now = Date.now();
    const userMessage: Message = {
      id: 'msg_' + now,
      role: 'user',
      content: displayText,
      createdAt: now,
      timestamp: now,
      attachments: attachments.length > 0 ? [...attachments] : undefined,
    };

    const newMessages = [...conversation.messages, userMessage];
    
    // Auto-derive conversation title from the first message or image name
    let derivedTitle = conversation.title;
    if (conversation.messages.length === 0) {
      if (rawText.trim()) {
        derivedTitle = rawText.trim().slice(0, 36) + (rawText.trim().length > 36 ? '...' : '');
      } else if (hasImages) {
        const firstImg = attachments.find(
          a => a.type?.startsWith('image/') || a.name?.match(/\.(jpe?g|png|webp)$/i)
        );
        derivedTitle = `Image: ${firstImg?.name || 'Inspection'}`.slice(0, 36);
      }
    }

    onUpdateConversation({
      ...conversation,
      title: derivedTitle,
      messages: newMessages,
      updatedAt: now,
    });

    setInputText('');
    setAttachments([]);
    setIsLoading(true);

    // Setup AbortController for client cancellation
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Build conversation payload preserving attachments and images for multimodal inference
      const chatPayload = newMessages
        .filter(m => (m.role === 'user' || m.role === 'assistant') && m.status !== 'error')
        .map(m => ({
          role: m.role as 'user' | 'assistant',
          content: m.content.trim(),
          attachments: m.attachments,
        }));

      const response = await sendChatMessage(chatPayload, {
        signal: controller.signal,
      });

      const completedTime = Date.now();
      const assistantMessage: Message = {
        id: 'msg_' + completedTime,
        role: 'assistant',
        content: response.content,
        createdAt: completedTime,
        timestamp: completedTime,
        model: response.model,
        provider: response.provider,
        reasoning: response.reasoning,
        status: 'complete',
      };

      onUpdateConversation({
        ...conversation,
        title: derivedTitle,
        messages: [...newMessages, assistantMessage],
        updatedAt: completedTime,
      });

      // Auto voice readout if enabled in settings
      if (settings?.voiceOutputEnabled) {
        VoiceAssistantService.speak(response.content, {
          language: settings?.voiceLanguage || 'auto',
          rate: settings?.speechRate || 1.0,
          onStart: () => setSpeakingMessageId(assistantMessage.id),
          onEnd: () => setSpeakingMessageId(null),
          onError: () => setSpeakingMessageId(null),
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError' || err.code === 'ABORTED') {
        setActiveError('Request cancelled.');
        return;
      }

      const errorMsg =
        err instanceof APIClientError
          ? err.message
          : err.message || 'Something went wrong while connecting to WREAD AI.';
      setActiveError(errorMsg);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  // Retry failed user message
  const handleRetry = async () => {
    if (isLoading || conversation.messages.length === 0) return;

    // Stop active speech playback and voice listening
    VoiceAssistantService.stopSpeaking();
    VoiceAssistantService.stopListening();
    setSpeakingMessageId(null);
    setIsRecording(false);

    // Find the last user message
    const lastUserMsg = [...conversation.messages].reverse().find(m => m.role === 'user');
    if (!lastUserMsg) return;

    // Remove any trailing error state from the list
    const lastUserIdx = conversation.messages.findLastIndex(m => m.id === lastUserMsg.id);
    const messagesToKeep = conversation.messages.slice(0, lastUserIdx + 1);

    onUpdateConversation({
      ...conversation,
      messages: messagesToKeep,
      updatedAt: Date.now(),
    });

    setIsLoading(true);
    setActiveError(null);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const chatPayload = messagesToKeep
        .filter(m => (m.role === 'user' || m.role === 'assistant') && m.status !== 'error')
        .map(m => ({
          role: m.role as 'user' | 'assistant',
          content: m.content,
        }));

      const response = await sendChatMessage(chatPayload, {
        signal: controller.signal,
      });

      const completedTime = Date.now();
      const assistantMessage: Message = {
        id: 'msg_' + completedTime,
        role: 'assistant',
        content: response.content,
        createdAt: completedTime,
        timestamp: completedTime,
        model: response.model,
        provider: response.provider,
        reasoning: response.reasoning,
        status: 'complete',
      };

      onUpdateConversation({
        ...conversation,
        messages: [...messagesToKeep, assistantMessage],
        updatedAt: completedTime,
      });

      // Auto voice readout if enabled in settings
      if (settings?.voiceOutputEnabled) {
        VoiceAssistantService.speak(response.content, {
          language: settings?.voiceLanguage || 'auto',
          rate: settings?.speechRate || 1.0,
          onStart: () => setSpeakingMessageId(assistantMessage.id),
          onEnd: () => setSpeakingMessageId(null),
          onError: () => setSpeakingMessageId(null),
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError' || err.code === 'ABORTED') {
        setActiveError('Request cancelled.');
        return;
      }

      const errorMsg = err.message || 'Something went wrong.';
      setActiveError(errorMsg);
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  // Copy message text with visual feedback
  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  };

  // Export conversation transcript as Markdown
  const handleExportChat = () => {
    const transcript = conversation.messages
      .map(
        m =>
          `### ${m.role === 'user' ? 'User' : 'WREAD AI (' + (m.model || 'Kimi-K3') + ')'} [${new Date(
            m.createdAt || m.timestamp || Date.now()
          ).toLocaleString()}]\n\n${m.content}\n\n`
      )
      .join('---\n\n');

    const blob = new Blob([transcript], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wread-chat-${conversation.id}-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Save header title rename
  const handleSaveHeaderTitle = () => {
    if (headerTitleInput.trim() && onRenameConversation) {
      onRenameConversation(conversation.id, headerTitleInput.trim());
    } else if (headerTitleInput.trim()) {
      onUpdateConversation({
        ...conversation,
        title: headerTitleInput.trim(),
        updatedAt: Date.now(),
      });
    }
    setIsRenamingHeader(false);
  };

  return (
    <div className="flex-1 flex h-full w-full overflow-hidden relative">
      {/* Optional Collapsible Chat History Drawer / Sidebar */}
      {conversations.length > 0 && (
        <ChatHistoryPanel
          conversations={conversations}
          activeId={conversation.id}
          onSelectConversation={(id) => {
            if (onSelectConversation) onSelectConversation(id);
            if (window.innerWidth < 768) setIsHistoryOpen(false);
          }}
          onNewChat={() => {
            onNewChat();
            if (window.innerWidth < 768) setIsHistoryOpen(false);
          }}
          onRenameConversation={(id, newTitle) => {
            if (onRenameConversation) onRenameConversation(id, newTitle);
          }}
          onDeleteConversation={(id) => {
            if (onDeleteConversation) onDeleteConversation(id);
          }}
          isOpen={isHistoryOpen}
          onClose={() => setIsHistoryOpen(false)}
        />
      )}

      {/* Main Chat Workspace Column */}
      <div className="flex-1 flex flex-col h-full max-w-4xl w-full mx-auto relative min-w-0">
        {/* Top Conversation Header Bar */}
        <div className="px-4 py-3 border-b border-white/[0.08] glass-panel flex items-center justify-between shrink-0 z-10 gap-3">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            {/* Toggle History Button */}
            <button
              onClick={() => setIsHistoryOpen(!isHistoryOpen)}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer shrink-0 ${
                isHistoryOpen
                  ? 'bg-cyan-950/50 border-cyan-500/40 text-cyan-300'
                  : 'bg-slate-900/80 border-white/[0.08] text-slate-400 hover:text-white'
              }`}
              title={isHistoryOpen ? 'Hide conversation history' : 'Show conversation history'}
            >
              {isHistoryOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeft className="w-4 h-4" />}
            </button>

            <div className="w-2 h-2 rounded-full bg-cyan-400 shrink-0 animate-pulse" />

            {/* Editable or Static Conversation Title */}
            {isRenamingHeader ? (
              <div className="flex items-center gap-1 min-w-0 max-w-sm">
                <input
                  type="text"
                  autoFocus
                  value={headerTitleInput}
                  onChange={(e) => setHeaderTitleInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveHeaderTitle();
                    if (e.key === 'Escape') setIsRenamingHeader(false);
                  }}
                  className="px-2 py-0.5 bg-slate-950 border border-cyan-400 rounded text-xs text-white focus:outline-none"
                />
                <button
                  onClick={handleSaveHeaderTitle}
                  className="p-1 text-cyan-400 hover:text-cyan-200"
                  title="Save title"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setIsRenamingHeader(false)}
                  className="p-1 text-slate-400 hover:text-slate-200"
                  title="Cancel"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 min-w-0 truncate">
                <h2
                  className="text-sm font-semibold text-slate-100 truncate cursor-pointer hover:text-cyan-300 transition-colors"
                  onClick={() => {
                    setHeaderTitleInput(conversation.title || 'New Conversation');
                    setIsRenamingHeader(true);
                  }}
                  title="Click to rename conversation"
                >
                  {conversation.title || 'New Conversation'}
                </h2>
                <button
                  onClick={() => {
                    setHeaderTitleInput(conversation.title || 'New Conversation');
                    setIsRenamingHeader(true);
                  }}
                  className="text-slate-500 hover:text-slate-300 p-0.5 rounded opacity-60 hover:opacity-100 transition-opacity"
                  title="Rename chat"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
                <span className="text-[11px] font-mono text-slate-300 hidden sm:inline shrink-0">
                  ({conversation.messages.length} msgs)
                </span>
              </div>
            )}
          </div>

          {/* Action buttons: New Chat, Export, Clear Chat */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={onNewChat}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600/80 to-indigo-600/80 hover:from-cyan-600 hover:to-indigo-600 text-white text-xs font-medium transition-all shadow-sm cursor-pointer"
              title="Start a new chat (⌘N)"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Chat</span>
            </button>

            <button
              onClick={handleExportChat}
              disabled={conversation.messages.length === 0}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors disabled:opacity-30 cursor-pointer"
              title="Export conversation as Markdown"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowClearConfirm(true)}
              disabled={conversation.messages.length === 0}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors disabled:opacity-30 cursor-pointer"
              title="Clear all messages in this conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Clear Chat Confirmation Modal */}
        {showClearConfirm && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <div className="bg-slate-900 border border-slate-700/80 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-rose-400" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Clear Conversation?</h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    This will delete all messages in the current conversation. This action cannot be undone.
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    onClearChat();
                    setShowClearConfirm(false);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium transition-colors shadow-md"
                >
                  Clear Messages
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Messages Scroll Area */}
        <div 
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-4 py-6 space-y-6 scroll-smooth"
        >
          {conversation.messages.length === 0 ? (
            /* Empty State */
            <div className="h-full flex flex-col items-center justify-center text-center px-4 py-12">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-indigo-500/20 to-purple-600/20 border border-white/10 flex items-center justify-center mb-4 shadow-xl">
                <Bot className="w-7 h-7 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-slate-100 mb-1">
                WREAD Intelligent AI Assistant
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-sm mb-6 leading-relaxed">
                Connected to Kimi-K3 neural engine. Ask technical questions, reason through logic, or draft specifications.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-md w-full">
                {[
                  'Explain zero-knowledge rollups architecture',
                  'Write a resilient TypeScript retry loop',
                  'Compare RPC vs REST for distributed agents',
                  'Draft best practices for secret sanitization',
                ].map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(suggestion)}
                    className="p-3 rounded-xl glass-card text-left text-xs text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 transition-all cursor-pointer"
                  >
                    "{suggestion}"
                  </button>
                ))}
              </div>
            </div>
          ) : (
            conversation.messages.map((message, messageIndex) => {
              const isUser = message.role === 'user';
              const isErrorMessage = message.status === 'error';
              const messageTime = message.createdAt || message.timestamp || Date.now();

              return (
                <div
                  key={message.id}
                  className={`flex gap-3 sm:gap-4 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-xl bg-slate-900 border border-cyan-500/40 flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-cyan-500/10">
                      <Bot className="w-4 h-4 text-cyan-400" />
                    </div>
                  )}

                  <div className={`flex flex-col max-w-[90%] sm:max-w-[82%] ${isUser ? 'items-end' : 'items-start'}`}>
                    {/* Message Bubble */}
                    <div
                      className={`rounded-2xl p-4 sm:p-5 text-sm sm:text-base leading-relaxed ${
                        isUser
                          ? 'bg-gradient-to-br from-cyan-600/90 to-indigo-600/90 text-white shadow-lg shadow-cyan-900/20'
                          : isErrorMessage
                          ? 'bg-rose-950/40 border border-rose-500/30 text-rose-200'
                          : 'glass-card border border-white/[0.08] text-slate-100 shadow-md'
                      }`}
                    >
                      {/* Attachments preview */}
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mb-3 space-y-2.5">
                          {/* Image indicator header if any image attached */}
                          {message.attachments.some(
                            a => a.type?.startsWith('image/') || a.name?.match(/\.(jpe?g|png|webp)$/i)
                          ) && (
                            <div className="flex items-center gap-1.5 text-xs text-cyan-200/90 font-medium">
                              <ImageIcon className="w-3.5 h-3.5 text-cyan-300 shrink-0" />
                              <span>Image Attached</span>
                            </div>
                          )}

                          <div className="flex flex-wrap gap-2.5">
                            {message.attachments.map((att, attIdx) => {
                              const isImage =
                                att.type?.startsWith('image/') ||
                                att.base64?.startsWith('data:image/') ||
                                att.name?.match(/\.(jpe?g|png|webp)$/i);

                              if (isImage) {
                                return (
                                  <div
                                    key={attIdx}
                                    onClick={() =>
                                      setLightboxImage({
                                        src: att.base64,
                                        title: att.name,
                                        size: att.size,
                                      })
                                    }
                                    className="group relative rounded-xl overflow-hidden bg-black/40 border border-white/15 hover:border-cyan-400/60 transition-all cursor-pointer shadow-md max-w-xs"
                                    title="Click to view full image"
                                  >
                                    <img
                                      src={att.base64}
                                      alt={att.name}
                                      referrerPolicy="no-referrer"
                                      className="max-h-56 max-w-full w-auto object-cover rounded-lg group-hover:scale-[1.02] transition-transform duration-200"
                                    />
                                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-2 pt-4 flex items-center justify-between text-[11px] text-slate-200">
                                      <span className="font-mono truncate max-w-[150px]">{att.name}</span>
                                      {att.size && (
                                        <span className="text-[10px] text-slate-300 shrink-0 ml-2">
                                          {formatFileSize(att.size)}
                                        </span>
                                      )}
                                    </div>
                                    <div className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs">
                                      <Maximize2 className="w-3.5 h-3.5" />
                                    </div>
                                  </div>
                                );
                              }

                              return (
                                <div
                                  key={attIdx}
                                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/30 border border-white/10 text-xs"
                                >
                                  <Paperclip className="w-3.5 h-3.5 text-cyan-300" />
                                  <span className="font-mono truncate max-w-[150px]">{att.name}</span>
                                  {att.size && (
                                    <span className="text-[10px] text-slate-400">
                                      ({formatFileSize(att.size)})
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Content */}
                      {isUser ? (
                        <p className="whitespace-pre-wrap">{message.content}</p>
                      ) : (
                        <FormattedResponse content={message.content} />
                      )}
                    </div>

                    {/* Metadata & Actions Bar */}
                    <div className="flex items-center gap-2.5 mt-1.5 px-1 text-[11px] text-slate-300">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(messageTime).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>

                      {isUser && onRunAgentTask && (
                        <>
                          <span>•</span>
                          <button
                            onClick={() => onRunAgentTask(message.content)}
                            className="hover:text-purple-300 text-purple-400 hover:bg-purple-950/60 bg-purple-950/30 border border-purple-500/20 hover:border-purple-500/50 px-2 py-0.5 rounded transition-all flex items-center gap-1 cursor-pointer font-medium text-[11px]"
                            title="Open in Agent Mode with this task prefilled"
                          >
                            <Bot className="w-3 h-3 text-purple-400" />
                            <span>Run with Agent</span>
                          </button>
                        </>
                      )}

                      {isUser && onResearchOnWeb && (
                        <>
                          <span>•</span>
                          <button
                            onClick={() => onResearchOnWeb(message.content)}
                            className="hover:text-emerald-300 text-emerald-400 hover:bg-emerald-950/60 bg-emerald-950/30 border border-emerald-500/20 hover:border-emerald-500/50 px-2 py-0.5 rounded transition-all flex items-center gap-1 cursor-pointer font-medium text-[11px]"
                            title="Research this query on the public web"
                          >
                            <Globe className="w-3 h-3 text-emerald-400" />
                            <span>Research this on the web</span>
                          </button>
                        </>
                      )}

                      {!isUser && (
                        <>
                          <span>•</span>
                          <span className="font-mono text-cyan-400">
                            {message.model ? message.model.replace('moonshotai/', '') : 'Kimi-K3'}
                          </span>
                          <span>•</span>
                          <button
                            onClick={() => handleCopyMessage(message.id, message.content)}
                            className="hover:text-slate-100 transition-colors flex items-center gap-1 cursor-pointer font-medium"
                            title="Copy response to clipboard"
                          >
                            {copiedMessageId === message.id ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>

                          <span>•</span>
                          <button
                            onClick={() => handleToggleSpeak(message.id, message.content)}
                            className={`flex items-center gap-1 cursor-pointer font-medium transition-colors ${
                              speakingMessageId === message.id
                                ? 'text-cyan-300 font-semibold'
                                : 'hover:text-slate-100 text-slate-300'
                            }`}
                            title={
                              speakingMessageId === message.id
                                ? 'Stop reading aloud'
                                : 'Read response aloud (Voice Assistant)'
                            }
                          >
                            {speakingMessageId === message.id ? (
                              <>
                                <VolumeX className="w-3 h-3 text-rose-400 animate-pulse" />
                                <span className="text-cyan-300">Stop</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3 h-3 text-cyan-400" />
                                <span>Read Aloud</span>
                              </>
                            )}
                          </button>

                          {onResearchOnWeb && (
                            <>
                              <span>•</span>
                              <button
                                onClick={() => {
                                  const prevMsg = conversation.messages.slice(0, messageIndex).reverse().find(m => m.role === 'user');
                                  onResearchOnWeb(prevMsg?.content || message.content.slice(0, 100));
                                }}
                                className="hover:text-emerald-300 text-slate-400 hover:bg-emerald-950/40 px-2 py-0.5 rounded transition-all flex items-center gap-1 cursor-pointer text-[11px]"
                                title="Research this topic on the public web"
                              >
                                <Globe className="w-3 h-3 text-emerald-400" />
                                <span>Research on web</span>
                              </button>
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4 text-cyan-200" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Elegant Loading / Thinking State (Requirement 6: No fake answer) */}
          {isLoading && (
            <div className="flex gap-3 sm:gap-4 justify-start">
              <div className="w-8 h-8 rounded-xl bg-slate-900 border border-cyan-500/40 flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-cyan-500/20 animate-pulse">
                <Sparkles className="w-4 h-4 text-cyan-400" />
              </div>

              <div className="glass-card border border-cyan-500/20 rounded-2xl p-4 sm:p-5 max-w-[85%] sm:max-w-[75%] space-y-2.5">
                <div className="flex items-center gap-2.5 text-xs text-cyan-300 font-medium">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
                  </span>
                  <span>WREAD AI Processing ({thinkingSeconds}s)...</span>
                </div>

                {/* Animated pulse bars */}
                <div className="space-y-1.5 py-1">
                  <div className="h-1.5 bg-gradient-to-r from-cyan-500/40 via-indigo-500/40 to-transparent rounded-full animate-pulse w-3/4" />
                  <div className="h-1.5 bg-gradient-to-r from-indigo-500/40 via-purple-500/40 to-transparent rounded-full animate-pulse w-1/2 delay-100" />
                </div>

                <div className="text-[11px] text-slate-300 font-mono">
                  Model: Kimi-K3 on Modal US-West • Multi-turn context loaded
                </div>
              </div>
            </div>
          )}

          {/* Error Banner with Retry (Requirement 8) */}
          {activeError && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 flex items-center justify-between gap-3 text-xs text-rose-300 shadow-md">
              <div className="flex items-center gap-2 min-w-0">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <div className="flex flex-col">
                  <span className="font-semibold text-rose-200">Something went wrong.</span>
                  <span className="text-[11px] text-rose-300/80 truncate">{activeError}</span>
                </div>
              </div>
              <button
                onClick={handleRetry}
                className="px-3 py-1.5 rounded-lg bg-rose-900/80 hover:bg-rose-800 text-rose-100 font-medium flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow"
                title="Retry sending the message"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Floating "Scroll to Bottom" Button (Requirement 11) */}
        {hasScrolledUp && (
          <button
            onClick={() => scrollToBottom('smooth')}
            className="absolute bottom-28 right-6 p-2 rounded-full bg-slate-900/90 border border-cyan-500/40 text-cyan-300 hover:text-white hover:bg-cyan-900/50 shadow-lg transition-all cursor-pointer z-20 flex items-center gap-1 text-xs"
            title="Jump to latest message"
          >
            <ArrowDown className="w-4 h-4" />
            <span className="hidden sm:inline pr-1">Latest</span>
          </button>
        )}

        {/* Message Composer Area (Requirement 1, 2, 3, 4, 10) */}
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative p-3 sm:p-4 border-t border-white/[0.08] glass-panel shrink-0 space-y-2.5 transition-colors ${
            isDraggingOver ? 'bg-cyan-950/30 ring-2 ring-cyan-500/50' : ''
          }`}
        >
          {/* Drag and drop overlay banner */}
          {isDraggingOver && (
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs rounded-t-xl z-30 flex items-center justify-center gap-3 border-2 border-dashed border-cyan-400 text-cyan-300">
              <ImageIcon className="w-6 h-6 animate-bounce" />
              <span className="font-semibold text-sm">Drop image here to analyze</span>
            </div>
          )}

          {/* Staged Attachments Preview with Image Thumbnails (Requirement 3) */}
          {attachments.length > 0 && (
            <div className="space-y-1.5 pb-1">
              <div className="flex items-center justify-between text-[11px] text-slate-300 px-1">
                <span className="font-medium">Attached files ({attachments.length}):</span>
                <button
                  type="button"
                  onClick={() => setAttachments([])}
                  className="text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                >
                  Clear all
                </button>
              </div>

              <div className="flex flex-wrap gap-2.5">
                {attachments.map((att, idx) => {
                  const isImage =
                    att.type?.startsWith('image/') ||
                    att.base64?.startsWith('data:image/') ||
                    att.name?.match(/\.(jpe?g|png|webp)$/i);

                  if (isImage) {
                    return (
                      <div
                        key={idx}
                        className="group relative flex items-center gap-3 p-2 pr-3 rounded-xl bg-slate-900/90 border border-cyan-500/30 shadow-md max-w-xs"
                      >
                        <div 
                          onClick={() => setLightboxImage({ src: att.base64, title: att.name, size: att.size })}
                          className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-black/50 border border-white/10 cursor-pointer"
                          title="Click to preview image"
                        >
                          <img
                            src={att.base64}
                            alt={att.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <Maximize2 className="w-3 h-3 text-white" />
                          </div>
                        </div>

                        <div className="flex flex-col min-w-0 pr-1">
                          <span className="text-xs font-semibold text-slate-100 truncate max-w-[130px]" title={att.name}>
                            {att.name}
                          </span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] text-slate-300">{formatFileSize(att.size)}</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                              Vision Ready
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => removeAttachment(idx)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer shrink-0 ml-auto"
                          title="Remove image"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={idx}
                      className="flex items-center gap-2 p-2 px-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-slate-200"
                    >
                      <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
                      <div className="flex flex-col min-w-0">
                        <span className="truncate max-w-[140px] font-medium">{att.name}</span>
                        <span className="text-[10px] text-slate-400">{formatFileSize(att.size)}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeAttachment(idx)}
                        className="p-1 hover:text-rose-400 cursor-pointer ml-1"
                        title="Remove file"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Voice recording interim status indicator */}
          {isRecording && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-xs text-cyan-200 animate-pulse">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
              </span>
              <span className="font-semibold text-cyan-300">
                Listening ({settings?.voiceLanguage === 'hi-IN' ? 'Hindi (हिन्दी)' : settings?.voiceLanguage === 'en-US' ? 'English' : 'Auto Detect'}):
              </span>
              <span className="italic truncate text-slate-300">
                {interimVoiceText || 'Speak now... (Tap Mic to finish)'}
              </span>
            </div>
          )}

          <div className="relative flex items-end gap-1.5 bg-slate-950/80 rounded-2xl border border-white/[0.1] focus-within:border-cyan-500/50 p-2 shadow-xl transition-all">
            {/* Hidden file inputs for Image, Mobile Camera, and Documents */}
            <input
              type="file"
              ref={imageInputRef}
              onChange={handleImageSelect}
              className="hidden"
              accept="image/jpeg,image/png,image/webp,image/jpg"
            />
            <input
              type="file"
              ref={cameraInputRef}
              onChange={handleCameraSelect}
              className="hidden"
              accept="image/jpeg,image/png,image/webp,image/jpg"
              capture="environment"
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              accept="*/*"
            />

            {/* 1. Image Attachment Button (Requirement 1 & 2: Gallery / Image file) */}
            <button
              type="button"
              onClick={() => imageInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
              title="Attach image (JPG, PNG, WEBP)"
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            {/* 2. Camera Button (Requirement 2: Mobile camera capture) */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
              title="Take photo with Camera"
            >
              <Camera className="w-4 h-4" />
            </button>

            {/* 3. General Document / Code File Attach Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-900 transition-colors cursor-pointer shrink-0"
              title="Attach document or text file"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* 4. Speech to text Mic */}
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className={`p-2 rounded-xl transition-colors cursor-pointer shrink-0 ${
                isRecording
                  ? 'text-rose-400 bg-rose-950/50 animate-pulse'
                  : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-900'
              }`}
              title={isRecording ? 'Listening (Click to stop)' : 'Voice input'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Multiline auto-expanding textarea with screenshot paste support (Requirement 4) */}
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onPaste={handlePaste}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={
                isRecording
                  ? 'Listening to voice...'
                  : attachments.some(a => a.type?.startsWith('image/') || a.name?.match(/\.(jpe?g|png|webp)$/i))
                  ? 'Ask a question about this image, or press Enter to analyze...'
                  : 'Ask WREAD anything... (Enter to send, Shift+Enter for newline)'
              }
              className="flex-1 bg-transparent border-0 text-sm sm:text-base text-slate-100 placeholder:text-slate-400 focus:outline-none resize-none py-1.5 px-1 max-h-44 leading-relaxed"
            />

            {/* Send or Stop Button (Requirement 7 & 12) */}
            {isLoading ? (
              <button
                type="button"
                onClick={handleStopGeneration}
                className="px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold shrink-0 shadow-md"
                title="Stop AI generation"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={!inputText.trim() && attachments.length === 0}
                onClick={() => handleSendMessage()}
                className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-20 disabled:pointer-events-none text-white transition-all shadow-md shadow-cyan-900/30 cursor-pointer flex items-center justify-center shrink-0"
                title="Send message (Enter)"
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-300 px-1">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
              <span>Kimi-K3 Neural Gateway</span>
              <span className="text-slate-400">•</span>
              <span className="text-cyan-300/90 font-medium">Vision Enabled (JPG, PNG, WEBP)</span>
            </span>
            <span className="hidden sm:inline">Paste screenshots directly • Enter to send</span>
          </div>
        </div>

        {/* High-Resolution Image Lightbox Modal */}
        {lightboxImage && (
          <div 
            onClick={() => setLightboxImage(null)}
            className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col items-center justify-center p-4 sm:p-6"
          >
            <div 
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl max-h-[90vh] w-full flex flex-col items-center"
            >
              {/* Top Header Bar */}
              <div className="w-full flex items-center justify-between p-3 bg-slate-950/80 rounded-t-2xl border border-white/10 text-white backdrop-blur-xs">
                <div className="flex items-center gap-2 min-w-0 pr-4">
                  <ImageIcon className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="text-sm font-semibold truncate">{lightboxImage.title}</span>
                  {lightboxImage.size && (
                    <span className="text-xs text-slate-400 font-mono">
                      ({formatFileSize(lightboxImage.size)})
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={lightboxImage.src}
                    download={lightboxImage.title}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                    title="Download image"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                  <button
                    onClick={() => setLightboxImage(null)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-300 transition-colors cursor-pointer"
                    title="Close preview"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Main Image Container */}
              <div className="w-full max-h-[80vh] overflow-auto flex items-center justify-center p-2 bg-black/60 rounded-b-2xl border-x border-b border-white/10">
                <img
                  src={lightboxImage.src}
                  alt={lightboxImage.title}
                  referrerPolicy="no-referrer"
                  className="max-h-[76vh] max-w-full object-contain rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
