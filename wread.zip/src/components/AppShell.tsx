import React, { useState } from 'react';
import { 
  Home, 
  MessageSquare, 
  Bot, 
  Search, 
  Image as ImageIcon, 
  Brain, 
  CheckSquare, 
  Settings, 
  Sparkles,
  Server,
  Activity,
  Cpu,
  ChevronRight,
  Menu,
  X,
  Plus
} from 'lucide-react';
import { ActiveWorkspace, BackendHealth } from '../types';

interface AppShellProps {
  activeWorkspace: ActiveWorkspace;
  setActiveWorkspace: (ws: ActiveWorkspace) => void;
  backendHealth: BackendHealth;
  onNewChat?: () => void;
  recentChats?: Array<{ id: string; title: string }>;
  activeChatId?: string | null;
  onSelectChat?: (id: string) => void;
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({
  activeWorkspace,
  setActiveWorkspace,
  backendHealth,
  onNewChat,
  recentChats = [],
  activeChatId,
  onSelectChat,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);

  const navItems = [
    { id: 'home' as ActiveWorkspace, label: 'Home', icon: Home },
    { id: 'chat' as ActiveWorkspace, label: 'Ask AI', icon: MessageSquare },
    { id: 'agent' as ActiveWorkspace, label: 'Agent Mode', icon: Bot },
    { id: 'research' as ActiveWorkspace, label: 'Web Research', icon: Search },
    { id: 'vision' as ActiveWorkspace, label: 'Analyze Image', icon: ImageIcon },
    { id: 'memory' as ActiveWorkspace, label: 'Memory', icon: Brain },
    { id: 'tasks' as ActiveWorkspace, label: 'Tasks', icon: CheckSquare },
    { id: 'settings' as ActiveWorkspace, label: 'Settings', icon: Settings },
  ];

  // Derive status badge details
  const isBackendConnected = backendHealth.backend === 'ok';
  const isConfigured = backendHealth.configured;
  const isProviderOnline = backendHealth.onlineConfirmed;

  const handleNavClick = (id: ActiveWorkspace) => {
    setActiveWorkspace(id);
    setMobileMenuOpen(false);
  };

  return (
    <div id="wread-app-shell" className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col antialiased selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background ambient lighting gradients */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[140px]" />
        <div className="absolute top-[40%] right-[-5%] w-[450px] h-[450px] bg-purple-600/10 rounded-full blur-[160px]" />
        <div className="absolute bottom-[-10%] left-[5%] w-[400px] h-[400px] bg-cyan-600/8 rounded-full blur-[130px]" />
      </div>

      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 h-14 border-b border-white/[0.08] glass-panel px-4 sm:px-6 flex items-center justify-between">
        {/* Left: Branding & Status */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Toggle navigation drawer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div 
            onClick={() => handleNavClick('home')} 
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            {/* Animated Logo Symbol */}
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 shadow-[0_0_12px_rgba(99,102,241,0.5)] group-hover:shadow-[0_0_18px_rgba(6,182,212,0.6)] transition-all">
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
            </div>
            
            <div className="flex flex-col">
              <span className="font-extrabold text-base tracking-wider bg-gradient-to-r from-white via-slate-200 to-cyan-300 bg-clip-text text-transparent">
                WREAD
              </span>
            </div>
          </div>

          {/* AI Status Indicator */}
          <div className="hidden sm:flex items-center gap-2 ml-3 px-2.5 py-1 rounded-full bg-slate-900/80 border border-white/[0.08] text-xs">
            <span className="relative flex h-2 w-2">
              <span 
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  !isBackendConnected ? 'bg-rose-500' : isProviderOnline ? 'bg-cyan-400' : 'bg-amber-400'
                }`}
              />
              <span 
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  !isBackendConnected ? 'bg-rose-500' : isProviderOnline ? 'bg-cyan-400' : 'bg-amber-400'
                }`} 
              />
            </span>
            <span className="text-slate-300 font-medium tracking-tight">
              {!isBackendConnected ? 'Backend Offline' : isProviderOnline ? 'AI Online' : isConfigured ? 'Configured' : 'Setup Required'}
            </span>
          </div>
        </div>

        {/* Right Header: System Status & Panel Toggle */}
        <div className="flex items-center gap-2">
          {/* Active Model Tag */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-900/60 border border-white/[0.07] text-xs text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-[11px] text-slate-300">
              {backendHealth.model ? backendHealth.model.replace('moonshotai/', '') : 'Kimi-K3'}
            </span>
          </div>

          {/* Health Pill */}
          <button
            onClick={() => setActiveWorkspace('settings')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
              isBackendConnected
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/50'
                : 'bg-rose-950/40 border-rose-500/30 text-rose-300 hover:bg-rose-900/50'
            }`}
            title="Inspect backend & model health status"
          >
            <Server className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {isBackendConnected ? 'Connected' : 'Offline'}
            </span>
          </button>

          {/* Desktop Right Contextual Panel Toggle */}
          <button
            onClick={() => setRightPanelOpen(!rightPanelOpen)}
            className={`hidden md:flex p-1.5 rounded-lg border transition-colors cursor-pointer ${
              rightPanelOpen 
                ? 'bg-cyan-950/50 border-cyan-500/40 text-cyan-300' 
                : 'bg-slate-900/70 border-white/[0.08] text-slate-400 hover:text-white'
            }`}
            title="Toggle system telemetry panel"
            aria-label="Toggle telemetry panel"
          >
            <Activity className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex relative z-10 overflow-hidden">
        {/* Desktop Left Sidebar */}
        <aside className="hidden md:flex flex-col w-60 lg:w-64 border-r border-white/[0.08] glass-panel p-3 shrink-0 justify-between">
          <div className="space-y-4">
            {/* New Chat Action */}
            <button
              onClick={() => {
                if (onNewChat) onNewChat();
                setActiveWorkspace('chat');
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600/80 to-cyan-600/80 hover:from-indigo-600 hover:to-cyan-600 text-white shadow-md shadow-indigo-900/30 font-medium text-sm transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-200 group-hover:rotate-90 transition-transform" />
                <span>New Conversation</span>
              </div>
              <span className="text-[10px] font-mono opacity-70 px-1.5 py-0.5 rounded bg-black/20">⌘N</span>
            </button>

            {/* Navigation items */}
            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeWorkspace === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                      isActive
                        ? 'bg-white/[0.08] text-cyan-300 border border-cyan-500/30 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Recent Conversations List */}
            {recentChats.length > 0 && (
              <div className="pt-2">
                <div className="px-3 pb-2 text-[11px] font-semibold text-slate-300 tracking-wider uppercase">
                  Recent Chats
                </div>
                <div className="space-y-0.5 max-h-48 overflow-y-auto">
                  {recentChats.slice(0, 6).map((chat) => (
                    <button
                      key={chat.id}
                      onClick={() => {
                        if (onSelectChat) onSelectChat(chat.id);
                        setActiveWorkspace('chat');
                      }}
                      className={`w-full text-left px-3 py-1.5 rounded-lg text-xs truncate transition-colors cursor-pointer ${
                        activeChatId === chat.id
                          ? 'bg-indigo-950/40 text-cyan-300 font-medium'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                      }`}
                    >
                      {chat.title || 'Untitled Conversation'}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar Footer System telemetry */}
          <div className="pt-3 border-t border-white/[0.06] text-xs text-slate-300 space-y-1">
            <div className="flex items-center justify-between text-[11px]">
              <span>Architecture</span>
              <span className="font-mono text-cyan-400">v1.0.4-OS</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span>Security Vault</span>
              <span className="text-emerald-400 font-medium">Encrypted</span>
            </div>
          </div>
        </aside>

        {/* Mobile Navigation Drawer (Overlay) */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 flex">
            <div 
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative w-4/5 max-w-xs bg-slate-950 border-r border-slate-800 p-5 flex flex-col justify-between z-10">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-cyan-400" />
                    <span className="font-bold text-lg text-white">WREAD</span>
                  </div>
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    if (onNewChat) onNewChat();
                    handleNavClick('chat');
                  }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-semibold text-sm shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Conversation</span>
                </button>

                <nav className="space-y-1">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeWorkspace === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                          isActive
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </nav>
              </div>

              <div className="text-xs text-slate-300 pt-4 border-t border-slate-900">
                WREAD AI Operating System
              </div>
            </div>
          </div>
        )}

        {/* Center Workspace */}
        <main className="flex-1 flex flex-col min-w-0 overflow-y-auto pb-16 md:pb-0">
          {children}
        </main>

        {/* Optional Right Contextual Panel (Desktop) */}
        {rightPanelOpen && (
          <aside className="hidden md:flex flex-col w-72 border-l border-white/[0.08] glass-panel p-4 space-y-4 shrink-0 overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                <span>AI OS Telemetry</span>
              </div>
              <button
                onClick={() => setRightPanelOpen(false)}
                className="text-slate-300 hover:text-slate-300 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Provider specs */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-white/[0.06] space-y-2 text-xs">
              <div className="text-slate-300 font-medium">Active AI Engine</div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Primary Model</span>
                <span className="font-mono text-cyan-300">Kimi-K3</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Host Infrastructure</span>
                <span className="text-slate-200">Modal US-West</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Credential Guard</span>
                <span className="text-emerald-400 font-medium">Server-Side Proxy</span>
              </div>
            </div>

            {/* Security Check */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-white/[0.06] space-y-2 text-xs">
              <div className="text-slate-300 font-medium">Security Validation</div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Zero client-side secrets. All upstream calls to Modal and AI endpoints are strictly proxied via secure server API routes.
              </p>
            </div>

            {/* Quick Actions */}
            <div className="space-y-1.5 pt-2">
              <div className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider px-1">
                Quick Jump
              </div>
              <button
                onClick={() => handleNavClick('agent')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-xs text-slate-300 transition-colors"
              >
                <span>Launch Autonomous Agent</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              </button>
              <button
                onClick={() => handleNavClick('research')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-xs text-slate-300 transition-colors"
              >
                <span>New Research Dossier</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              </button>
              <button
                onClick={() => handleNavClick('memory')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-xs text-slate-300 transition-colors"
              >
                <span>Inspect Active Memories</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              </button>
            </div>
          </aside>
        )}
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 border-t border-white/[0.08] glass-panel px-2 flex items-center justify-around">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = activeWorkspace === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`flex flex-col items-center justify-center w-14 py-1 rounded-xl transition-all cursor-pointer ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'text-cyan-400 scale-110' : 'text-slate-400'}`} />
              <span className="text-[10px] tracking-tight whitespace-nowrap">{item.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => handleNavClick('tasks')}
          className={`flex flex-col items-center justify-center w-14 py-1 rounded-xl transition-all cursor-pointer ${
            activeWorkspace === 'tasks' ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <CheckSquare className={`w-5 h-5 mb-0.5 ${activeWorkspace === 'tasks' ? 'text-cyan-400 scale-110' : 'text-slate-400'}`} />
          <span className="text-[10px] tracking-tight whitespace-nowrap">Tasks</span>
        </button>
      </nav>
    </div>
  );
};
