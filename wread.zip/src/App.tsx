/**
 * WREAD - Personal AI Operating System
 * Main Application Component
 */

import React, { useState, useEffect } from 'react';
import { ActiveWorkspace, BackendHealth, Conversation, AppSettings } from './types';
import { StorageService, DEFAULT_SETTINGS } from './services/storage';
import { checkBackendHealth } from './services/api';
import { AppShell } from './components/AppShell';
import { HomeWorkspace } from './components/HomeWorkspace';
import { ChatWorkspace } from './components/ChatWorkspace';
import { AgentWorkspace } from './components/AgentWorkspace';
import { ResearchWorkspace } from './components/ResearchWorkspace';
import { VisionWorkspace } from './components/VisionWorkspace';
import { MemoryWorkspace } from './components/MemoryWorkspace';
import { TasksWorkspace } from './components/TasksWorkspace';
import { SettingsWorkspace } from './components/SettingsWorkspace';

export default function App() {
  const [activeWorkspace, setActiveWorkspace] = useState<ActiveWorkspace>('home');
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [initialPromptForChat, setInitialPromptForChat] = useState<string | undefined>(undefined);
  const [initialPromptForAgent, setInitialPromptForAgent] = useState<string | undefined>(undefined);
  const [initialQueryForResearch, setInitialQueryForResearch] = useState<string | undefined>(undefined);
  
  const [backendHealth, setBackendHealth] = useState<BackendHealth>({
    backend: 'ok',
    configured: false,
    provider: 'kimi',
    model: 'moonshotai/Kimi-K3',
    hasKimiKey: false,
    hasGeminiKey: false,
    onlineConfirmed: false,
    timestamp: new Date().toISOString(),
  });

  // Load initial local data and verify backend health
  useEffect(() => {
    // 1. Settings
    setSettings(StorageService.getSettings());

    // 2. Conversations
    const storedChats = StorageService.getConversations();
    setConversations(storedChats);

    const activeId = StorageService.getActiveConversationId();
    if (activeId && storedChats.some(c => c.id === activeId)) {
      setActiveConversationId(activeId);
    } else if (storedChats.length > 0) {
      setActiveConversationId(storedChats[0].id);
    }

    // 3. Backend Health
    refreshHealth();
  }, []);

  const refreshHealth = async () => {
    try {
      const health = await checkBackendHealth();
      setBackendHealth(prev => ({
        ...health,
        onlineConfirmed: prev.onlineConfirmed, // preserve if confirmed by active response
      }));
    } catch {
      setBackendHealth(prev => ({
        ...prev,
        backend: 'offline',
        configured: false,
      }));
    }
  };

  // Create new chat
  const handleNewChat = () => {
    const newChat: Conversation = {
      id: 'conv_' + Date.now(),
      title: 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };
    StorageService.saveConversation(newChat);
    StorageService.setActiveConversationId(newChat.id);
    setConversations(StorageService.getConversations());
    setActiveConversationId(newChat.id);
    setInitialPromptForChat(undefined);
  };

  // Update conversation
  const handleUpdateConversation = (updated: Conversation) => {
    StorageService.saveConversation(updated);
    setConversations(StorageService.getConversations());
    // If a response succeeded, mark onlineConfirmed
    if (updated.messages.some(m => m.role === 'assistant' && m.status === 'complete')) {
      setBackendHealth(prev => ({ ...prev, onlineConfirmed: true }));
    }
  };

  // Rename conversation
  const handleRenameConversation = (id: string, newTitle: string) => {
    StorageService.renameConversation(id, newTitle);
    setConversations(StorageService.getConversations());
  };

  // Delete conversation
  const handleDeleteConversation = (id: string) => {
    StorageService.deleteConversation(id);
    const updated = StorageService.getConversations();
    setConversations(updated);
    if (activeConversationId === id) {
      if (updated.length > 0) {
        setActiveConversationId(updated[0].id);
        StorageService.setActiveConversationId(updated[0].id);
      } else {
        handleNewChat();
      }
    }
  };

  // Clear current conversation
  const handleClearCurrentChat = () => {
    if (!activeConversationId) return;
    const current = conversations.find(c => c.id === activeConversationId);
    if (!current) return;

    const cleared: Conversation = {
      ...current,
      messages: [],
      updatedAt: Date.now(),
    };
    handleUpdateConversation(cleared);
  };

  // Switch to specific conversation
  const handleSelectChat = (id: string) => {
    setActiveConversationId(id);
    StorageService.setActiveConversationId(id);
  };

  // Quick prompt from Home screen
  const handleQuickPromptFromHome = (prompt: string) => {
    handleNewChat();
    setInitialPromptForChat(prompt);
    setActiveWorkspace('chat');
  };

  // Run with Agent action from Chat
  const handleRunAgentTaskFromChat = (prompt: string) => {
    setInitialPromptForAgent(prompt);
    setActiveWorkspace('agent');
  };

  // Research this on the web action from Chat
  const handleResearchOnWebFromChat = (query: string) => {
    setInitialQueryForResearch(query);
    setActiveWorkspace('research');
  };

  // Active conversation object
  const activeConversation: Conversation =
    conversations.find(c => c.id === activeConversationId) || {
      id: 'conv_default',
      title: 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };

  return (
    <AppShell
      activeWorkspace={activeWorkspace}
      setActiveWorkspace={setActiveWorkspace}
      backendHealth={backendHealth}
      onNewChat={handleNewChat}
      recentChats={conversations}
      activeChatId={activeConversationId}
      onSelectChat={handleSelectChat}
    >
      {activeWorkspace === 'home' && (
        <HomeWorkspace
          onSelectWorkspace={setActiveWorkspace}
          onQuickPromptSubmit={handleQuickPromptFromHome}
        />
      )}

      {activeWorkspace === 'chat' && (
        <ChatWorkspace
          conversation={activeConversation}
          conversations={conversations}
          onUpdateConversation={handleUpdateConversation}
          onSelectConversation={handleSelectChat}
          onNewChat={handleNewChat}
          onRenameConversation={handleRenameConversation}
          onDeleteConversation={handleDeleteConversation}
          onClearChat={handleClearCurrentChat}
          initialPrompt={initialPromptForChat}
          onRunAgentTask={handleRunAgentTaskFromChat}
          onResearchOnWeb={handleResearchOnWebFromChat}
          settings={settings}
        />
      )}

      {activeWorkspace === 'agent' && (
        <AgentWorkspace
          initialPrompt={initialPromptForAgent}
          onClearInitialPrompt={() => setInitialPromptForAgent(undefined)}
        />
      )}

      {activeWorkspace === 'research' && (
        <ResearchWorkspace
          initialQuery={initialQueryForResearch}
          onClearInitialQuery={() => setInitialQueryForResearch(undefined)}
        />
      )}

      {activeWorkspace === 'vision' && <VisionWorkspace />}

      {activeWorkspace === 'memory' && <MemoryWorkspace />}

      {activeWorkspace === 'tasks' && <TasksWorkspace />}

      {activeWorkspace === 'settings' && (
        <SettingsWorkspace
          settings={settings}
          onUpdateSettings={setSettings}
          backendHealth={backendHealth}
          onRefreshHealth={refreshHealth}
        />
      )}
    </AppShell>
  );
}
