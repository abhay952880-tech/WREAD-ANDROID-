/**
 * WREAD - Core Data Models & TypeScript Interfaces
 */

export interface MessageAttachment {
  name: string;
  type: string;
  base64?: string;
  url?: string;
  size?: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
  timestamp?: number;
  status?: 'sending' | 'streaming' | 'complete' | 'error';
  error?: string;
  model?: string;
  provider?: string;
  reasoning?: string;
  attachments?: MessageAttachment[];
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  pinned?: boolean;
}

export type TaskStatus = 'Pending' | 'Running' | 'Completed' | 'Failed' | 'Cancelled';

export interface Task {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  createdAt: number;
  updatedAt: number;
  progress: number;
  result?: string;
  category?: string;
}

export type MemoryCategory = 
  | 'Preferences' 
  | 'Projects' 
  | 'Instructions' 
  | 'Important Information' 
  | 'General';

export interface Memory {
  id: string;
  key: string;
  content: string;
  category: MemoryCategory;
  createdAt: number;
  updatedAt: number;
  tags?: string[];
}

export interface ResearchSource {
  title: string;
  url: string;
  snippet: string;
  sourceName: string;
  retrievedAt: string;
  domain?: string;
  relevance?: number;
  date?: string;
}

export type ResearchMode = 'quick' | 'deep';

export interface ResearchResult {
  id: string;
  query: string;
  createdAt: number;
  mode: ResearchMode;
  depth?: 'overview' | 'deep';
  summary: string;
  finalAnswer: string;
  keyFindings?: string[];
  keyFacts?: string[];
  contradictions?: string[];
  sources: ResearchSource[];
  status: 'completed' | 'in_progress' | 'stopped' | 'failed';
  model?: string;
  provider?: string;
  error?: string;
}

export interface ResearchHistoryItem {
  id: string;
  query: string;
  mode: ResearchMode;
  createdAt: number;
  sources: ResearchSource[];
  summary: string;
  finalAnswer?: string;
  keyFacts?: string[];
  contradictions?: string[];
}

export type AgentToolType = 
  | 'web_search' 
  | 'file_operations' 
  | 'research' 
  | 'data_analysis' 
  | 'api_call' 
  | 'automation' 
  | 'reasoning'
  | 'vision_analysis';

export interface AgentStep {
  id: string;
  title: string;
  description: string;
  tool: AgentToolType;
  toolConnected: boolean;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
  output?: string;
  timestamp: number;
}

export interface AgentHistoryItem {
  id: string;
  task: string;
  status: 'idle' | 'planning' | 'executing' | 'completed' | 'stopped' | 'failed';
  createdAt: number;
  completedAt?: number;
  steps: AgentStep[];
  finalResult?: string;
  imageAttachment?: MessageAttachment;
}

export interface AgentTask {
  id: string;
  task: string;
  prompt: string;
  status: 'idle' | 'planning' | 'executing' | 'completed' | 'stopped' | 'failed';
  steps: AgentStep[];
  currentStepIndex: number;
  result?: string;
  finalResult?: string;
  imageAttachment?: MessageAttachment;
  logs: Array<{
    timestamp: number;
    message: string;
    type: 'info' | 'warn' | 'error' | 'tool';
  }>;
  createdAt: number;
  completedAt?: number;
  error?: string;
}

export interface AIResponse {
  content: string;
  model: string;
  provider: string;
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
  };
  reasoning?: string;
}

export interface APIError {
  status: number;
  message: string;
  code?: string;
}

export interface BackendHealth {
  backend: 'ok' | 'degraded' | 'offline';
  configured: boolean;
  provider: string;
  model: string;
  hasKimiKey: boolean;
  hasGeminiKey: boolean;
  supportsVision?: boolean;
  onlineConfirmed?: boolean;
  timestamp: string;
}

export type VoiceLanguage = 'auto' | 'hi-IN' | 'en-US';

export interface AppSettings {
  aiModel: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
  memoryEnabled: boolean;
  autoExtractMemory: boolean;
  soundEnabled: boolean;
  accentColor: 'cyan' | 'purple' | 'emerald';
  orbAnimation: boolean;
  // Voice Assistant Settings
  voiceInputEnabled: boolean;
  voiceOutputEnabled: boolean; // Auto Speak default OFF
  voiceLanguage: VoiceLanguage;
  speechRate: number; // 0.8 - 1.5
}

export type ActiveWorkspace = 
  | 'home'
  | 'chat'
  | 'agent'
  | 'research'
  | 'vision'
  | 'memory'
  | 'tasks'
  | 'settings';
