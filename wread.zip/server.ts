import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Increase JSON payload limit for image data / agent tasks
app.use(express.json({ limit: '25mb' }));

// -------------------------------------------------------------
// SECURE PROVIDER ABSTRACTION & KIMI-K3 INTEGRATION
// -------------------------------------------------------------

export interface ImagePayload {
  name?: string;
  mimeType: string;
  base64: string; // raw base64 or data URL
  size?: number;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  images?: ImagePayload[];
}

export interface ChatResult {
  content: string;
  model: string;
  reasoning?: string;
  usage?: { promptTokens?: number; completionTokens?: number; totalTokens?: number };
}

interface AIProvider {
  name: string;
  isConfigured(): boolean;
  generateChat(messages: ChatMessage[], options?: { stream?: boolean; temperature?: number }): Promise<ChatResult>;
}

// Sanitize helper to ensure NO credentials ever leak into responses or logs
function sanitizeErrorMessage(error: any): string {
  if (!error) return 'An unexpected system error occurred.';
  let msg = typeof error === 'string' ? error : error.message || String(error);
  
  // Strip potential tokens, Bearer headers, or secret patterns
  msg = msg.replace(/Bearer\s+[A-Za-z0-9_\-\.]+/gi, 'Bearer [REDACTED]');
  msg = msg.replace(/key=[A-Za-z0-9_\-\.]+/gi, 'key=[REDACTED]');
  msg = msg.replace(/api[-_]?key[:=]\s*[A-Za-z0-9_\-\.]+/gi, 'apiKey=[REDACTED]');
  
  if (msg.includes('401') || msg.includes('Unauthorized')) {
    return 'Authentication failed with the upstream AI provider. Please verify server environment credentials.';
  }
  if (msg.includes('403') || msg.includes('Forbidden')) {
    return 'Access forbidden by upstream AI provider. The service token may lack required permissions.';
  }
  if (msg.includes('404') || msg.includes('Not Found')) {
    return 'The requested AI model endpoint was not found on the upstream server.';
  }
  if (msg.includes('429') || msg.includes('Too Many Requests') || msg.includes('rate limit')) {
    return 'Upstream AI provider rate limit reached. Please wait a moment and try again.';
  }
  if (msg.includes('502') || msg.includes('Bad Gateway')) {
    return 'Bad Gateway from upstream AI provider. The remote service or container may be starting up.';
  }
  if (msg.includes('503') || msg.includes('Service Unavailable')) {
    return 'AI provider service temporarily unavailable. The remote instance may be scaling up.';
  }
  if (msg.includes('504') || msg.includes('Gateway Timeout') || msg.includes('timeout')) {
    return 'AI provider request timed out. The model took too long to complete generation.';
  }
  
  return msg;
}

// Kimi-K3 on Modal Provider Implementation
class KimiProvider implements AIProvider {
  name = 'Kimi-K3';

  getBaseUrl(): string {
    return (
      process.env.KIMI_BASE_URL ||
      'https://searchess50--ep-kimi-k3-server.us-west.modal.direct'
    ).replace(/\/+$/, '');
  }

  getModel(): string {
    return process.env.KIMI_MODEL || 'moonshotai/Kimi-K3';
  }

  getApiKey(): string | undefined {
    return process.env.KIMI_API_KEY;
  }

  isConfigured(): boolean {
    const key = this.getApiKey();
    return Boolean(key && key.trim().length > 0);
  }

  async generateChat(messages: ChatMessage[], options?: { stream?: boolean; temperature?: number }) {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new Error('KIMI_API_KEY is not configured on the server. Please set it in server environment secrets.');
    }

    const baseUrl = this.getBaseUrl();
    const endpoint = `${baseUrl}/v1/chat/completions`;
    const model = this.getModel();

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000); // 12s timeout for upstream Kimi endpoint

    const startTime = Date.now();
    console.log(`[AI Provider] POST request initiated to Kimi endpoint with model: ${model}`);

    // Format messages for OpenAI-compatible endpoint, supporting multimodal image_url when present
    const formattedMessages = messages.map(m => {
      if (m.images && m.images.length > 0) {
        const parts: any[] = [];
        if (m.content && m.content.trim()) {
          parts.push({ type: 'text', text: m.content.trim() });
        } else {
          parts.push({
            type: 'text',
            text: 'Please analyze this image, describe what you see, and highlight any key details, visible text, diagrams, or errors.',
          });
        }
        for (const img of m.images) {
          const dataUrl = img.base64.startsWith('data:')
            ? img.base64
            : `data:${img.mimeType || 'image/jpeg'};base64,${img.base64}`;
          parts.push({
            type: 'image_url',
            image_url: { url: dataUrl },
          });
        }
        return {
          role: m.role,
          content: parts,
        };
      }
      return {
        role: m.role,
        content: m.content,
      };
    });

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: formattedMessages,
          temperature: options?.temperature ?? 0.7,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const elapsed = Date.now() - startTime;
      console.log(`[AI Provider] Kimi response status: ${response.status} (${elapsed}ms)`);

      if (!response.ok) {
        let errBody = '';
        try {
          errBody = await response.text();
        } catch {
          // ignore
        }
        throw new Error(`Kimi provider HTTP ${response.status}: ${errBody || response.statusText}`);
      }

      const data = await response.json();
      const choice = data?.choices?.[0];
      const content = choice?.message?.content || choice?.text || '';
      const reasoning = choice?.message?.reasoning_content;

      return {
        content: content.trim(),
        model: data?.model || model,
        reasoning,
        usage: {
          promptTokens: data?.usage?.prompt_tokens,
          completionTokens: data?.usage?.completion_tokens,
          totalTokens: data?.usage?.total_tokens,
        },
      };
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        throw new Error('504 Gateway Timeout: Upstream AI request exceeded timeout limit.');
      }
      throw err;
    }
  }
}

// Fallback Gemini Provider (supports server-side GEMINI_API_KEY if present)
class GeminiFallbackProvider implements AIProvider {
  name = 'Gemini';

  isConfigured(): boolean {
    return Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
  }

  async generateChat(messages: ChatMessage[]): Promise<ChatResult> {
    if (!this.isConfigured()) {
      throw new Error('GEMINI_API_KEY not configured.');
    }
    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const hasImages = messages.some(m => m.images && m.images.length > 0);
    const candidateModels = hasImages
      ? ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest']
      : ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-3.1-flash-lite'];

    const systemMsg = messages.find(m => m.role === 'system')?.content || '';
    let lastError: any;

    for (const model of candidateModels) {
      try {
        let contents: any;

        if (hasImages) {
          const parts: any[] = [];
          if (systemMsg) {
            parts.push({ text: `SYSTEM INSTRUCTIONS:\n${systemMsg}\n\n` });
          }

          for (const m of messages) {
            if (m.role === 'system') continue;
            if (m.images && m.images.length > 0) {
              for (const img of m.images) {
                const cleanBase64 = img.base64.replace(/^data:image\/\w+;base64,/, '');
                parts.push({
                  inlineData: {
                    data: cleanBase64,
                    mimeType: img.mimeType || 'image/jpeg',
                  },
                });
              }
            }
            if (m.content) {
              parts.push({ text: `${m.role.toUpperCase()}: ${m.content}\n\n` });
            }
          }
          parts.push({ text: 'ASSISTANT:' });
          contents = parts;
        } else {
          const conversation = messages
            .filter(m => m.role !== 'system')
            .map(m => `${m.role.toUpperCase()}: ${m.content}`)
            .join('\n\n');

          const fullPrompt = systemMsg 
            ? `SYSTEM INSTRUCTIONS:\n${systemMsg}\n\nCONVERSATION:\n${conversation}\n\nASSISTANT:`
            : `${conversation}\n\nASSISTANT:`;
          contents = fullPrompt;
        }

        const response = await ai.models.generateContent({
          model,
          contents,
        });

        return {
          content: response.text || '',
          model,
        };
      } catch (err) {
        lastError = err;
        console.warn(`[Gemini Provider] Model ${model} failed, attempting next candidate...`);
      }
    }

    throw lastError || new Error('All Gemini models exhausted.');
  }
}

const kimiProvider = new KimiProvider();
const geminiProvider = new GeminiFallbackProvider();

// Active AI request orchestrator
async function executeChatRequest(messages: ChatMessage[], options?: { temperature?: number }) {
  const hasImages = messages.some(m => m.images && m.images.length > 0);

  // If request contains images:
  if (hasImages) {
    // 1. Prefer Gemini for multimodal requests if configured (official vision model)
    if (geminiProvider.isConfigured()) {
      try {
        console.log('[AI Orchestrator] Routing multimodal vision request to Gemini...');
        return await geminiProvider.generateChat(messages);
      } catch (geminiErr) {
        console.warn('[AI Orchestrator] Gemini vision error:', sanitizeErrorMessage(geminiErr));
      }
    }

    // 2. Next attempt Kimi multimodal if configured
    if (kimiProvider.isConfigured()) {
      try {
        console.log('[AI Orchestrator] Routing multimodal request to Kimi multimodal endpoint...');
        return await kimiProvider.generateChat(messages, options);
      } catch (kimiErr) {
        console.warn('[AI Orchestrator] Kimi multimodal request error:', sanitizeErrorMessage(kimiErr));
      }
    }

    // 3. If neither provider can process images: do NOT fake understanding
    throw new Error(
      `Image analysis is currently unavailable: The active AI provider configuration could not process multimodal images, and no fallback vision model is configured. Please configure a vision-compatible model (such as Gemini 3.8 Flash via GEMINI_API_KEY) in Settings.`
    );
  }

  // Text-only standard chat request flow:
  if (kimiProvider.isConfigured()) {
    try {
      return await kimiProvider.generateChat(messages, options);
    } catch (kimiErr) {
      console.warn(`[AI Orchestrator] Kimi provider error:`, sanitizeErrorMessage(kimiErr));
      if (geminiProvider.isConfigured()) {
        console.log(`[AI Orchestrator] Attempting fallback to Gemini provider...`);
        return await geminiProvider.generateChat(messages);
      }
      throw kimiErr;
    }
  }

  if (geminiProvider.isConfigured()) {
    return await geminiProvider.generateChat(messages);
  }

  throw new Error(
    'No AI provider is configured. Please add your KIMI_API_KEY (or GEMINI_API_KEY) in the environment secrets.'
  );
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// 1. Health Check
app.get('/api/health', (req: Request, res: Response) => {
  const hasKimiKey = kimiProvider.isConfigured();
  const hasGeminiKey = geminiProvider.isConfigured();
  const configured = hasKimiKey || hasGeminiKey;
  const supportsVision = Boolean(hasGeminiKey || hasKimiKey);

  res.json({
    backend: 'ok',
    configured,
    provider: hasKimiKey ? 'kimi' : hasGeminiKey ? 'gemini' : 'none',
    model: kimiProvider.getModel(),
    hasKimiKey,
    hasGeminiKey,
    supportsVision,
    timestamp: new Date().toISOString(),
  });
});

// 2. Chat API
app.post('/api/chat', async (req: Request, res: Response) => {
  const startTime = Date.now();
  const { messages, stream, temperature } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({
      error: {
        status: 400,
        message: 'Invalid request: "messages" must be a non-empty array of message objects.',
      },
    });
    return;
  }

  // Validate message objects and preserve attached images
  const sanitizedMessages: ChatMessage[] = messages.map(m => {
    const images: ImagePayload[] = [];
    if (Array.isArray(m.images)) {
      for (const img of m.images) {
        if (img && img.base64) {
          images.push({
            name: img.name,
            mimeType: img.mimeType || 'image/jpeg',
            base64: String(img.base64).replace(/^data:image\/\w+;base64,/, ''),
            size: img.size,
          });
        }
      }
    }
    if (Array.isArray(m.attachments)) {
      for (const att of m.attachments) {
        if (att && att.base64 && (att.type?.startsWith('image/') || att.name?.match(/\.(jpg|jpeg|png|webp)$/i))) {
          images.push({
            name: att.name,
            mimeType: att.type || 'image/jpeg',
            base64: String(att.base64).replace(/^data:image\/\w+;base64,/, ''),
            size: att.size,
          });
        }
      }
    }
    return {
      role: m.role === 'assistant' || m.role === 'system' ? m.role : 'user',
      content: typeof m.content === 'string' ? m.content : '',
      images: images.length > 0 ? images : undefined,
    };
  });

  try {
    const result = await executeChatRequest(sanitizedMessages, { temperature });
    const responseTime = Date.now() - startTime;
    console.log(`[Chat API] Completed successfully in ${responseTime}ms (model: ${result.model})`);

    res.json({
      content: result.content,
      model: result.model,
      provider: result.model.includes('Kimi') || result.model.includes('moonshot') ? 'Kimi-K3' : 'Gemini',
      reasoning: result.reasoning,
      usage: result.usage,
      responseTime,
    });
  } catch (error: any) {
    const responseTime = Date.now() - startTime;
    const sanitizedMsg = sanitizeErrorMessage(error);
    console.error(`[Chat API Error] ${sanitizedMsg} (${responseTime}ms)`);

    let statusCode = 500;
    if (sanitizedMsg.includes('401') || sanitizedMsg.includes('Authentication')) statusCode = 401;
    else if (sanitizedMsg.includes('403') || sanitizedMsg.includes('forbidden')) statusCode = 403;
    else if (sanitizedMsg.includes('404')) statusCode = 404;
    else if (sanitizedMsg.includes('429') || sanitizedMsg.includes('rate limit')) statusCode = 429;
    else if (sanitizedMsg.includes('502')) statusCode = 502;
    else if (sanitizedMsg.includes('503') || sanitizedMsg.includes('unavailable')) statusCode = 503;
    else if (sanitizedMsg.includes('504') || sanitizedMsg.includes('Timeout')) statusCode = 504;

    res.status(statusCode).json({
      error: {
        status: statusCode,
        message: sanitizedMsg,
      },
    });
  }
});

// 3. Agent Step Execution
app.post('/api/agent/step', async (req: Request, res: Response) => {
  const { prompt, step, context, imageAttachment } = req.body;

  if (!prompt || !step) {
    res.status(400).json({ error: { status: 400, message: 'Missing prompt or step details.' } });
    return;
  }

  try {
    const isVisionStep =
      step.tool === 'vision_analysis' ||
      step.title?.toLowerCase().includes('visual') ||
      step.title?.toLowerCase().includes('screenshot') ||
      step.title?.toLowerCase().includes('image');

    const systemPrompt = `You are WREAD Autonomous Agent Engine.
Execute the following step for the user's high-level task: "${prompt}".
Current Step: "${step.title}" - Description: "${step.description}".
Tool: "${step.tool}". Tool connected state: ${step.toolConnected ? 'CONNECTED' : 'DISCONNECTED'}.
${context ? `Previous context:\n${JSON.stringify(context)}` : ''}
${isVisionStep ? 'Focus on precise visual inspection, error identification, UI state analysis, and technical diagnosis.' : ''}

Provide a realistic, professional execution output for this step. If tool is disconnected, state clearly what architectural steps were completed and what live API would be called.
Respond in clear, structured format.`;

    const userImages: ImagePayload[] = [];
    if (imageAttachment && imageAttachment.base64) {
      userImages.push({
        name: imageAttachment.name,
        mimeType: imageAttachment.type || 'image/jpeg',
        base64: String(imageAttachment.base64).replace(/^data:image\/\w+;base64,/, ''),
        size: imageAttachment.size,
      });
    }

    const result = await executeChatRequest([
      { role: 'system', content: systemPrompt },
      {
        role: 'user',
        content: `Execute step: "${step.title}" - Description: "${step.description}".`,
        images: userImages.length > 0 ? userImages : undefined,
      },
    ]);

    res.json({
      output: result.content,
      model: result.model,
      status: 'completed',
    });
  } catch (error: any) {
    const safeMsg = sanitizeErrorMessage(error);
    res.status(500).json({
      error: { status: 500, message: safeMsg },
    });
  }
});

// -------------------------------------------------------------
// REAL WEB RETRIEVAL & SEARCH LAYER (NO MOCK DATA)
// -------------------------------------------------------------

interface RetrievedWebSource {
  title: string;
  url: string;
  snippet: string;
  sourceName: string;
  retrievedAt: string;
  domain: string;
  relevance: number;
  excerpt?: string;
}

// Decode HTML entities
function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&#39;/g, "'");
}

// Fetch real search results from DuckDuckGo public HTML interface
async function searchDuckDuckGo(query: string, limit: number = 6): Promise<RetrievedWebSource[]> {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      },
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      console.warn(`[DuckDuckGo Search] HTTP ${res.status}`);
      return [];
    }

    const html = await res.text();
    const sources: RetrievedWebSource[] = [];

    const titleRegex = /<h2 class="result__title">[\s\S]*?<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    const snippetRegex = /<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;

    let match;
    while ((match = titleRegex.exec(html)) !== null && sources.length < limit) {
      let rawUrl = match[1];
      let title = decodeHtmlEntities(match[2].replace(/<[^>]+>/g, '').trim());

      // Decode DuckDuckGo redirect uddg parameter
      if (rawUrl.includes('uddg=')) {
        const uddgMatch = rawUrl.match(/uddg=([^&]+)/);
        if (uddgMatch) {
          try {
            rawUrl = decodeURIComponent(uddgMatch[1]);
          } catch {}
        }
      }

      let domain = '';
      try {
        domain = new URL(rawUrl).hostname.replace(/^www\./, '');
      } catch {
        domain = 'web';
      }

      sources.push({
        title,
        url: rawUrl,
        snippet: '',
        sourceName: domain,
        domain,
        retrievedAt: new Date().toISOString(),
        relevance: 96 - sources.length * 4,
      });
    }

    let sIdx = 0;
    while ((match = snippetRegex.exec(html)) !== null && sIdx < sources.length) {
      const snippet = decodeHtmlEntities(match[1].replace(/<[^>]+>/g, '').trim());
      sources[sIdx].snippet = snippet;
      sIdx++;
    }

    return sources.filter(s => s.url && s.title);
  } catch (err: any) {
    clearTimeout(timeoutId);
    console.warn('[DuckDuckGo Search] Failed or timed out:', err.message);
    return [];
  }
}

// Fetch real search results from Wikipedia API
async function searchWikipedia(query: string, limit: number = 3): Promise<RetrievedWebSource[]> {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
    query
  )}&format=json&origin=*`;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 6000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) return [];

    const data = await res.json();
    const items = data.query?.search || [];
    return items.slice(0, limit).map((item: any) => {
      const title = item.title;
      const snippet = decodeHtmlEntities(item.snippet.replace(/<[^>]+>/g, '').trim());
      const pageUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`;
      return {
        title: `${title} - Wikipedia`,
        url: pageUrl,
        snippet,
        sourceName: 'Wikipedia',
        domain: 'en.wikipedia.org',
        retrievedAt: new Date().toISOString(),
        relevance: 90,
      };
    });
  } catch {
    clearTimeout(timeoutId);
    return [];
  }
}

// Safe Web Page Excerpt Fetcher for Deep Research mode
async function fetchPageExcerpt(pageUrl: string, timeoutMs: number = 4000): Promise<string> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const res = await fetch(pageUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,text/plain',
      },
    });
    clearTimeout(timeout);

    if (!res.ok) return '';
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('text/html') && !contentType.includes('text/plain')) return '';

    const html = await res.text();
    // Strip scripts, styles, navigations, footers
    const cleaned = html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
      .replace(/<header\b[^<]*(?:(?!<\/header>)<[^<]*)*<\/header>/gi, ' ')
      .replace(/<footer\b[^<]*(?:(?!<\/footer>)<[^<]*)*<\/footer>/gi, ' ')
      .replace(/<nav\b[^<]*(?:(?!<\/nav>)<[^<]*)*<\/nav>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return decodeHtmlEntities(cleaned.slice(0, 1000));
  } catch {
    return '';
  }
}

// Unified multi-source web retrieval engine
async function retrieveWebSources(query: string, mode: 'quick' | 'deep'): Promise<RetrievedWebSource[]> {
  const isDeep = mode === 'deep';
  const targetCount = isDeep ? 8 : 4;

  // Run DuckDuckGo retrieval and Wikipedia search in parallel with Promise.allSettled
  const results = await Promise.allSettled([
    searchDuckDuckGo(query, isDeep ? 7 : 4),
    searchWikipedia(query, isDeep ? 3 : 1),
  ]);

  const ddgResults: RetrievedWebSource[] = results[0].status === 'fulfilled' ? results[0].value : [];
  const wikiResults: RetrievedWebSource[] = results[1].status === 'fulfilled' ? results[1].value : [];

  // Merge and deduplicate by URL
  const seenUrls = new Set<string>();
  const combined: RetrievedWebSource[] = [];

  for (const src of [...ddgResults, ...wikiResults]) {
    if (!seenUrls.has(src.url)) {
      seenUrls.add(src.url);
      combined.push(src);
      if (combined.length >= targetCount) break;
    }
  }

  // If deep mode, extract text excerpts for top 3 sources
  if (isDeep && combined.length > 0) {
    const excerptPromises = combined.slice(0, 3).map(async src => {
      const excerpt = await fetchPageExcerpt(src.url);
      if (excerpt) src.excerpt = excerpt;
    });
    await Promise.allSettled(excerptPromises);
  }

  return combined;
}

// 4. Web Research Engine Endpoint
app.post('/api/research', async (req: Request, res: Response) => {
  const { query, mode: rawMode, depth, relevantMemories } = req.body;

  if (!query || typeof query !== 'string' || query.trim().length === 0) {
    res.status(400).json({ error: { status: 400, message: 'Query string is required.' } });
    return;
  }

  const cleanQuery = query.trim();
  const mode: 'quick' | 'deep' = rawMode === 'deep' || depth === 'deep' ? 'deep' : 'quick';

  console.log(`[Web Research] Query: "${cleanQuery}" | Mode: ${mode}`);

  try {
    // Phase 1: Retrieve real public web sources
    const sources = await retrieveWebSources(cleanQuery, mode);

    // If no sources could be retrieved from the public web
    if (sources.length === 0) {
      res.json({
        id: 'res_' + Date.now(),
        query: cleanQuery,
        mode,
        createdAt: Date.now(),
        sources: [],
        summary: `No public web sources were found matching the query "${cleanQuery}".`,
        finalAnswer: `No verifiable public web sources were retrieved for the query "${cleanQuery}". Please verify query terminology, check spelling, or try broader keywords.\n\n### Sources\nNo sources available.`,
        keyFacts: [],
        contradictions: [],
        status: 'completed',
        model: kimiProvider.getModel(),
        provider: kimiProvider.isConfigured() ? 'Kimi-K3' : 'Gemini',
      });
      return;
    }

    // Phase 2: Analyze retrieved sources with Kimi-K3
    const memoryDirective = Array.isArray(relevantMemories) && relevantMemories.length > 0
      ? `User Context / Relevant Memories:\n${relevantMemories.join('\n')}\n`
      : '';

    const sourcesListing = sources.map((s, idx) => {
      return `[${idx + 1}] Title: ${s.title}
URL: ${s.url}
Source: ${s.sourceName}
Snippet: ${s.snippet}${s.excerpt ? `\nContent Excerpt: ${s.excerpt}` : ''}`;
    }).join('\n\n');

    const systemPrompt = `You are WREAD Web Research Engine powered by Kimi-K3.
Analyze the following retrieved real public web sources to answer the user's research query.
Research Query: "${cleanQuery}"
Research Mode: ${mode === 'deep' ? 'Deep Research (Comprehensive comparative synthesis)' : 'Quick Research (Concise summary)'}.

${memoryDirective}
RETRIEVED REAL WEB SOURCES:
${sourcesListing}

ANALYSIS GUIDELINES:
1. Compare the sources carefully and identify important verifiable facts.
2. Identify any contradictions, differing numbers, or varied perspectives across sources (if consistent, note consistency).
3. Summarize the evidence objectively.
4. Produce a well-structured Final Answer.
5. SOURCE CITATIONS: Reference the sources using bracketed citations, like [1], [2].
6. AT THE VERY BOTTOM of the Final Answer, provide a Sources section formatted as:
Sources
1. Source Title — URL
2. Source Title — URL
(Strictly use only the exact URLs provided in the retrieved sources above).

Respond in structured JSON format with this schema:
{
  "summary": "Executive summary of the research (2-3 paragraphs)",
  "keyFacts": ["Important fact 1 with attribution", "Important fact 2", "Important fact 3", "Important fact 4"],
  "contradictions": ["Contradiction or divergence noted between sources (or 'Sources are consistent on core facts' if none)"],
  "finalAnswer": "Complete final answer with in-text citations [1], [2] and ending with the Sources list at the bottom"
}
Return raw JSON only.`;

    const result = await executeChatRequest([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Analyze the retrieved sources for query: "${cleanQuery}"` },
    ]);

    // Parse JSON safely
    let parsedData: any = {};
    try {
      const cleaned = result.content
        .replace(/^```json\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
      parsedData = JSON.parse(cleaned);
    } catch {
      // Fallback if LLM output markdown text directly
      const sourcesList = sources.map((s, i) => `${i + 1}. ${s.title} — ${s.url}`).join('\n');
      parsedData = {
        summary: result.content.slice(0, 500) + '...',
        keyFacts: [
          'Information synthesized from ' + sources.length + ' public web sources.',
          'Domain sources: ' + sources.map(s => s.sourceName).join(', ')
        ],
        contradictions: [],
        finalAnswer: result.content.includes('Sources')
          ? result.content
          : `${result.content}\n\n### Sources\n${sourcesList}`,
      };
    }

    res.json({
      id: 'res_' + Date.now(),
      query: cleanQuery,
      mode,
      createdAt: Date.now(),
      sources,
      summary: parsedData.summary || 'Summary unavailable.',
      finalAnswer: parsedData.finalAnswer || parsedData.summary || 'No answer produced.',
      keyFacts: Array.isArray(parsedData.keyFacts) ? parsedData.keyFacts : [],
      keyFindings: Array.isArray(parsedData.keyFacts) ? parsedData.keyFacts : [],
      contradictions: Array.isArray(parsedData.contradictions) ? parsedData.contradictions : [],
      status: 'completed',
      model: result.model,
      provider: result.model.includes('Kimi') || result.model.includes('moonshot') ? 'Kimi-K3' : 'Gemini',
    });
  } catch (error: any) {
    console.error('[Research API Error]:', error);
    const safeMsg = sanitizeErrorMessage(error);
    res.status(500).json({
      error: { status: 500, message: safeMsg },
    });
  }
});

// 5. Image Analysis Architecture
app.post('/api/analyze-image', async (req: Request, res: Response) => {
  const { imageBase64, mimeType = 'image/jpeg', prompt, fileName } = req.body;

  if (!imageBase64 || typeof imageBase64 !== 'string') {
    res.status(400).json({ error: { status: 400, message: 'Image base64 data is required.' } });
    return;
  }

  // Validate supported image formats (JPG, JPEG, PNG, WEBP)
  const validMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  const normalizedMime = (mimeType || 'image/jpeg').toLowerCase();
  const isValidMime = validMimes.some(vm => normalizedMime.includes(vm.replace('image/', '')));
  if (!isValidMime) {
    res.status(400).json({
      error: {
        status: 400,
        message: 'Unsupported image format. WREAD supports JPG, JPEG, PNG, and WEBP images.',
      },
    });
    return;
  }

  // Enforce size limit (10MB binary ≈ 14MB base64)
  if (imageBase64.length > 14 * 1024 * 1024) {
    res.status(400).json({
      error: {
        status: 400,
        message: 'Image exceeds maximum size (10 MB). Please upload an image under 10 MB.',
      },
    });
    return;
  }

  const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

  const userPrompt = (prompt && prompt.trim())
    ? prompt.trim()
    : 'Analyze this image in detail. Describe all visible elements, perform OCR on any text or code present, identify UI components or diagrams, and highlight key observations or potential issues.';

  const visualSystemPrompt = `You are WREAD's specialized Visual Intelligence Engine.
Analyze the provided image with high precision, objectivity, and accuracy.
Guidelines:
1. Grounding & Accuracy: Only report what is actually visible in the image. Never speculate or hallucinate details that cannot be verified from visual inspection.
2. Text & OCR: If text, code, logs, or error messages are visible, transcribe them accurately.
3. Screenshots & Diagnostics: If this is a screenshot of software, website, or mobile screen, explain the UI state, identify error banners, stack traces, or broken elements, and suggest practical fixes.
4. Diagrams & Charts: If this is a chart, graph, architecture diagram, or flowchart, explain the flow, data points, nodes, and relationships.
5. Organization: Use clear markdown with headings, bold text, and bullet points for readability.`;

  try {
    // 1. If Gemini is configured, it is the primary multimodal vision provider
    if (geminiProvider.isConfigured()) {
      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const candidateModels = ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
      let visionError: any;

      for (const model of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents: [
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType: normalizedMime.includes('png')
                    ? 'image/png'
                    : normalizedMime.includes('webp')
                    ? 'image/webp'
                    : 'image/jpeg',
                },
              },
              {
                text: `${visualSystemPrompt}\n\nUser Question/Task:\n${userPrompt}`,
              },
            ],
          });

          res.json({
            content: response.text || 'Image processed successfully, but no descriptive text was generated.',
            model: `${model} (multimodal)`,
            provider: 'Gemini Vision',
            timestamp: new Date().toISOString(),
          });
          return;
        } catch (vErr) {
          visionError = vErr;
          console.warn(`[Vision Provider] Model ${model} failed, trying next candidate...`);
        }
      }
      console.warn('[Vision Provider] Gemini models exhausted, attempting Kimi multimodal fallback...');
    }

    // 2. Next attempt Kimi multimodal if configured
    if (kimiProvider.isConfigured()) {
      try {
        const result = await kimiProvider.generateChat([
          { role: 'system', content: visualSystemPrompt },
          {
            role: 'user',
            content: userPrompt,
            images: [
              {
                name: fileName,
                mimeType: normalizedMime.includes('png')
                  ? 'image/png'
                  : normalizedMime.includes('webp')
                  ? 'image/webp'
                  : 'image/jpeg',
                base64: cleanBase64,
              },
            ],
          },
        ]);

        res.json({
          content: result.content,
          model: result.model,
          provider: 'Kimi-K3 Multimodal',
          timestamp: new Date().toISOString(),
        });
        return;
      } catch (kimiErr) {
        console.warn('[Vision Provider] Kimi multimodal call failed:', sanitizeErrorMessage(kimiErr));
      }
    }

    // 3. Neither provider supports vision — DO NOT fake image understanding
    res.status(503).json({
      error: {
        status: 503,
        message: 'Image analysis is currently unavailable: The active AI provider configuration does not support multimodal vision input, and no fallback vision model is configured. Please configure a vision-compatible model (such as Gemini 3.8 Flash via GEMINI_API_KEY) in Settings.',
      },
    });
  } catch (error: any) {
    const safeMsg = sanitizeErrorMessage(error);
    res.status(500).json({
      error: { status: 500, message: safeMsg },
    });
  }
});

// -------------------------------------------------------------
// VITE & STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[WREAD Server] Running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
