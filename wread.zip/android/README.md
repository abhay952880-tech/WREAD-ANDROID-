# WREAD — Android Application Packaging

This directory contains the production-ready Android wrapper project for **WREAD - Your Personal AI Agent**.

---

## 1. Architecture Overview

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS + Lucide Icons + Motion.
- **Backend**: Express server running on Node.js, managing secure communication with Kimi-K3, web research, memory matcher, and multimodal Gemini fallback.
- **Android Layer**: Native Android WebView wrapper targeting Android 14+ (API Level 34), with backwards compatibility down to Android 7.0 (API Level 24).
- **Application ID / Package**: `ai.wread.app`
- **Application Name**: `WREAD`

### 🔒 Security Guarantee
**Strictly ZERO API keys or secrets are embedded inside this Android project or compiled APK.**
All credentials (`KIMI_API_KEY`, Modal Proxy credentials, server secrets) remain strictly server-side. The Android application connects exclusively via secure HTTPS to the backend.

---

## 2. Supported Android Native Features

1. **Direct Launch**: Launches WREAD full-screen with system status bar matching brand color `#030712`.
2. **Responsive Mobile Viewport**: Optimized viewport meta tags, safe area insets, and `adjustResize` soft input handling for smooth mobile typing.
3. **Voice AI Microphone Support**: Handles runtime `RECORD_AUDIO` permission delegation via `WebChromeClient.onPermissionRequest` for real-time speech input.
4. **Image Vision & File Picker**: Custom `onShowFileChooser` implementation enabling photo capture via camera and gallery file selection for WREAD Image Understanding.
5. **Smart Back Navigation**: Integrated with Android 13+ `OnBackPressedCallback` to navigate backwards through in-app history (`webView.goBack()`) and double-tap confirmation to exit at root.
6. **Network Error / Offline Handling**: Custom native offline view with a dedicated "Retry Connection" button.
7. **Pull to Refresh**: Seamless `SwipeRefreshLayout` support.

---

## 3. How to Build the Real Android APK

### Option A: Using Android Studio (Recommended for Visual GUI)
1. Open **Android Studio** (Hedgehog, Iguana, or newer).
2. Select **File > Open...** and choose the `android` folder in this repository.
3. Wait for Gradle sync to complete (automatically downloads Android SDK 34 and dependencies).
4. Connect your Android phone via USB (with **USB Debugging** enabled in Developer Options) or start an Android Virtual Device (AVD).
5. Click the green **Run** button (or press `Shift + F10`) to build and launch WREAD on your phone.
6. To export an installable `.apk` file:
   - Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Click **locate** in the popup notification once the build finishes.
   - The file is located at `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: Using the Command Line (Terminal / CI)
Requirements: JDK 17+ and Android SDK with build-tools installed.

1. Navigate to the `android` directory:
   ```bash
   cd android
   ```
2. Build the debug APK:
   ```bash
   ./gradlew assembleDebug
   ```
   Or run the automated build script:
   ```bash
   ./build-apk.sh
   ```
3. The compiled APK will be at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### Option C: Instant PWA WebAPK on Android Device (Zero Compile Needed)
The web application includes a full Web App Manifest (`/public/manifest.json`):
1. Open the WREAD URL in **Google Chrome** on your Android phone.
2. Tap the browser menu (`⋮`) and select **"Install app"** or **"Add to Home Screen"**.
3. Android will package and install WREAD as a standalone native app icon on your home screen.

---

## 4. How to Install the APK on Your Android Device

1. Connect your Android phone to your computer via USB.
2. Ensure **USB Debugging** is turned on in **Settings > Developer Options**.
3. Run:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
4. Alternatively, transfer `app-debug.apk` directly to your phone via Google Drive, WhatsApp, or USB cable, tap the APK in your phone's File Manager, and select **Install**.
