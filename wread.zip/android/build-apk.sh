#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "          WREAD - Android APK Build Pipeline              "
echo "=========================================================="
echo ""

# Check Java environment
if ! command -v java &> /dev/null; then
    echo "❌ Error: Java (JDK 17+) is required to compile the Android APK."
    echo "   Please install OpenJDK 17 or Android Studio."
    exit 1
fi

echo "✅ Java detected: $(java -version 2>&1 | head -n 1)"

# Check Android SDK
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    echo "⚠️ Notice: Neither ANDROID_HOME nor ANDROID_SDK_ROOT is set."
    echo "   Ensure Android SDK platforms (API 34) and build-tools are installed."
fi

# Make gradlew executable
chmod +x ./gradlew

echo ""
echo "Building WREAD Android Debug APK..."
echo "Command: ./gradlew assembleDebug"
echo ""

./gradlew assembleDebug

echo ""
echo "=========================================================="
echo "🎉 Build Complete!"
echo "Generated APK location:"
echo "👉 app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "To install on your connected Android device:"
echo "   adb install -r app/build/outputs/apk/debug/app-debug.apk"
echo "=========================================================="
